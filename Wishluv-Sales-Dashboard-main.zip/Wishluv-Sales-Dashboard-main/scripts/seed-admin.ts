import { db } from "../server/db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seedAdmin() {
  console.log("Seeding admin user...");
  
  try {
    // Check if admin already exists
    const adminCheck = await db.select().from(users).where(eq(users.username, "admin"));
    
    if (adminCheck.length > 0) {
      console.log("Admin user already exists!");
      return;
    }
    
    // Create admin user
    const hashedPassword = await hashPassword("admin123");
    
    await db.insert(users).values({
      username: "admin",
      password: hashedPassword,
      email: "admin@wishluv.com",
      fullName: "System Administrator",
      role: "admin",
      status: true,
      department: "IT",
      designation: "Super Admin",
      reportingManager: ""
    });
    
    console.log("Admin user created successfully!");
  } catch (error) {
    console.error("Error in seed function:", error);
    throw error;
  }
}

seedAdmin()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Error seeding admin:", err);
    process.exit(1);
  });