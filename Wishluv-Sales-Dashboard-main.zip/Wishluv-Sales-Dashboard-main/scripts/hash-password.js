import crypto from 'crypto';

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${hash}.${salt}`;
}

const password = 'admin123';
const hashedPassword = hashPassword(password);
console.log(`Password: ${password}`);
console.log(`Hashed: ${hashedPassword}`);