import { useState, useEffect } from "react";
import { Switch, Route, useLocation, Redirect, Link } from "wouter";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import ResetPasswordPage from "@/pages/reset-password-page";
import DashboardPage from "@/pages/dashboard-page";
import UserDashboardPage from "@/pages/user-dashboard-page";
import UserManagementPage from "@/pages/user-management-page";
import SalesManagementPage from "@/pages/sales-management-page";
import SalesViewPage from "@/pages/sales-view-page";
import MySalesPage from "@/pages/my-sales-page";
import SalesDashboardPage from "@/pages/sales-dashboard-page";
import ProjectManagementPage from "@/pages/project-management-page";
import DepartmentManagementPage from "@/pages/department-management-page";
import RoleManagementPage from "@/pages/role-management-page";
import AnnouncementsPage from "@/pages/announcements-page";
import EmployeesPage from "@/pages/employees-page";
import EmployeesViewPage from "@/pages/employees-view-page";
import BillingPage from "@/pages/billing-page";
import TargetManagementPage from "@/pages/target-management-page";
import TargetAnalyticsPage from "@/pages/target-analytics-page";
import TargetAchievementPage from "@/pages/target-achievement-page";
import IncentivePage from "@/pages/incentive-page";
import AllTimeIncentivePage from "@/pages/all-time-incentive-page";
import SiteVisitRequestPage from "@/pages/site-visit-request-page";
import DriverDashboardPage from "@/pages/driver-dashboard-page";
import AdminSiteVisitManagementPage from "@/pages/admin-site-visit-management-page";
import { Loader2 } from "lucide-react";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/sidebar";
import { SalesSidebar } from "@/components/layout/sales-sidebar";

// A wrapper component for authenticated admin pages
const AdminLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen bg-gray-50">
    <Sidebar />
    <div className="md:ml-72">
      <main className="p-4 md:p-8">
        {children}
      </main>
    </div>
  </div>
);

// A wrapper component for authenticated sales user pages
const SalesLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen bg-gray-50">
    <SalesSidebar />
    <div className="md:ml-56 pb-16 md:pb-0">
      <main className="p-4 md:p-6">
        {children}
      </main>
    </div>
  </div>
);

// A wrapper component for driver pages
const DriverLayout = ({ children }: { children: React.ReactNode }) => {
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      // Force page reload to ensure clean state
      window.location.href = '/auth';
    } catch (error) {
      console.error('Logout error:', error);
      // Even if logout fails, redirect to auth page
      window.location.href = '/auth';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center space-x-3">
            <h1 className="text-xl font-semibold text-gray-900">Driver Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              Welcome, {user?.fullName || user?.username}
            </span>
            <button
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
              className="px-4 py-2 text-sm text-red-600 hover:text-red-800 border border-red-300 hover:border-red-400 rounded-md transition-colors disabled:opacity-50"
            >
              {logoutMutation.isPending ? 'Logging out...' : 'Logout'}
            </button>
          </div>
        </div>
      </header>
      <main>
        {children}
      </main>
    </div>
  );
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [isSalesUser, setIsSalesUser] = useState<boolean>(false);
  const [isDriverUser, setIsDriverUser] = useState<boolean>(false);
  const [location] = useLocation();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        console.log('Checking authentication status...');
        const response = await fetch('/api/user', {
          credentials: 'include',
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        });
        
        console.log('Auth check response status:', response.status);
        
        if (response.ok) {
          console.log('User is authenticated');
          setIsAuthenticated(true);
          
          // Get user data to check role and department
          const userData = await response.json();
          console.log('Auth user data:', userData);
          
          // Check if user is in Sales department (this will override role-based routing)
          if (userData?.department === 'Sales') {
            console.log('User identified as Sales department user');
            setIsSalesUser(true);
            setIsDriverUser(false);
          } 
          // Check if user is a Driver (by role or designation)
          else if (userData?.designation === 'Driver' || userData?.role === 'Driver') {
            console.log('User identified as Driver');
            setIsSalesUser(false);
            setIsDriverUser(true);
          }
          // If not in Sales department or Driver, check other factors
          else {
            console.log('User identified as admin/non-sales user');
            setIsSalesUser(false);
            setIsDriverUser(false);
          }
        } else {
          console.log('User is not authenticated, redirecting to login');
          setIsAuthenticated(false);
          setIsSalesUser(false);
        }
      } catch (error) {
        console.error('Auth check error:', error);
        setIsAuthenticated(false);
        setIsSalesUser(false);
      }
    };
    
    checkAuth();
  }, [location]);
  
  // Show loading state while checking authentication
  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <AuthProvider>
      <Switch>
        <Route path="/auth">
          {isAuthenticated ? <Redirect to="/" /> : <AuthPage setIsAuthenticated={setIsAuthenticated} />}
        </Route>

        <Route path="/reset-password">
          <ResetPasswordPage />
        </Route>
        
        {/* Protected Routes with role-based routing */}
        <Route path="/">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isDriverUser ? (
            <DriverLayout>
              <DriverDashboardPage />
            </DriverLayout>
          ) : isSalesUser ? (
            <SalesLayout>
              <UserDashboardPage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <DashboardPage />
            </AdminLayout>
          )}
        </Route>

        {/* Admin-only routes */}
        <Route path="/users">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isDriverUser || isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <UserManagementPage />
            </AdminLayout>
          )}
        </Route>
        
        <Route path="/user-management">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isDriverUser || isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <UserManagementPage />
            </AdminLayout>
          )}
        </Route>
        <Route path="/departments">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isDriverUser || isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <DepartmentManagementPage />
            </AdminLayout>
          )}
        </Route>
        <Route path="/roles">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isDriverUser || isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <RoleManagementPage />
            </AdminLayout>
          )}
        </Route>
        <Route path="/billing">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isDriverUser || isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <BillingPage />
            </AdminLayout>
          )}
        </Route>
        
        {/* Removed redundant /sales route as requested */}
        
        {/* Specific route for Sales Management */}
        <Route path="/sales-management">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <SalesManagementPage />
            </AdminLayout>
          )}
        </Route>
        
        {/* Admin Sales Management route */}
        <Route path="/admin/sales">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <SalesManagementPage />
            </AdminLayout>
          )}
        </Route>
        <Route path="/projects">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <SalesLayout>
              <ProjectManagementPage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <ProjectManagementPage />
            </AdminLayout>
          )}
        </Route>
        <Route path="/announcements">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <SalesLayout>
              <AnnouncementsPage viewOnly={true} />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <AnnouncementsPage viewOnly={false} />
            </AdminLayout>
          )}
        </Route>
        
        {/* Employees route (accessible by both) */}
        <Route path="/employees">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <SalesLayout>
              <EmployeesViewPage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <EmployeesPage />
            </AdminLayout>
          )}
        </Route>
        
        {/* Target Management Routes */}
        <Route path="/targets">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <TargetManagementPage />
            </AdminLayout>
          )}
        </Route>
        
        {/* Alternative route for Target Management */}
        <Route path="/target-management">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <TargetManagementPage />
            </AdminLayout>
          )}
        </Route>
        
        {/* Target Analytics Page - Admin only */}
        <Route path="/admin/target-analytics">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <Redirect to="/" />
          ) : (
            <AdminLayout>
              <TargetAnalyticsPage />
            </AdminLayout>
          )}
        </Route>
        
        <Route path="/target-achievement">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <SalesLayout>
              <TargetAchievementPage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <TargetAchievementPage />
            </AdminLayout>
          )}
        </Route>
        
        <Route path="/incentive">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <SalesLayout>
              <IncentivePage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <IncentivePage />
            </AdminLayout>
          )}
        </Route>
        
        <Route path="/all-time-incentive">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <SalesLayout>
              <AllTimeIncentivePage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <AllTimeIncentivePage />
            </AdminLayout>
          )}
        </Route>
        
        {/* My Sales route - for sales users to view their sales */}
        <Route path="/my-sales">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isSalesUser ? (
            <SalesLayout>
              <MySalesPage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <MySalesPage />
            </AdminLayout>
          )}
        </Route>

        {/* Site Visit Management Routes */}
        <Route path="/site-visits">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : isDriverUser ? (
            <Redirect to="/" />
          ) : isSalesUser ? (
            <SalesLayout>
              <SiteVisitRequestPage />
            </SalesLayout>
          ) : (
            <AdminLayout>
              <AdminSiteVisitManagementPage />
            </AdminLayout>
          )}
        </Route>

        <Route path="/driver-dashboard">
          {!isAuthenticated ? (
            <Redirect to="/auth" />
          ) : (
            <DriverLayout>
              <DriverDashboardPage />
            </DriverLayout>
          )}
        </Route>
        
        <Route>
          <NotFound />
        </Route>
      </Switch>
    </AuthProvider>
  );
}

export default App;
