// This file maps to the SalesDesignation enum in the server-side schema.ts file

export enum SalesDesignation {
  SALES_EXECUTIVE = "Sales Executive",
  TEAM_LEADER = "Team Leader",
  SALES_HEAD = "Sales Head"
}

// Helper functions to check designations
export const isSalesExecutive = (designation: string | null | undefined): boolean => {
  return designation === SalesDesignation.SALES_EXECUTIVE;
};

export const isTeamLeader = (designation: string | null | undefined): boolean => {
  return designation === SalesDesignation.TEAM_LEADER;
};

export const isSalesHead = (designation: string | null | undefined): boolean => {
  return designation === SalesDesignation.SALES_HEAD;
};

export const isAnySalesRole = (designation: string | null | undefined): boolean => {
  return isSalesExecutive(designation) || isTeamLeader(designation) || isSalesHead(designation);
};