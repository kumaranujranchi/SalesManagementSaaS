/**
 * Date utility functions for formatting and manipulating dates
 */

/**
 * Get the name of the month from its numeric representation (1-12)
 * @param monthNumber Month number (1-12)
 * @returns The name of the month
 */
export function getMonthName(monthNumber: number): string {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  
  // Adjust for 1-based month numbering
  const index = ((monthNumber - 1) % 12 + 12) % 12; // Handle negative or out of range values
  return months[index];
}

/**
 * Format a date string (YYYY-MM-DD) to a more readable format
 * @param dateString Date string in YYYY-MM-DD format
 * @returns Formatted date string (e.g., "May 10, 2025")
 */
export function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  } catch (e) {
    return dateString;
  }
}

/**
 * Format a date object to YYYY-MM-DD string format
 * @param date Date object
 * @returns Date string in YYYY-MM-DD format
 */
export function formatDateToString(date: Date): string {
  return date.toISOString().split('T')[0];
}

/**
 * Get the current month and year as an object
 * @returns Object with month (1-12) and year
 */
export function getCurrentMonthYear(): { month: number; year: number } {
  const now = new Date();
  return {
    month: now.getMonth() + 1, // Months are 0-indexed in JS
    year: now.getFullYear()
  };
}

/**
 * Get the first day of the current month
 * @returns Date object for the first day of the current month
 */
export function getFirstDayOfMonth(): Date {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), 1);
}

/**
 * Get the last day of the current month
 * @returns Date object for the last day of the current month
 */
export function getLastDayOfMonth(): Date {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth() + 1, 0);
}

/**
 * Format a date in a standard format
 * @param date Date to format
 * @param includeTime Whether to include time in the output
 * @returns Formatted date string
 */
export function formatDateTime(date: Date, includeTime: boolean = false): string {
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  };
  
  if (includeTime) {
    options.hour = '2-digit';
    options.minute = '2-digit';
  }
  
  return date.toLocaleDateString('en-US', options);
}

/**
 * Get the relative time description from a date
 * @param date Date to get relative time for
 * @returns Relative time string (e.g., "2 hours ago", "yesterday", etc.)
 */
export function getRelativeTime(date: Date): string {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return `${diffInSeconds} second${diffInSeconds === 1 ? '' : 's'} ago`;
  }
  
  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) {
    return `${diffInMinutes} minute${diffInMinutes === 1 ? '' : 's'} ago`;
  }
  
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) {
    return `${diffInHours} hour${diffInHours === 1 ? '' : 's'} ago`;
  }
  
  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays === 1) {
    return 'yesterday';
  }
  
  if (diffInDays < 30) {
    return `${diffInDays} days ago`;
  }
  
  return formatDateTime(date);
}