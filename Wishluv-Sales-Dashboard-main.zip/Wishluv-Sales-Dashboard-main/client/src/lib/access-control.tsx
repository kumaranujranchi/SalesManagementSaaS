import { ReactNode } from 'react';
import { Redirect } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Loader2 } from 'lucide-react';

type PermissionCheckFunc = (userRole: string, userDepartment: string) => boolean;

interface RoleBasedRouteProps {
  children: ReactNode;
  fallbackPath?: string;
  permissionCheck: PermissionCheckFunc;
}

/**
 * A component that checks if the current user has the required permission
 * based on their role and department.
 */
export function RoleBasedRoute({
  children,
  fallbackPath = '/',
  permissionCheck
}: RoleBasedRouteProps) {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  const hasAccess = user ? permissionCheck(user.role || '', user.department || '') : false;
  
  if (!hasAccess) {
    return <Redirect to={fallbackPath} />;
  }
  
  return <>{children}</>;
}

// Predefined permission checks for common scenarios
export const isAdmin = (role: string) => {
  return ['admin', 'Admin', 'Super Admin'].includes(role);
};

export const isCRM = (role: string) => {
  return role === 'CRM';
};

export const isAccountant = (role: string) => {
  return role === 'Accountant';
};

export const isSalesDepartment = (role: string, department: string) => {
  return department === 'Sales';
};

export const hasUserManagementAccess = (role: string) => {
  return ['admin', 'Admin', 'Super Admin'].includes(role);
};

export const hasSalesManagementAccess = (role: string, department: string) => {
  return ['admin', 'Admin', 'Super Admin', 'CRM', 'Accountant'].includes(role) || 
         (department === 'Sales' && ['Manager'].includes(role));
};

export const hasRoleManagementAccess = (role: string) => {
  return ['admin', 'Super Admin'].includes(role);
};

export const hasDepartmentManagementAccess = (role: string) => {
  return ['admin', 'Super Admin'].includes(role);
};

export const hasProjectManagementAccess = (role: string, department: string) => {
  return ['admin', 'Admin', 'Super Admin'].includes(role) || 
         (department === 'Sales' && ['Manager'].includes(role));
};

export const hasAnnouncementsAccess = (role: string) => {
  // Everyone can see announcements
  return true;
};