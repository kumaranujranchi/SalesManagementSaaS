import { usePermissions } from "@/hooks/use-permissions";
import { ReactNode } from "react";

interface PermissionGuardProps {
  resource: string; // e.g. "user", "department", "role"
  action: 'view' | 'create' | 'edit' | 'delete'; // Action type
  children: ReactNode;
  fallback?: ReactNode; // Optional fallback to render instead
}

/**
 * A component that conditionally renders its children if the user has the required permission
 */
export function PermissionGuard({
  resource,
  action,
  children,
  fallback = null
}: PermissionGuardProps) {
  const { canPerformAction } = usePermissions();
  
  if (!canPerformAction(resource, action)) {
    return <>{fallback}</>;
  }
  
  return <>{children}</>;
}