import { Button, ButtonProps } from "@/components/ui/button";
import { usePermissions } from "@/hooks/use-permissions";
import { ReactNode } from "react";

interface PermissionButtonProps extends ButtonProps {
  resource: string; // e.g. "user", "department", "role"
  action: 'view' | 'create' | 'edit' | 'delete'; // Action type
  children: ReactNode;
}

/**
 * A button that is only rendered if the user has the required permission
 */
export function PermissionButton({
  resource,
  action,
  children,
  ...props
}: PermissionButtonProps) {
  const { canPerformAction } = usePermissions();
  
  // Don't render the button at all if user doesn't have permission
  if (!canPerformAction(resource, action)) {
    return null;
  }
  
  return (
    <Button {...props}>
      {children}
    </Button>
  );
}