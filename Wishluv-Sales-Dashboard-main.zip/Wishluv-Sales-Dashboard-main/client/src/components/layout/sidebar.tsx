import { useLocation, Link } from "wouter";
import { 
  Home, 
  Users, 
  BarChartBig, 
  ClipboardList, 
  Building2, 
  UserSquare2, 
  BellRing,
  LogOut,
  Target,
  LineChart,
  MapPin
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import logo from "../../assets/company-logo.png";

export interface SidebarItem {
  title: string;
  path: string;
  icon: React.ReactNode;
  mobileDisplay?: boolean;
  requiredPermission?: string;
  allowedRoles?: string[];
}

export function Sidebar() {
  const [location] = useLocation();
  const { logoutMutation, user } = useAuth();

  // Define all possible sidebar items
  const allSidebarItems: SidebarItem[] = [
    {
      title: "Dashboard",
      path: "/",
      icon: <Home className="w-5 h-5" />,
      mobileDisplay: true,
      allowedRoles: ["admin", "Admin", "Super Admin", "Accountant", "CRM", "Manager", "Sales Executive", "Team Leader", "Sales Head"]
    },
    {
      title: "Sales",
      path: "/my-sales",
      icon: <LineChart className="w-5 h-5" />,
      mobileDisplay: true,
      allowedRoles: ["Sales Executive", "Team Leader", "Sales Head", "Sales Manager"]
    },
    {
      title: "Sales Management",
      path: "/sales-management",
      icon: <BarChartBig className="w-5 h-5" />,
      mobileDisplay: true,
      requiredPermission: "sales.view",
      allowedRoles: ["admin", "Admin", "Super Admin", "Accountant", "CRM", "Manager"]
    },
    {
      title: "User Management",
      path: "/users",
      icon: <Users className="w-5 h-5" />,
      mobileDisplay: false,
      requiredPermission: "user.view",
      allowedRoles: ["admin", "Admin", "Super Admin", "CRM"]
    },
    {
      title: "Project Management",
      path: "/projects",
      icon: <ClipboardList className="w-5 h-5" />,
      mobileDisplay: false,
      allowedRoles: ["admin", "Admin", "Super Admin", "Manager"]
    },
    {
      title: "Department Management",
      path: "/departments",
      icon: <Building2 className="w-5 h-5" />,
      mobileDisplay: false,
      allowedRoles: ["admin", "Super Admin"]
    },
    {
      title: "Role Management",
      path: "/roles",
      icon: <UserSquare2 className="w-5 h-5" />,
      mobileDisplay: false,
      allowedRoles: ["admin", "Super Admin"]
    },
    {
      title: "Announcements",
      path: "/announcements",
      icon: <BellRing className="w-5 h-5" />,
      mobileDisplay: true,
      allowedRoles: ["admin", "Admin", "Super Admin", "Accountant", "CRM", "Manager"]
    },
    {
      title: "Target Management",
      path: "/targets",
      icon: <Target className="w-5 h-5" />,
      mobileDisplay: false,
      allowedRoles: ["admin", "Super Admin", "Sales Manager"]
    },
    {
      title: "Site Visit Management",
      path: "/site-visits",
      icon: <MapPin className="w-5 h-5" />,
      mobileDisplay: true,
      allowedRoles: ["admin", "Super Admin", "Manager"]
    }
  ];

  // Define a type for permissions
  type PermissionsType = {
    [key: string]: boolean | undefined;
  };

  // Parse permissions from user role
  const userPermissions: PermissionsType = (() => {
    try {
      // For roles with JSON permissions
      if (user?.role === 'Admin' || user?.role === 'admin') {
        return {
          "sales.view": true,
          "sales.edit": true,
          "sales.create": true,
          "sales.delete": true,
          "user.view": true,
          "user.edit": true,
          "user.delete": true,
          "user.create": true,
          "dashboard.view": true,
          "announcements.view": true
        };
      }
      
      // Super Admin has all permissions
      if (user?.role === 'Super Admin') {
        const allPermissions: PermissionsType = { "*": true };
        return allPermissions;
      }
      
      // CRM role permissions
      if (user?.role === 'CRM') {
        return { 
          "sales.view": true,
          "sales.edit": true,
          "sales.create": true,
          "sales.delete": true,
          "user.view": true,
          "user.edit": true,
          "user.create": true,
          "user.delete": true,
          "dashboard.view": true,
          "announcements.view": true
        };
      }
      
      // Accountant role permissions
      if (user?.role === 'Accountant') {
        return { 
          "sales.view": true,
          "sales.edit": false,
          "sales.create": false,
          "dashboard.view": true,
          "announcements.view": true
        };
      }
      
      // Default to empty permissions
      return {};
    } catch (error) {
      console.error("Error parsing permissions:", error);
      return {};
    }
  })();

  // Filter sidebar items based on user role and permissions
  const sidebarItems = allSidebarItems.filter(item => {
    // Check if user has required permission
    if (item.requiredPermission) {
      if (userPermissions["*"]) return true; // Super admin access
      return !!userPermissions[item.requiredPermission];
    }
    
    // Check if user's role is in allowed roles
    if (item.allowedRoles) {
      return item.allowedRoles.includes(user?.role || "");
    }
    
    // Default items shown to everyone
    return true;
  });

  // Items to show in mobile bottom nav
  const mobileNavItems = sidebarItems.filter(item => item.mobileDisplay);

  return (
    <>
      {/* Desktop Sidebar with fixed-height layout */}
      <div className="hidden md:block fixed top-0 left-0 bottom-0 w-72 z-10">
        <div className="bg-white shadow-md h-full flex flex-col">
          {/* Logo section */}
          <div className="p-4 border-b border-gray-200 bg-blue-50">
            <div className="flex items-center">
              <div className="h-8 w-8 rounded-md flex items-center justify-center">
                <img src={logo} alt="WishLuv BuildCon Logo" className="h-8 w-auto" />
              </div>
              <h1 className="ml-2 text-xl font-semibold text-blue-900">WishLuv BuildCon</h1>
            </div>
          </div>
          
          {/* Navigation menu - scrollable */}
          <div className="flex-1 overflow-y-auto py-4 px-3">
            <ul className="space-y-1">
              {sidebarItems.map((item) => (
                <li key={item.path}>
                  <Link href={item.path} className={cn(
                    "flex items-center px-4 py-3 rounded-md transition-colors",
                    location === item.path 
                      ? "bg-blue-100 text-blue-800 font-medium" 
                      : "hover:bg-neutral-100 text-neutral-700"
                  )}>
                    <span className={location === item.path ? "text-blue-600" : "text-gray-500"}>
                      {item.icon}
                    </span>
                    <span className="ml-2">{item.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Logout section - truly fixed at bottom */}
          <div className="p-4 border-t border-gray-200">
            <button 
              onClick={() => logoutMutation.mutate()}
              className="w-full flex items-center justify-center gap-2 text-sm text-gray-700 py-2 px-3 rounded-md hover:bg-blue-50 transition-colors hover:text-blue-700"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_8px_rgba(0,0,0,0.08)] border-t border-gray-100 z-20">
        <nav className="grid grid-cols-4 w-full">
          {mobileNavItems.map((item) => (
            <Link 
              key={item.path}
              href={item.path}
              className={cn(
                "flex flex-col items-center justify-center py-2 px-1 h-16",
                location === item.path 
                  ? "text-blue-700" 
                  : "text-neutral-600"
              )}
            >
              <div className={cn(
                "flex items-center justify-center w-8 h-8 rounded-full mb-1",
                location === item.path 
                  ? "bg-blue-100" 
                  : "bg-transparent"
              )}>
                <div className={cn(
                  "w-5 h-5 flex items-center justify-center",
                  location === item.path 
                    ? "text-blue-700" 
                    : "text-gray-500"
                )}>
                  {item.icon}
                </div>
              </div>
              <span className="text-[10px] font-medium text-center whitespace-nowrap">{item.title}</span>
            </Link>
          ))}
        </nav>
        
        {/* Logout button in mobile nav */}
        <div className="absolute right-3 -top-14 z-30">
          <button 
            onClick={() => logoutMutation.mutate()}
            className="flex items-center justify-center w-11 h-11 rounded-full bg-white shadow-lg border border-gray-200 text-red-500 hover:bg-red-50 transition-colors"
            aria-label="Logout"
          >
            <LogOut className="h-5 w-5" />
          </button>
        </div>
        
        {/* Space buffer at bottom to ensure content isn't hidden behind bottom nav on small screens */}
        <div className="h-safe-area-bottom bg-white"></div>
      </div>
    </>
  );
}
