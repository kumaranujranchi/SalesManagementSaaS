import { ReactNode } from "react";
import { Link } from "wouter";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  backAction?: () => void;
  backUrl?: string;
}

export function PageHeader({ 
  title, 
  subtitle, 
  icon, 
  backAction, 
  backUrl 
}: PageHeaderProps) {
  return (
    <div className="flex flex-col space-y-2 py-4">
      <div className="flex items-center">
        {(backAction || backUrl) && (
          backUrl ? (
            <Link href={backUrl}>
              <Button variant="ghost" size="sm" className="mr-2">
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back
              </Button>
            </Link>
          ) : (
            <Button onClick={backAction} variant="ghost" size="sm" className="mr-2">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Button>
          )
        )}
        <div className="flex items-center">
          {icon && <div className="mr-2 text-primary">{icon}</div>}
          <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        </div>
      </div>
      {subtitle && <p className="text-muted-foreground">{subtitle}</p>}
    </div>
  );
}