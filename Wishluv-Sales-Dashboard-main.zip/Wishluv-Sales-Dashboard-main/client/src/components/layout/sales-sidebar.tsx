import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  LayoutDashboard, 
  Users, 
  Megaphone, 
  Calendar, 
  Building2, 
  LogOut,
  BarChart3,
  Menu,
  X,
  Target,
  TrendingUp,
  Gift,
  MapPin
} from "lucide-react";

interface SidebarLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
}

const SidebarLink = ({ href, icon, children, active }: SidebarLinkProps) => {
  return (
    <Link href={href}>
      <div
        className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-black hover:bg-gray-100 ${
          active ? "bg-muted font-medium text-primary" : "text-muted-foreground"
        }`}
      >
        {icon}
        <span>{children}</span>
      </div>
    </Link>
  );
};

export function SalesSidebar() {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleLogout = () => {
    if (confirm("Are you sure you want to log out?")) {
      logoutMutation.mutate();
    }
  };

  // Determine if we're on the current path for active state
  const isActive = (path: string) => {
    if (path === "/") {
      return location === "/";
    }
    
    // For all other paths, check if the current location starts with the provided path
    // This makes the menu item stay active for sub-paths like /employees-view
    return location === path || location.startsWith(`${path}-view`);
  };

  // Mobile bottom nav
  if (isMobile) {
    return (
      <>
        {/* Mobile Menu Button */}
        <div className="fixed top-4 right-14 z-50">
          <Button 
            size="icon" 
            variant="outline" 
            className="h-10 w-10 rounded-full shadow-sm ml-[-20px] mr-[-20px]"
            onClick={toggleSidebar}
          >
            {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
        
        {/* Mobile Sidebar */}
        {isOpen && (
          <div className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm" onClick={toggleSidebar}>
            <div 
              className="fixed inset-y-0 left-0 z-40 w-72 bg-background border-r" 
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex h-screen flex-col overflow-y-auto">
                <div className="px-3 py-4 border-b sticky top-0 bg-background">
                  <h2 className="text-lg font-bold text-primary">Wishluv Buildcon</h2>
                  <p className="text-sm text-muted-foreground">Sales Dashboard</p>
                </div>
                <nav className="flex-1 space-y-1 px-3 py-4">
                  <SidebarLink 
                    href="/" 
                    icon={<LayoutDashboard className="h-5 w-5" />} 
                    active={isActive("/")}
                  >
                    Dashboard
                  </SidebarLink>


                  <SidebarLink 
                    href="/target-achievement" 
                    icon={<Target className="h-5 w-5" />} 
                    active={isActive("/target-achievement")}
                  >
                    Target vs Achievement
                  </SidebarLink>
                  <SidebarLink 
                    href="/incentive" 
                    icon={<Gift className="h-5 w-5" />} 
                    active={isActive("/incentive")}
                  >
                    Incentive
                  </SidebarLink>
                  <SidebarLink 
                    href="/site-visits" 
                    icon={<MapPin className="h-5 w-5" />} 
                    active={isActive("/site-visits")}
                  >
                    Site Visits
                  </SidebarLink>
                  <SidebarLink 
                    href="/announcements" 
                    icon={<Megaphone className="h-5 w-5" />} 
                    active={isActive("/announcements")}
                  >
                    Announcement
                  </SidebarLink>
                </nav>
                <div className="border-t p-3 sticky bottom-0 bg-background mt-auto">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={handleLogout}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Fixed bottom navigation */}
        <div className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background shadow-md">
          <div className="grid grid-cols-6 gap-1 px-1">
            <Link href="/">
              <div className={`flex flex-col items-center justify-center py-2 ${isActive("/") ? "text-primary" : "text-muted-foreground"}`}>
                <LayoutDashboard className="h-4 w-4" />
                <span className="text-xs mt-1">Dashboard</span>
              </div>
            </Link>
            <Link href="/employees">
              <div className={`flex flex-col items-center justify-center py-2 ${isActive("/employees") || isActive("/employees-view") ? "text-primary" : "text-muted-foreground"}`}>
                <Users className="h-4 w-4" />
                <span className="text-xs mt-1">Employee</span>
              </div>
            </Link>
            <Link href="/site-visits">
              <div className={`flex flex-col items-center justify-center py-2 ${isActive("/site-visits") ? "text-primary" : "text-muted-foreground"}`}>
                <MapPin className="h-4 w-4" />
                <span className="text-xs mt-1">Site Visits</span>
              </div>
            </Link>
            <Link href="/incentive">
              <div className={`flex flex-col items-center justify-center py-2 ${isActive("/incentive") ? "text-primary" : "text-muted-foreground"}`}>
                <Gift className="h-4 w-4" />
                <span className="text-xs mt-1">Incentive</span>
              </div>
            </Link>
            <Link href="/target-achievement">
              <div className={`flex flex-col items-center justify-center py-2 ${isActive("/target-achievement") ? "text-primary" : "text-muted-foreground"}`}>
                <Target className="h-4 w-4" />
                <span className="text-xs mt-1">Targets</span>
              </div>
            </Link>
            <Link href="/announcements">
              <div className={`flex flex-col items-center justify-center py-2 ${isActive("/announcements") || isActive("/announcements-view") ? "text-primary" : "text-muted-foreground"}`}>
                <Megaphone className="h-4 w-4" />
                <span className="text-xs mt-1">Updates</span>
              </div>
            </Link>
          </div>
        </div>
      </>
    );
  }

  // Desktop sidebar
  return (
    <div className="fixed inset-y-0 left-0 w-56 bg-background border-r">
      <div className="flex h-screen flex-col">
        <div className="px-3 py-4 border-b">
          <h2 className="text-lg font-bold text-primary">Wishluv Buildcon</h2>
          <p className="text-sm text-muted-foreground">Sales Dashboard</p>
        </div>
        <nav className="flex-1 space-y-1 px-3 py-4">
          <div className="mb-4">
            <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Main
            </h3>
            <div className="space-y-1 mt-2">
              <SidebarLink 
                href="/" 
                icon={<LayoutDashboard className="h-5 w-5" />} 
                active={isActive("/")}
              >
                Dashboard
              </SidebarLink>
            </div>
          </div>
          
          <div className="mb-4">
            <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Resources
            </h3>
            <div className="space-y-1 mt-2">
              <SidebarLink 
                href="/employees" 
                icon={<Users className="h-5 w-5" />} 
                active={isActive("/employees")}
              >
                Employee
              </SidebarLink>

              <SidebarLink 
                href="/my-sales" 
                icon={<TrendingUp className="h-5 w-5" />} 
                active={isActive("/my-sales")}
              >
                My Sales
              </SidebarLink>
              <SidebarLink 
                href="/target-achievement" 
                icon={<Target className="h-5 w-5" />} 
                active={isActive("/target-achievement")}
              >
                Target vs Achievement
              </SidebarLink>
              <SidebarLink 
                href="/incentive" 
                icon={<Gift className="h-5 w-5" />} 
                active={isActive("/incentive")}
              >
                Incentive
              </SidebarLink>
              <SidebarLink 
                href="/site-visits" 
                icon={<MapPin className="h-5 w-5" />} 
                active={isActive("/site-visits")}
              >
                Site Visits
              </SidebarLink>
              <SidebarLink 
                href="/announcements" 
                icon={<Megaphone className="h-5 w-5" />} 
                active={isActive("/announcements")}
              >
                Announcement
              </SidebarLink>
            </div>
          </div>
        </nav>
        <div className="border-t p-3">
          <Button 
            variant="outline" 
            className="w-full justify-start ml-[-20px] mr-[-20px]"
            onClick={handleLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
}