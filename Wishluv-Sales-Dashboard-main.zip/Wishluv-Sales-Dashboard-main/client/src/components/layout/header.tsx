import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { SidebarItem } from "./sidebar";
import { 
  Home, 
  Users, 
  BarChartBig, 
  ClipboardList, 
  Building2, 
  UserSquare2, 
  BellRing,
  CreditCard
} from "lucide-react";
import { cn } from "@/lib/utils";

// Empty header component as requested - header section has been removed
export function Header() {
  const { user } = useAuth();
  const [location] = useLocation();

  return <></>; // Return empty fragment
}
