import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, CreditCard, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";

interface BillingOption {
  period: "3years" | "2years" | "1year";
  label: string;
  originalPrice: number;
  discountedPrice: number;
  isPopular?: boolean;
}

export function BillingPeriod() {
  const { toast } = useToast();
  const [selectedPeriod, setSelectedPeriod] = useState<string>("3years");
  const [couponCode, setCouponCode] = useState<string>("");
  const [showCouponInput, setShowCouponInput] = useState<boolean>(false);
  
  const billingOptions: BillingOption[] = [
    {
      period: "3years",
      label: "3 years",
      originalPrice: 1179.0,
      discountedPrice: 499.0,
    },
    {
      period: "2years",
      label: "2 years",
      originalPrice: 1179.0,
      discountedPrice: 499.0,
      isPopular: true,
    },
    {
      period: "1year",
      label: "1 year",
      originalPrice: 1179.0,
      discountedPrice: 749.0,
    },
  ];
  
  const selectedOption = billingOptions.find(option => option.period === selectedPeriod);
  
  const taxesAndFees = 567.11;
  const total = selectedOption ? selectedOption.discountedPrice * (selectedOption.period === "3years" ? 3 : (selectedOption.period === "2years" ? 2 : 1)) + taxesAndFees : 0;
  
  const handleCompletePurchase = () => {
    toast({
      title: "Payment Successful",
      description: "Your payment has been processed successfully.",
    });
  };
  
  const handleCancel = () => {
    toast({
      title: "Purchase Cancelled",
      description: "Your purchase has been cancelled.",
      variant: "destructive",
    });
  };

  return (
    <Card className="mx-auto max-w-2xl bg-white rounded-lg shadow-md overflow-hidden">
      <CardContent className="p-6">
        <h1 className="text-xl font-bold mb-2">Choose billing period - omavonstructions.com</h1>
        <p className="text-neutral-600 mb-6">Choose a billing period and finish the checkout</p>
        
        <RadioGroup 
          defaultValue={selectedPeriod} 
          value={selectedPeriod}
          onValueChange={setSelectedPeriod}
          className="space-y-4"
        >
          {billingOptions.map((option) => (
            <div 
              key={option.period}
              className={`border rounded-md p-4 flex items-center justify-between ${
                selectedPeriod === option.period 
                  ? "border-primary" 
                  : "border-neutral-200"
              }`}
            >
              <div className="flex items-center">
                <RadioGroupItem value={option.period} id={option.period} className="text-secondary" />
                <Label htmlFor={option.period} className="ml-3 font-medium">
                  {option.label}
                  {option.isPopular && (
                    <span className="ml-2 px-2 py-0.5 text-xs bg-red-100 text-red-500 rounded-sm font-medium">
                      MOST POPULAR
                    </span>
                  )}
                </Label>
              </div>
              <div className="flex items-center">
                <span className="text-neutral-500 line-through mr-2">₹ {option.originalPrice.toFixed(2)}</span>
                <span className="font-semibold">₹ {option.discountedPrice.toFixed(2)}/1st yr</span>
              </div>
            </div>
          ))}
        </RadioGroup>
        
        <div className="mt-6 p-4 bg-primary/10 rounded-md flex items-center">
          <Shield className="h-6 w-6 flex-shrink-0 text-green-500" />
          <span className="ml-3 text-sm">FREE domain privacy protection included</span>
        </div>
        
        <div className="mt-6">
          <h3 className="font-medium mb-3">Payment method</h3>
          <div className="border border-neutral-200 rounded-md p-3 flex items-center justify-between">
            <div className="flex items-center">
              <span className="mr-2 h-8 w-12 bg-neutral-800 rounded flex items-center justify-center text-white">
                <CreditCard className="h-4 w-4" />
              </span>
              <span className="text-neutral-600">Card •••• ••••</span>
            </div>
            <ChevronDown className="h-4 w-4 text-neutral-500" />
          </div>
        </div>
        
        <div className="mt-6 space-y-2">
          <div className="flex justify-between">
            <span className="text-neutral-600">Taxes & Fees</span>
            <span className="font-medium">₹ {taxesAndFees.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-medium">Total</span>
            <span className="font-bold">₹ {total.toFixed(2)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-neutral-600">Coupon code</span>
            {showCouponInput ? (
              <div className="flex items-center">
                <Input 
                  value={couponCode} 
                  onChange={(e) => setCouponCode(e.target.value)} 
                  placeholder="Enter coupon code"
                  className="w-36 h-8 mr-2"
                />
                <Button 
                  variant="link" 
                  onClick={() => {
                    setShowCouponInput(false);
                    setCouponCode("");
                  }}
                  className="h-8 p-0 text-red-500"
                >
                  Cancel
                </Button>
              </div>
            ) : (
              <Button 
                variant="link" 
                onClick={() => setShowCouponInput(true)}
                className="text-secondary font-medium p-0 h-8"
              >
                Add
              </Button>
            )}
          </div>
        </div>
        
        <div className="mt-6 text-sm text-neutral-600">
          <p>By checking out, you agree with our <a href="#" className="text-secondary">Terms of Service</a> and confirm that you have read our <a href="#" className="text-secondary">Privacy Policy</a>. You can cancel recurring payments at any time.</p>
        </div>
        
        <div className="mt-3 text-sm text-neutral-600">
          <p>Domain renews at ₹ 1,179.00/year on 2028-04-20</p>
        </div>
        
        <div className="mt-6 flex justify-between">
          <Button 
            variant="outline" 
            onClick={handleCancel}
            className="px-6 py-3 border border-neutral-300 text-neutral-700 font-medium rounded-md hover:bg-neutral-50 transition-colors"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleCompletePurchase}
            className="px-6 py-3 bg-secondary text-white font-medium rounded-md hover:bg-secondary/90 transition-colors"
          >
            Complete payment
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
