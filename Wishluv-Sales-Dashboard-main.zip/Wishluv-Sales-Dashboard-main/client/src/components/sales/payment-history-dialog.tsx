import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogClose 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, DollarSign, Hourglass, RotateCcw } from "lucide-react";
import { Sales, Project } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";

interface PaymentHistoryDialogProps {
  open: boolean;
  onClose: () => void;
  sale: Sales | null;
  projectsData?: Project[];
}

interface Payment {
  id: number;
  saleId: number;
  paymentDate: string;
  amount: string;
  paymentMode: string;
  paymentType: string;
  remarks?: string;
  createdBy: number;
  createdAt: string;
}

export function PaymentHistoryDialog({ 
  open, 
  onClose, 
  sale,
  projectsData
}: PaymentHistoryDialogProps) {
  const { user } = useAuth();
  
  // Exit early if no sale is selected
  if (!sale) return null;

  // Get the project name for the sale
  const projectName = projectsData?.find(p => p.id === sale.projectId)?.name || "Unknown";

  // Fetch payments for this sale
  const { data: payments, isLoading } = useQuery<Payment[]>({
    queryKey: [`/api/payments/${sale.id}`],
    queryFn: async () => {
      const res = await fetch(`/api/payments/${sale.id}`);
      if (!res.ok) throw new Error("Failed to fetch payment data");
      return res.json();
    },
    enabled: open && !!sale
  });
  
  // Fetch sales executive information if not available
  const { data: userData } = useQuery<any[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await fetch("/api/users");
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    },
    enabled: open && !!sale
  });
  
  // Find the sales executive name based on the sale's salesExecutiveId
  const salesExecutiveName = userData?.find((u: any) => u.id === sale.salesExecutiveId)?.fullName || user?.fullName || "Unknown";

  // Calculate payment stats
  const totalPaid = payments?.reduce((sum, payment) => 
    sum + parseFloat(payment.amount), 0) || 0;
  
  const finalAmount = parseFloat(sale.finalAmount || "0");
  const balanceDue = Math.max(0, finalAmount - totalPaid);
  const paymentPercentage = finalAmount > 0 ? (totalPaid / finalAmount) * 100 : 0;
  
  // Find the latest payment date
  const lastPayment = payments?.sort((a, b) => 
    new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime()
  )[0];

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto bg-amber-50 p-4 sm:p-6">
        <DialogHeader className="bg-amber-200 -mx-4 -mt-4 sm:-mx-6 sm:-mt-6 p-4 sm:p-6 sticky top-0 z-10">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="bg-white rounded-full p-1.5 sm:p-2">
                <DollarSign className="h-5 w-5 sm:h-6 sm:w-6 text-amber-500" />
              </div>
              <div>
                <DialogTitle className="text-lg sm:text-xl font-bold text-black">
                  {sale.customerName}
                </DialogTitle>
                <p className="text-amber-800 text-xs sm:text-sm">Customer Ledger & Payment Management</p>
              </div>
            </div>
            <DialogClose asChild>
              <Button 
                className="h-8 sm:h-9 w-auto px-2 sm:px-3 text-xs sm:text-sm rounded-full bg-white hover:bg-gray-100 text-gray-700"
                variant="ghost"
              >
                Close
              </Button>
            </DialogClose>
          </div>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mt-6">
          {/* Left column - Sale details */}
          <div className="md:col-span-1 space-y-4 sm:space-y-6">
            <div className="bg-white p-3 sm:p-4 rounded-md shadow-sm">
              <h3 className="flex items-center text-amber-700 text-sm sm:text-base font-medium mb-2 sm:mb-4">
                <span className="bg-amber-100 p-1 rounded-full mr-2">
                  <svg className="h-3 w-3 sm:h-4 sm:w-4 text-amber-500" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5.586a1 1 0 0 1 .707.293l5.414 5.414a1 1 0 0 1 .293.707V19a2 2 0 0 1-2 2z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </span>
                SALE DETAILS
              </h3>

              <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm">
                <div>
                  <p className="text-gray-500">Project</p>
                  <p className="font-medium text-black">{projectName}</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Sales Executive</p>
                  <p className="font-medium text-black">{salesExecutiveName}</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Booking Date</p>
                  <p className="font-medium text-black">{format(new Date(sale.bookingDate), "MMMM dd, yyyy")}</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Area Sold</p>
                  <p className="font-medium text-black">{parseFloat(sale.areaSold.toString()).toLocaleString()} sq. ft.</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Base Sale Price</p>
                  <p className="font-medium text-amber-800">₹ {sale.baseSalePrice}/sq. ft.</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Final Amount</p>
                  <p className="font-medium text-amber-700">₹ {parseFloat(sale.finalAmount || "0").toLocaleString()}</p>
                </div>
              </div>
            </div>

            {/* Payment summary */}
            <div className="bg-white p-3 sm:p-4 rounded-md shadow-sm">
              <h3 className="flex items-center text-amber-700 text-sm sm:text-base font-medium mb-2 sm:mb-4">
                <span className="bg-amber-100 p-1 rounded-full mr-2">
                  <svg className="h-3 w-3 sm:h-4 sm:w-4 text-amber-500" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </span>
                PAYMENT SUMMARY
              </h3>

              <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm">
                <div>
                  <p className="text-gray-500">Total Payments</p>
                  <p className="font-medium text-green-600">₹ {totalPaid.toLocaleString()}</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Remaining Balance</p>
                  <p className="font-medium text-red-500">₹ {balanceDue.toLocaleString()}</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Payment Progress</p>
                  <div className="mt-1">
                    <Progress value={paymentPercentage} className="h-1.5 sm:h-2 bg-amber-100" />
                    <p className="text-[10px] sm:text-xs text-right mt-0.5 sm:mt-1">{Math.round(paymentPercentage)}%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right column - Payment history */}
          <div className="md:col-span-2">
            {/* Payment stats cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3 mb-4 sm:mb-6">
              {/* Total Paid card */}
              <div className="bg-white border-l-4 border-green-500 rounded-md shadow-sm p-3 sm:p-4">
                <h4 className="text-xs sm:text-sm text-gray-500 flex items-center">
                  <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 mr-1 text-green-600" />
                  Total Paid
                </h4>
                <div className="mt-1 sm:mt-2">
                  <p className="text-lg sm:text-xl font-bold text-green-600">₹ {totalPaid.toLocaleString()}</p>
                  <p className="text-[10px] sm:text-xs text-gray-500 mt-0.5 sm:mt-1">Across {payments?.length || 0} payments</p>
                </div>
              </div>

              {/* Balance Due card */}
              <div className="bg-white border-l-4 border-amber-500 rounded-md shadow-sm p-3 sm:p-4">
                <h4 className="text-xs sm:text-sm text-gray-500 flex items-center">
                  <Hourglass className="h-3 w-3 sm:h-4 sm:w-4 mr-1 text-amber-600" />
                  Balance Due
                </h4>
                <div className="mt-1 sm:mt-2">
                  <p className="text-lg sm:text-xl font-bold text-amber-600">₹ {balanceDue.toLocaleString()}</p>
                  <p className="text-[10px] sm:text-xs text-gray-500 mt-0.5 sm:mt-1">
                    {balanceDue > 0 ? "Remaining to be collected" : "Fully paid"}
                  </p>
                </div>
              </div>

              {/* Last Payment card */}
              <div className="bg-white border-l-4 border-blue-500 rounded-md shadow-sm p-3 sm:p-4">
                <h4 className="text-xs sm:text-sm text-gray-500 flex items-center">
                  <RotateCcw className="h-3 w-3 sm:h-4 sm:w-4 mr-1 text-blue-600" />
                  Last Payment
                </h4>
                <div className="mt-1 sm:mt-2">
                  {lastPayment ? (
                    <>
                      <p className="text-base sm:text-lg font-bold text-blue-600">
                        {format(new Date(lastPayment.paymentDate), "MMM dd, yyyy")}
                      </p>
                      <p className="text-[10px] sm:text-xs text-gray-500 mt-0.5 sm:mt-1">
                        {lastPayment.paymentType} (₹ {parseFloat(lastPayment.amount).toLocaleString()})
                      </p>
                    </>
                  ) : (
                    <p className="text-xs sm:text-sm text-gray-400">No payments recorded</p>
                  )}
                </div>
              </div>
            </div>

            {/* Payment history table */}
            <div className="bg-white rounded-md shadow-sm overflow-hidden">
              <div className="p-3 sm:p-4 bg-amber-50 border-b">
                <h3 className="text-sm sm:text-base font-medium text-amber-800">Payment History</h3>
              </div>
              
              {isLoading ? (
                <div className="flex items-center justify-center h-48">
                  <div className="animate-spin h-8 w-8 border-4 border-amber-500 border-t-transparent rounded-full"></div>
                </div>
              ) : !payments || payments.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  <p>No payment records found for this customer.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 text-gray-700 text-xs sm:text-sm">
                      <tr>
                        <th className="px-3 py-2 sm:px-4 sm:py-3 text-left font-medium">Date</th>
                        <th className="px-3 py-2 sm:px-4 sm:py-3 text-right font-medium">Amount</th>
                        <th className="px-3 py-2 sm:px-4 sm:py-3 text-left font-medium hidden sm:table-cell">Type</th>
                        <th className="px-3 py-2 sm:px-4 sm:py-3 text-left font-medium hidden sm:table-cell">Mode</th>
                        <th className="px-3 py-2 sm:px-4 sm:py-3 text-left font-medium hidden md:table-cell">Remarks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {payments.map((payment) => (
                        <tr key={payment.id} className="hover:bg-gray-50">
                          <td className="px-3 py-2 sm:px-4 sm:py-3 text-xs sm:text-sm">
                            {format(new Date(payment.paymentDate), "MMM dd, yyyy")}
                          </td>
                          <td className="px-3 py-2 sm:px-4 sm:py-3 text-xs sm:text-sm text-right font-medium">
                            ₹ {parseFloat(payment.amount).toLocaleString()}
                          </td>
                          <td className="px-3 py-2 sm:px-4 sm:py-3 text-xs sm:text-sm hidden sm:table-cell">
                            {payment.paymentType}
                          </td>
                          <td className="px-3 py-2 sm:px-4 sm:py-3 text-xs sm:text-sm hidden sm:table-cell">
                            {payment.paymentMode}
                          </td>
                          <td className="px-3 py-2 sm:px-4 sm:py-3 text-xs sm:text-sm text-gray-500 hidden md:table-cell">
                            {payment.remarks || "-"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}