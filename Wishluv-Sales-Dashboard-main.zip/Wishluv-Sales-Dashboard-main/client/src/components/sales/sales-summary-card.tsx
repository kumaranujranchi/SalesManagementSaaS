import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, Home, Award, CheckSquare } from "lucide-react";

interface SalesSummaryCardProps {
  title: string;
  value: string | number;
  description?: string;
  icon: "money" | "area" | "bookings" | "achievement";
  trend?: number;
  loading?: boolean;
}

export function SalesSummaryCard({
  title,
  value,
  description,
  icon,
  trend,
  loading = false,
}: SalesSummaryCardProps) {
  const renderIcon = () => {
    switch (icon) {
      case "money":
        return <DollarSign className="h-5 w-5 text-blue-600" />;
      case "area":
        return <Home className="h-5 w-5 text-green-600" />;
      case "bookings":
        return <CheckSquare className="h-5 w-5 text-blue-600" />;
      case "achievement":
        return <Award className="h-5 w-5 text-green-600" />;
      default:
        return null;
    }
  };

  const renderTrend = () => {
    if (trend === undefined) return null;
    
    return (
      <div className={`text-xs font-medium ${trend >= 0 ? "text-green-600" : "text-red-600"}`}>
        {trend >= 0 ? "+" : ""}{trend}%
      </div>
    );
  };

  return (
    <Card className="overflow-hidden border-blue-100">
      <CardHeader className="bg-blue-50 pb-2">
        <CardTitle className="text-sm font-medium text-blue-900 flex items-center gap-2">
          {renderIcon()}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        {loading ? (
          <div className="h-8 w-24 bg-gray-200 animate-pulse rounded"></div>
        ) : (
          <div className="text-2xl font-bold text-blue-950">{value}</div>
        )}
        {description && (
          <p className="text-xs text-blue-700 mt-1 flex items-center justify-between">
            {description}
            {renderTrend()}
          </p>
        )}
      </CardContent>
    </Card>
  );
}