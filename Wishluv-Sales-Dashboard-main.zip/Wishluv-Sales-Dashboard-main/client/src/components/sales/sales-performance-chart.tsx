import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from "recharts";
import { useIsMobile } from "@/hooks/use-mobile";

interface SalesPerformanceChartProps {
  salesData: any[];
  userSalesData: any[];
  title?: string;
}

export function SalesPerformanceChart({ 
  salesData, 
  userSalesData,
  title = "Sales Performance Comparison"
}: SalesPerformanceChartProps) {
  const isMobile = useIsMobile();
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (!salesData || !userSalesData) return;

    // Process data for chart
    const currentDate = new Date();
    const lastSixMonths: any[] = [];
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(currentDate);
      date.setMonth(currentDate.getMonth() - i);
      const monthName = date.toLocaleString('default', { month: 'short' });
      const year = date.getFullYear();
      const monthYear = `${monthName} ${year}`;
      const month = date.getMonth();
      const fullYear = date.getFullYear();

      // Filter sales data for this month and year
      const teamSalesThisMonth = salesData.filter(sale => {
        const saleDate = new Date(sale.bookingDate);
        return saleDate.getMonth() === month && saleDate.getFullYear() === fullYear;
      });
      
      // Filter user sales data for this month and year
      const userSalesThisMonth = userSalesData.filter(sale => {
        const saleDate = new Date(sale.bookingDate);
        return saleDate.getMonth() === month && saleDate.getFullYear() === fullYear;
      });
      
      // Calculate total sales volume for team and user
      const teamSalesVolume = teamSalesThisMonth.reduce((total, sale) => {
        return total + parseFloat(sale.areaSold || 0);
      }, 0);
      
      const userSalesVolume = userSalesThisMonth.reduce((total, sale) => {
        return total + parseFloat(sale.areaSold || 0);
      }, 0);
      
      lastSixMonths.push({
        name: monthName,
        Team: Math.round(teamSalesVolume),
        You: Math.round(userSalesVolume),
        monthYear
      });
    }
    
    setChartData(lastSixMonths);
  }, [salesData, userSalesData]);

  const colors = {
    Team: "#f59e0b",  // amber-500
    You: "#78350f"    // amber-900
  };

  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-amber-900">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="name" 
                  fontSize={12}
                  tick={{ fill: '#78350f' }}
                />
                <YAxis 
                  fontSize={12}
                  tick={{ fill: '#78350f' }}
                  label={{ 
                    value: 'Area (sq.ft.)', 
                    angle: -90, 
                    position: 'insideLeft',
                    style: { textAnchor: 'middle', fill: '#78350f' }
                  }}
                />
                <Tooltip 
                  formatter={(value: number) => [`${value.toLocaleString()} sq.ft.`, undefined]}
                  labelFormatter={(label) => {
                    const item = chartData.find(item => item.name === label);
                    return item ? item.monthYear : label;
                  }}
                />
                <Legend />
                <Bar dataKey="Team" fill={colors.Team}>
                  {chartData.map((_, index) => (
                    <Cell key={`cell-team-${index}`} fill={colors.Team} />
                  ))}
                </Bar>
                <Bar dataKey="You" fill={colors.You}>
                  {chartData.map((_, index) => (
                    <Cell key={`cell-you-${index}`} fill={colors.You} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground">No data available</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}