import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Skeleton } from "@/components/ui/skeleton";
import { Medal, Crown, Award, Trophy } from "lucide-react";

export function TeamLeaderboard() {
  const { user } = useAuth();

  // Fetch all sales data
  const { data: salesData, isLoading: isSalesLoading } = useQuery<any[]>({
    queryKey: ["/api/sales"],
    queryFn: async () => {
      const res = await fetch("/api/sales");
      if (!res.ok) {
        throw new Error("Failed to fetch sales data");
      }
      return res.json();
    },
  });

  // Fetch all users data
  const { data: usersData, isLoading: isUsersLoading } = useQuery<any[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await fetch("/api/users");
      if (!res.ok) {
        throw new Error("Failed to fetch users data");
      }
      return res.json();
    },
  });

  // If data is loading, show skeleton
  if (isSalesLoading || isUsersLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg text-amber-900">Team Leaderboard</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-5 w-36" />
                </div>
                <Skeleton className="h-5 w-20" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const calculateTeamMetrics = () => {
    // Filter out only sales users
    const salesUsers = usersData?.filter(u => 
      u.department === "Sales" && 
      u.status && 
      (u.designation === "Sales Executive" || u.designation === "Executive")
    ) || [];

    // Calculate total area sold by each user
    const userSales = salesUsers.map(salesUser => {
      const userSalesItems = salesData?.filter(sale => 
        sale.salesExecutiveId === salesUser.id
      ) || [];
      
      const totalAreaSold = userSalesItems.reduce((total, sale) => 
        total + parseFloat(sale.areaSold || 0), 0
      );
      
      const totalAmount = userSalesItems.reduce((total, sale) => 
        total + parseFloat(sale.finalAmount || 0), 0
      );
      
      return {
        id: salesUser.id,
        name: salesUser.fullName,
        imageUrl: salesUser.imageUrl,
        team: salesUser.team,
        totalAreaSold,
        totalAmount,
        salesCount: userSalesItems.length
      };
    });

    // Sort by total area sold (descending)
    return userSales.sort((a, b) => b.totalAreaSold - a.totalAreaSold).slice(0, 5);
  };

  const teamMetrics = calculateTeamMetrics();

  // Find current user's rank
  const currentUserRank = teamMetrics.findIndex(m => m.id === user?.id) + 1;

  const renderRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-5 w-5 text-amber-500" />;
      case 2:
        return <Medal className="h-5 w-5 text-gray-400" />;
      case 3:
        return <Medal className="h-5 w-5 text-amber-700" />;
      default:
        return <Award className="h-5 w-5 text-amber-600" />;
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-amber-900">Team Leaderboard</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {teamMetrics.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">No data available</p>
          ) : (
            teamMetrics.map((metric, index) => (
              <div 
                key={metric.id} 
                className={`flex items-center justify-between p-3 rounded-md ${
                  metric.id === user?.id 
                    ? "bg-amber-50 border border-amber-200" 
                    : "hover:bg-gray-50"
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <div className="h-10 w-10 rounded-full overflow-hidden bg-amber-100 flex items-center justify-center">
                      {metric.imageUrl ? (
                        <img 
                          src={metric.imageUrl} 
                          alt={metric.name} 
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span className="text-lg font-semibold text-amber-700">
                          {metric.name.charAt(0)}
                        </span>
                      )}
                    </div>
                    <div className="absolute -top-1 -left-1 bg-amber-100 rounded-full p-0.5">
                      {renderRankIcon(index + 1)}
                    </div>
                  </div>
                  <div>
                    <div className="font-medium text-amber-900">{metric.name}</div>
                    <div className="text-xs text-amber-700">{metric.team}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-amber-900">{metric.totalAreaSold.toLocaleString()} sq.ft.</div>
                  <div className="text-xs text-amber-700">{metric.salesCount} sales</div>
                </div>
              </div>
            ))
          )}
          
          {user && currentUserRank > 5 && (
            <div className="mt-2 p-3 bg-amber-50 rounded-md border border-amber-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-900 font-medium">
                    {currentUserRank}
                  </div>
                  <div className="font-medium text-amber-900">Your Rank</div>
                </div>
                <div className="text-amber-900 font-medium">Keep going! 💪</div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}