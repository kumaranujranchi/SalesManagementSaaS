import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { TabsContent, Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { 
  X, UserCircle, Home, Map, Calendar, IndianRupee, 
  FileText, CreditCard, PieChart, InfoIcon 
} from "lucide-react";
import { Sales } from "@shared/schema";
import { PieChart as RechartsChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

interface SalesDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedSale: Sales | null;
  projectsData?: any[];
}

export function SalesDetailsDialog({
  open,
  onOpenChange,
  selectedSale,
  projectsData = [],
}: SalesDetailsDialogProps) {
  const [activeTab, setActiveTab] = useState("details");
  const [totalPayments, setTotalPayments] = useState(0);
  const [remainingBalance, setRemainingBalance] = useState(0);

  // Fetch payment data for the sale
  const { data: paymentData } = useQuery<any[]>({
    queryKey: ["/api/payments", selectedSale?.id],
    queryFn: async () => {
      if (!selectedSale) return [];
      const res = await fetch(`/api/payments/${selectedSale.id}`);
      if (!res.ok) {
        throw new Error("Failed to fetch payment data");
      }
      return res.json();
    },
    enabled: !!selectedSale,
  });

  // Calculate total payments and remaining balance
  useEffect(() => {
    if (selectedSale && paymentData) {
      const total = paymentData.reduce(
        (sum, payment) => sum + parseFloat(payment.amount || "0"),
        0
      );
      setTotalPayments(total);
      
      const finalAmount = parseFloat(selectedSale.finalAmount || "0");
      setRemainingBalance(finalAmount - total);
    }
  }, [selectedSale, paymentData]);

  const getProjectName = (projectId: number) => {
    const project = projectsData.find((p) => p.id === projectId);
    return project ? project.name : "Unknown Project";
  };

  // Prepare chart data for payment types
  const getPaymentTypeChartData = () => {
    if (!paymentData || paymentData.length === 0) return [];
    
    // Count occurrences of each payment type
    const typeCounts: Record<string, number> = {};
    paymentData.forEach(payment => {
      const type = payment.paymentType || "Unknown";
      typeCounts[type] = (typeCounts[type] || 0) + parseFloat(payment.amount);
    });
    
    return Object.entries(typeCounts).map(([name, value]) => ({
      name,
      value,
    }));
  };
  
  const chartData = getPaymentTypeChartData();
  const COLORS = ['#f59e0b', '#d97706', '#b45309', '#92400e', '#78350f', '#fcd34d'];

  if (!selectedSale) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl text-amber-900">
              Sale Details
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="absolute right-4 top-4"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <Tabs
          defaultValue="details"
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="details" className="text-amber-900">
              <FileText className="h-4 w-4 mr-2" />
              Details
            </TabsTrigger>
            <TabsTrigger value="payments" className="text-amber-900">
              <CreditCard className="h-4 w-4 mr-2" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-amber-900">
              <PieChart className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Details Tab */}
          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Customer Information */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center">
                    <UserCircle className="h-4 w-4 mr-2 text-amber-600" />
                    Customer Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <Label className="text-xs text-muted-foreground">Name</Label>
                    <p className="font-medium">{selectedSale.customerName || "N/A"}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Mobile</Label>
                    <p className="font-medium">{selectedSale.customerMobile || "N/A"}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Email</Label>
                    <p className="font-medium">{selectedSale.customerEmail || "N/A"}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Address</Label>
                    <p className="font-medium">{selectedSale.customerAddress || "N/A"}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Property Details */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center">
                    <Home className="h-4 w-4 mr-2 text-amber-600" />
                    Property Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <Label className="text-xs text-muted-foreground">Project</Label>
                    <p className="font-medium">{getProjectName(selectedSale.projectId)}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Unit Type</Label>
                    <p className="font-medium">{selectedSale.unitType || "N/A"}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Unit Number</Label>
                    <p className="font-medium">{selectedSale.unitNumber || "N/A"}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Area (sq.ft.)</Label>
                    <p className="font-medium">{selectedSale.areaSold.toLocaleString()}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Booking Details */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-amber-600" />
                    Booking Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <Label className="text-xs text-muted-foreground">Booking Date</Label>
                    <p className="font-medium">
                      {format(new Date(selectedSale.bookingDate), "PPP")}
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Booking ID</Label>
                    <p className="font-medium">{selectedSale.bookingId || `BK-${selectedSale.id}`}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Agreement Status</Label>
                    <p className={`font-medium ${selectedSale.bookingDone === "Yes" ? "text-green-600" : "text-amber-600"}`}>
                      {selectedSale.bookingDone || "Not Specified"}
                      {selectedSale.bookingDone === "Yes" && selectedSale.agreementDate && (
                        <span className="block text-xs text-green-600">
                          Date: {format(new Date(selectedSale.agreementDate), "PPP")}
                        </span>
                      )}
                      {selectedSale.bookingDone === "No" && selectedSale.bookingData && (
                        <span className="block text-xs text-amber-600">
                          {selectedSale.bookingData}
                        </span>
                      )}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Summary */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center">
                    <IndianRupee className="h-4 w-4 mr-2 text-amber-600" />
                    Payment Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <Label className="text-xs text-muted-foreground">Booking Amount</Label>
                    <p className="font-medium">₹{parseFloat(selectedSale.bookingAmount || "0").toLocaleString()}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Final Amount</Label>
                    <p className="font-medium">₹{parseFloat(selectedSale.finalAmount || "0").toLocaleString()}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Total Payments</Label>
                    <p className="font-medium">₹{totalPayments.toLocaleString()}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Remaining Balance</Label>
                    <p className="font-medium text-amber-700">₹{remainingBalance.toLocaleString()}</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Additional Details */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center">
                  <InfoIcon className="h-4 w-4 mr-2 text-amber-600" />
                  Additional Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div>
                  <Label className="text-xs text-muted-foreground">Notes</Label>
                  <p className="text-sm mt-1">{selectedSale.notes || "No additional notes available."}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center">
                  <CreditCard className="h-4 w-4 mr-2 text-amber-600" />
                  Payment History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {paymentData?.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-muted-foreground">No payment records found</p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-amber-50">
                        <tr>
                          <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-amber-900 uppercase tracking-wider">
                            Date
                          </th>
                          <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-amber-900 uppercase tracking-wider">
                            Type
                          </th>
                          <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-amber-900 uppercase tracking-wider">
                            Mode
                          </th>
                          <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-amber-900 uppercase tracking-wider">
                            Amount
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {paymentData?.map((payment) => (
                          <tr key={payment.id}>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-amber-900">
                              {format(new Date(payment.paymentDate), "dd/MM/yyyy")}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-amber-900">
                              {payment.paymentType || "N/A"}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-amber-900">
                              {payment.paymentMode || "N/A"}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-right font-medium text-amber-900">
                              ₹{parseFloat(payment.amount).toLocaleString()}
                            </td>
                          </tr>
                        ))}
                        
                        {/* Total row */}
                        <tr className="bg-amber-50">
                          <td colSpan={3} className="px-4 py-3 whitespace-nowrap text-sm font-bold text-amber-900">
                            Total Paid
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-right font-bold text-amber-900">
                            ₹{totalPayments.toLocaleString()}
                          </td>
                        </tr>
                        
                        {/* Remaining Balance */}
                        <tr>
                          <td colSpan={3} className="px-4 py-3 whitespace-nowrap text-sm font-bold text-amber-900">
                            Remaining Balance
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-right font-bold text-amber-700">
                            ₹{remainingBalance.toLocaleString()}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center">
                    <PieChart className="h-4 w-4 mr-2 text-amber-600" />
                    Payment Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    {chartData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsChart>
                          <Pie
                            data={chartData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {chartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value: number) => [`₹${value.toLocaleString()}`, "Amount"]}
                          />
                        </RechartsChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <p className="text-muted-foreground">No payment data available</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center">
                    <Map className="h-4 w-4 mr-2 text-amber-600" />
                    Payment Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col justify-center h-[300px]">
                    <div className="mb-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-amber-900">Payment Progress</span>
                        <span className="text-sm font-medium text-amber-900">
                          {selectedSale.finalAmount && totalPayments 
                            ? `${Math.round((totalPayments / parseFloat(selectedSale.finalAmount)) * 100)}%` 
                            : "0%"}
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-amber-500 h-2.5 rounded-full" 
                          style={{ 
                            width: selectedSale.finalAmount && totalPayments 
                              ? `${Math.min(100, (totalPayments / parseFloat(selectedSale.finalAmount)) * 100)}%` 
                              : "0%" 
                          }}
                        ></div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-6">
                      <div className="bg-amber-50 p-4 rounded-md border border-amber-100">
                        <h4 className="text-sm font-medium text-amber-800 mb-2">Total Amount</h4>
                        <p className="text-2xl font-bold text-amber-900">
                          ₹{parseFloat(selectedSale.finalAmount || "0").toLocaleString()}
                        </p>
                      </div>
                      <div className="bg-amber-50 p-4 rounded-md border border-amber-100">
                        <h4 className="text-sm font-medium text-amber-800 mb-2">Amount Paid</h4>
                        <p className="text-2xl font-bold text-amber-900">
                          ₹{totalPayments.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}