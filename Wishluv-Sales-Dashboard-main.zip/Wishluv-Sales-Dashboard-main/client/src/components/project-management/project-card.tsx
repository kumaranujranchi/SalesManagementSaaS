import { CalendarIcon, Clock, CheckCircle2, Edit, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
  statusColor: string;
  onEdit: (project: Project) => void;
  onView: (project: Project) => void;
}

export function ProjectCard({ project, statusColor, onEdit, onView }: ProjectCardProps) {
  // Based on status, show appropriate icon
  const StatusIcon = () => {
    switch (project.status?.toLowerCase()) {
      case 'running':
        return <CalendarIcon className="h-3 w-3 mr-1 text-green-500" />;
      case 'on_hold':
        return <Clock className="h-3 w-3 mr-1 text-blue-500" />;
      case 'closed':
        return <CheckCircle2 className="h-3 w-3 mr-1 text-gray-500" />;
      default:
        return <CalendarIcon className="h-3 w-3 mr-1" />;
    }
  };

  return (
    <Card key={project.id} className="mb-3 overflow-hidden hover:shadow-md transition-shadow">
      {project.imageUrl && (
        <div className="w-full h-32 overflow-hidden">
          <img 
            src={project.imageUrl} 
            alt={project.name} 
            className="w-full h-full object-cover"
            onError={(e) => e.currentTarget.style.display = 'none'}
          />
        </div>
      )}
      <CardContent className={`p-3 ${!project.imageUrl ? `border-t-4 ${statusColor}` : ''}`}>
        <h4 className="font-medium text-lg">{project.name}</h4>
        <p className="text-sm text-neutral-500 truncate mt-1">{project.description}</p>
        <div className="flex items-center gap-2 mt-2">
          <span className={`text-xs px-2 py-1 rounded-full font-medium ${
            project.status?.toLowerCase() === 'running' ? 'bg-green-100 text-green-800' :
            project.status?.toLowerCase() === 'on_hold' ? 'bg-blue-100 text-blue-800' :
            'bg-gray-100 text-gray-800'
          }`}>
            {project.projectType}
          </span>
          <span className="text-xs bg-neutral-100 text-neutral-800 px-2 py-1 rounded-full">
            {project.location}
          </span>
        </div>
        <div className="flex justify-between items-center mt-3 pt-2 border-t border-gray-100">
          <span className="text-xs text-neutral-500 flex items-center">
            <StatusIcon />
            {project.deadline 
              ? new Date(project.deadline).toLocaleDateString() 
              : "No deadline"}
          </span>
          <div className="flex items-center gap-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-6 w-6"
              onClick={(e) => {
                e.stopPropagation();
                onEdit(project);
              }}
            >
              <Edit className="h-3 w-3 text-neutral-500" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-6 w-6"
              onClick={(e) => {
                e.stopPropagation();
                onView(project);
              }}
            >
              <Eye className="h-3 w-3 text-neutral-500" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}