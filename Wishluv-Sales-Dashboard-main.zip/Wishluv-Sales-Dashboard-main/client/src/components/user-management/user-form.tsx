import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Calendar, Target } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertUserSchema, InsertUser } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Radio Button Components to replace dropdowns
function DesignationRadio({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const designations = ["Admin", "Manager", "Executive", "Sales Representative"];
  return (
    <div className="flex flex-wrap gap-3">
      {designations.map((designation) => (
        <label key={designation} className="flex items-center space-x-2 cursor-pointer">
          <input
            type="radio"
            name="designation"
            value={designation}
            checked={value === designation}
            onChange={(e) => onChange(e.target.value)}
            className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
          />
          <span className="text-sm text-gray-700">{designation}</span>
        </label>
      ))}
    </div>
  );
}

function DepartmentRadio({ value, onChange, departments, loading }: { 
  value: string; 
  onChange: (value: string) => void; 
  departments: any[];
  loading: boolean;
}) {
  const defaultDepartments = ["HR", "Sales", "Marketing", "Development", "Finance"];
  const departmentList = !loading && departments && departments.length > 0 
    ? departments.map(d => d.name) 
    : defaultDepartments;
    
  return (
    <div className="flex flex-wrap gap-3">
      {departmentList.map((dept) => (
        <label key={dept} className="flex items-center space-x-2 cursor-pointer">
          <input
            type="radio"
            name="department"
            value={dept}
            checked={value === dept}
            onChange={(e) => onChange(e.target.value)}
            className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
          />
          <span className="text-sm text-gray-700">{dept}</span>
        </label>
      ))}
    </div>
  );
}

function TeamRadio({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const teams = ["Team Manish", "Team Kaustuv", "Team Awinash", "Special Projects"];
  return (
    <div className="flex flex-wrap gap-3">
      <label className="flex items-center space-x-2 cursor-pointer">
        <input
          type="radio"
          name="team"
          value=""
          checked={!value || value === "default"}
          onChange={() => onChange("")}
          className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
        />
        <span className="text-sm text-gray-700">No Team</span>
      </label>
      {teams.map((team) => (
        <label key={team} className="flex items-center space-x-2 cursor-pointer">
          <input
            type="radio"
            name="team"
            value={team}
            checked={value === team}
            onChange={(e) => onChange(e.target.value)}
            className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
          />
          <span className="text-sm text-gray-700">{team}</span>
        </label>
      ))}
    </div>
  );
}

function RoleRadio({ value, onChange, roles, loading }: { 
  value: string; 
  onChange: (value: string) => void; 
  roles: any[];
  loading: boolean;
}) {
  const defaultRoles = ["Super Admin", "Admin", "Manager", "User"];
  const roleList = !loading && roles && roles.length > 0 
    ? roles.map(r => r.name) 
    : defaultRoles;
    
  return (
    <div className="flex flex-wrap gap-3">
      {roleList.map((role) => (
        <label key={role} className="flex items-center space-x-2 cursor-pointer">
          <input
            type="radio"
            name="role"
            value={role}
            checked={value === role}
            onChange={(e) => onChange(e.target.value)}
            className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
          />
          <span className="text-sm text-gray-700">{role}</span>
        </label>
      ))}
    </div>
  );
}

function ReportingManagerRadio({ value, onChange, users, loading }: { 
  value: number | null | undefined; 
  onChange: (value: number | undefined) => void; 
  users: any[];
  loading: boolean;
}) {
  const handleChange = (selectedValue: string) => {
    if (selectedValue === "none") {
      onChange(undefined);
    } else {
      onChange(parseInt(selectedValue));
    }
  };
    
  return (
    <div className="flex flex-wrap gap-3">
      <label className="flex items-center space-x-2 cursor-pointer">
        <input
          type="radio"
          name="reportingManager"
          value="none"
          checked={!value}
          onChange={() => handleChange("none")}
          className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
        />
        <span className="text-sm text-gray-700">No Manager</span>
      </label>
      
      {loading ? (
        <span className="text-sm text-gray-500">Loading managers...</span>
      ) : users && users.length > 0 ? (
        users.map((user) => (
          <label key={user.id} className="flex items-center space-x-2 cursor-pointer">
            <input
              type="radio"
              name="reportingManager"
              value={user.id.toString()}
              checked={value === user.id}
              onChange={(e) => handleChange(e.target.value)}
              className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
            />
            <span className="text-sm text-gray-700">{user.fullName}</span>
          </label>
        ))
      ) : (
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="radio"
            name="reportingManager"
            value="1"
            checked={value === 1}
            onChange={(e) => handleChange(e.target.value)}
            className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
          />
          <span className="text-sm text-gray-700">System Administrator</span>
        </label>
      )}
    </div>
  );
}

import { Switch } from "@/components/ui/switch";

// Extend the user schema for the form and make fields required
const userFormSchema = insertUserSchema
  .omit({
    // Remove target-related fields - these are managed separately
    joiningDate: true,
    monthlyTarget: true,
  })
  .extend({
    fullName: z.string().min(1, "Full name is required"),
    email: z.string().email("Invalid email format").min(1, "Email is required"),
    phone: z.string().min(1, "Phone number is required"),
    designation: z.string().min(1, "Designation is required"),
    department: z.string().min(1, "Department is required"),
    role: z.string().min(1, "Role is required"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
    imageUrl: z.string().min(1, "Image URL is required"),
    // Username is required but will be auto-generated
    username: z.string().optional(),
    // Employee ID is optional
    employeeId: z.string().optional(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

type UserFormValues = z.infer<typeof userFormSchema>;

interface UserFormProps {
  onSuccess?: () => void;
  user?: any; // The user object for editing mode
}

export function UserForm({ onSuccess, user }: UserFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isGeneratingPassword, setIsGeneratingPassword] = useState(false);
  const isEditMode = !!user;
  
  const { data: departments, isLoading: departmentsLoading } = useQuery({
    queryKey: ["/api/departments"],
  });
  
  const { data: roles, isLoading: rolesLoading } = useQuery({
    queryKey: ["/api/roles"],
  });
  
  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ["/api/users"],
  });
  
  // Determine default values based on whether we're editing or creating
  const defaultValues: Partial<UserFormValues> = isEditMode 
    ? {
        fullName: user.fullName || "",
        email: user.email || "",
        phone: user.phone || "",
        designation: user.designation || "Admin",
        department: user.department || "HR",
        reportingManager: user.reportingManager || "",
        reportingManagerId: user.reportingManagerId,
        team: user.team || "",
        imageUrl: user.imageUrl || "",
        role: user.role || "Super Admin",
        // Don't populate password fields when editing
        password: "", 
        confirmPassword: "",
        status: user.status ?? true,
        employeeId: user.employeeId || "",
        username: user.username || "",

      }
    : {
        fullName: "",
        email: "",
        phone: "",
        designation: "Admin",
        department: "HR",
        reportingManager: "", // Keep for backward compatibility
        reportingManagerId: undefined, // New field using IDs
        team: "",
        imageUrl: "",
        role: "Super Admin",
        password: "",
        confirmPassword: "",
        status: true,
        employeeId: "",
        username: "", // This will be auto-generated from email
      };

  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues,
  });

  const createUser = useMutation({
    mutationFn: async (data: InsertUser) => {
      const res = await apiRequest("POST", "/api/register", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "User created",
        description: "The user has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      form.reset(defaultValues);
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create user.",
        variant: "destructive",
      });
    },
  });

  const generatePassword = () => {
    setIsGeneratingPassword(true);
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    let password = "";
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    form.setValue("password", password);
    form.setValue("confirmPassword", password);
    
    setTimeout(() => {
      setIsGeneratingPassword(false);
    }, 500);
  };

  // Function to generate username from email
  const generateUsernameFromEmail = (email: string) => {
    if (!email) return "";
    const emailParts = email.split('@');
    // Remove any special characters to create a valid username
    return emailParts[0].replace(/[^a-zA-Z0-9]/g, '');
  };

  // When email changes, update the username field
  useEffect(() => {
    const email = form.watch("email");
    if (email) {
      const username = generateUsernameFromEmail(email);
      form.setValue("username", username);
    }
  }, [form]);

  // Add mutation for updating a user
  const updateUser = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await apiRequest("PUT", `/api/users/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "User updated",
        description: "The user has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update user.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: UserFormValues) => {
    const { confirmPassword, ...userData } = data;
    
    // Make sure username is always set as a string
    userData.username = userData.username || generateUsernameFromEmail(userData.email);
    
    // If edit mode and password is empty, don't include it in the update data
    const finalData = {
      ...userData,
      ...(isEditMode && (!userData.password || userData.password.trim() === '') 
          ? { password: undefined } 
          : {})
    };
    
    // If no employee ID is provided, generate a unique one based on timestamp and random digits
    if (!finalData.employeeId || finalData.employeeId.trim() === '') {
      const timestamp = new Date().getTime().toString().slice(-6);
      const randomDigits = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      finalData.employeeId = `EMP-${timestamp}-${randomDigits}`;
    }
    
    // Remove target-related fields that are managed separately
    const { joiningDate, monthlyTarget, ...cleanData } = finalData as any;
    
    // For debugging
    console.log('Submitting user data:', cleanData);
    
    if (isEditMode && user.id) {
      updateUser.mutate({ id: user.id, data: cleanData });
    } else {
      createUser.mutate(cleanData as InsertUser);
    }
  };

  return (
    <Card className="bg-primary/10">
      <CardHeader>
        <CardTitle>{isEditMode ? "Edit Employee" : "Add New Employee"}</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Basic Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter full name" 
                          className="bg-primary/30 border-0 focus:ring-2 focus:ring-secondary" 
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="employeeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Employee ID</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter employee ID" 
                          className="bg-primary/30 border-0 focus:ring-2 focus:ring-secondary" 
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="Enter email address" 
                          className="bg-primary/30 border-0 focus:ring-2 focus:ring-secondary" 
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input 
                          type="tel" 
                          placeholder="Enter phone number" 
                          className="bg-primary/30 border-0 focus:ring-2 focus:ring-secondary" 
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Hidden username field */}
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <input type="hidden" {...field} />
              )}
            />
            

            
            {/* Role & Department Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Role & Department</h3>
              
              <FormField
                control={form.control}
                name="designation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Designation</FormLabel>
                    <FormControl>
                      <DesignationRadio 
                        value={field.value} 
                        onChange={field.onChange} 
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <FormControl>
                      <DepartmentRadio 
                        value={field.value} 
                        onChange={field.onChange}
                        departments={Array.isArray(departments) ? departments : []}
                        loading={departmentsLoading}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              {form.watch("department") === "Sales" && (
                <FormField
                  control={form.control}
                  name="team"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team</FormLabel>
                      <FormControl>
                        <TeamRadio 
                          value={field.value || ""} 
                          onChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}
              
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <FormControl>
                      <RoleRadio 
                        value={field.value} 
                        onChange={field.onChange}
                        roles={Array.isArray(roles) ? roles : []}
                        loading={rolesLoading}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="reportingManagerId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reporting Manager</FormLabel>
                    <FormControl>
                      <ReportingManagerRadio 
                        value={field.value ?? undefined} 
                        onChange={field.onChange}
                        users={Array.isArray(users) ? users : []}
                        loading={usersLoading}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            {/* Profile Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Profile Information</h3>
              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>User Image URL</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter profile image URL" 
                        className="bg-primary/30 border-0 focus:ring-2 focus:ring-secondary" 
                        {...field} 
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            
            {/* Password Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Security Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <div className="flex gap-2">
                        <FormControl>
                          <Input
                            type="password"
                            placeholder={isEditMode ? "Leave blank to keep current" : "Enter password"}
                            className="bg-primary/30 border-0 focus:ring-2 focus:ring-secondary"
                            {...field}
                          />
                        </FormControl>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={generatePassword}
                          disabled={isGeneratingPassword}
                          className="shrink-0"
                        >
                          {isGeneratingPassword ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            "Generate"
                          )}
                        </Button>
                      </div>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder={isEditMode ? "Leave blank to keep current" : "Confirm password"}
                          className="bg-primary/30 border-0 focus:ring-2 focus:ring-secondary"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <div className="flex flex-row items-center justify-between rounded-lg border p-3 bg-primary/30">
                    <div className="space-y-0.5">
                      <FormLabel>Status</FormLabel>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value === true}
                        onCheckedChange={(checked) => field.onChange(checked)}
                      />
                    </FormControl>
                  </div>
                </FormItem>
              )}
            />


            
            <div className="md:col-span-2">
              <Button 
                type="submit" 
                className="w-full md:w-auto px-6 py-2 bg-orange-500 hover:bg-orange-600 text-white font-medium rounded-md transition-all"
                disabled={isEditMode ? updateUser.isPending : createUser.isPending}
              >
                {isEditMode ? (
                  updateUser.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Employee"
                  )
                ) : (
                  createUser.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create Employee"
                  )
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
