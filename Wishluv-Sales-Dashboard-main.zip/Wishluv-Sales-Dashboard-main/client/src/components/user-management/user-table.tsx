import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Eye, Edit, Ban, Trash2, Check, Search, Loader2, ChevronDown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { PermissionButton } from "@/components/ui/permission-button";
import { PermissionGuard } from "@/components/ui/permission-guard";
import { usePermissions } from "@/hooks/use-permissions";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { UserForm } from "./user-form";

// Radio Button Filter Component - Simple and reliable
function RoleFilter({ 
  value, 
  onChange, 
  className = "" 
}: {
  value: string;
  onChange: (value: string) => void;
  className?: string;
}) {
  const roles = [
    { value: "All", label: "All" },
    { value: "Super Admin", label: "Super Admin" },
    { value: "Admin", label: "Admin" },
    { value: "Manager", label: "Manager" },
    { value: "Sales Representative", label: "Sales Representative" }
  ];

  return (
    <div className={`flex flex-wrap gap-3 ${className}`}>
      {roles.map((role) => (
        <label
          key={role.value}
          className="flex items-center space-x-2 cursor-pointer"
        >
          <input
            type="radio"
            name="roleFilter"
            value={role.value}
            checked={value === role.value}
            onChange={(e) => onChange(e.target.value)}
            className="w-4 h-4 text-primary border-gray-300 focus:ring-primary focus:ring-2"
          />
          <span className="text-sm text-gray-700 hover:text-gray-900">
            {role.label}
          </span>
        </label>
      ))}
    </div>
  );
}

export function UserTable() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  
  const itemsPerPage = 10;
  
  const { data: users, isLoading, error } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });
  
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      await apiRequest("DELETE", `/api/users/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "User deleted",
        description: "The user has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setShowDeleteDialog(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete user.",
        variant: "destructive",
      });
    },
  });
  
  const updateUserStatusMutation = useMutation({
    mutationFn: async ({ userId, status }: { userId: number; status: boolean }) => {
      await apiRequest("PUT", `/api/users/${userId}`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Status updated",
        description: `The user has been ${selectedUser?.status ? 'deactivated' : 'activated'}.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setShowStatusDialog(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update user status.",
        variant: "destructive",
      });
    },
  });
  
  // Filter users by search term and role
  const filteredUsers = users
    ? users.filter(user => 
        (user.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
         user.email?.toLowerCase().includes(searchTerm.toLowerCase())) &&
        (roleFilter === "All" || user.role === roleFilter)
      )
    : [];
  
  // Get current page of data
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentUsers = filteredUsers.slice(indexOfFirstItem, indexOfLastItem);
  
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
  
  const handleDelete = (user: User) => {
    setSelectedUser(user);
    setShowDeleteDialog(true);
  };
  
  const confirmDelete = () => {
    if (selectedUser) {
      deleteUserMutation.mutate(selectedUser.id);
    }
  };
  
  const handleStatusChange = (user: User) => {
    setSelectedUser(user);
    setShowStatusDialog(true);
  };
  
  const confirmStatusChange = () => {
    if (selectedUser) {
      updateUserStatusMutation.mutate({ 
        userId: selectedUser.id, 
        status: !selectedUser.status 
      });
    }
  };
  
  // Handle viewing user details
  const handleView = (user: User) => {
    setSelectedUser(user);
    setShowViewDialog(true);
  };
  
  // Handle editing user
  const handleEdit = (user: User) => {
    setSelectedUser(user);
    setShowEditDialog(true);
  };
  
  return (
    <>
      <Card className="bg-white rounded-lg shadow overflow-hidden">
        <CardHeader className="pb-4">
          <CardTitle>Existing Employees</CardTitle>
          
          <div className="flex flex-col md:flex-row justify-between mt-4">
            <div className="w-full md:w-1/3 mb-4 md:mb-0">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search employees..."
                  className="w-full pl-10 pr-4 py-2 rounded-md bg-primary/20 border-0 focus:ring-2 focus:ring-secondary"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-neutral-500" />
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <span className="text-sm font-medium text-neutral-700">Filter by Role:</span>
              <RoleFilter
                value={roleFilter}
                onChange={setRoleFilter}
                className="mt-2"
              />
            </div>
          </div>
        </CardHeader>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-primary/50">
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Role</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Department</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Manager</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-neutral-200">
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center">
                    Loading employees...
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center text-red-500">
                    Failed to load employees
                  </td>
                </tr>
              ) : currentUsers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center">
                    No employees found
                  </td>
                </tr>
              ) : (
                currentUsers.map((user) => (
                  <tr key={user.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-neutral-800">{user.fullName}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-neutral-600">{user.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-neutral-600">{user.role}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-neutral-600">{user.department}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-neutral-600">{user.reportingManager}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        user.status
                          ? "bg-green-100 text-green-800"
                          : "bg-neutral-100 text-neutral-800"
                      }`}>
                        {user.status ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-1">
                      <PermissionButton 
                        resource="user"
                        action="view"
                        variant="ghost" 
                        size="sm" 
                        className="bg-primary/80 text-neutral-800 rounded-md text-xs h-7"
                        onClick={() => handleView(user)}
                      >
                        <Eye className="h-3 w-3 mr-1" /> View
                      </PermissionButton>
                      <PermissionButton 
                        resource="user"
                        action="edit"
                        variant="ghost" 
                        size="sm" 
                        className="bg-yellow-400/80 text-neutral-800 rounded-md text-xs h-7"
                        onClick={() => handleEdit(user)}
                      >
                        <Edit className="h-3 w-3 mr-1" /> Edit
                      </PermissionButton>
                      
                      <PermissionButton 
                        resource="user"
                        action="edit"
                        variant="ghost" 
                        size="sm" 
                        className={`${
                          user.status 
                            ? "bg-red-500/80 text-white" 
                            : "bg-green-500/80 text-white"
                        } rounded-md text-xs h-7`}
                        onClick={() => handleStatusChange(user)}
                      >
                        {user.status ? (
                          <>
                            <Ban className="h-3 w-3 mr-1" /> Deactivate
                          </>
                        ) : (
                          <>
                            <Check className="h-3 w-3 mr-1" /> Activate
                          </>
                        )}
                      </PermissionButton>
                      
                      <PermissionButton 
                        resource="user"
                        action="delete"
                        variant="ghost" 
                        size="sm" 
                        className="bg-red-600 text-white rounded-md text-xs h-7"
                        onClick={() => handleDelete(user)}
                      >
                        <Trash2 className="h-3 w-3 mr-1" /> Delete
                      </PermissionButton>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        
        <CardFooter className="flex items-center justify-between border-t border-neutral-200 p-4">
          <div className="text-sm text-neutral-600">
            Showing {indexOfFirstItem + 1} to {Math.min(indexOfLastItem, filteredUsers.length)} of {filteredUsers.length} entries
          </div>
          {totalPages > 1 && (
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-3 py-1 bg-primary/80 text-neutral-800 rounded-md text-sm"
              >
                Previous
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-input hover:bg-accent hover:text-accent-foreground h-9 px-3 py-1 rounded-md text-sm bg-[#3a9aff] text-[#262626]"
              >
                Next
              </Button>
            </div>
          )}
        </CardFooter>
      </Card>
      
      {/* Delete User Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete {selectedUser?.fullName}'s account
              and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 text-white hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Change Status Confirmation Dialog */}
      <AlertDialog open={showStatusDialog} onOpenChange={setShowStatusDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Status Change</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to {selectedUser?.status ? 'deactivate' : 'activate'} {selectedUser?.fullName}'s account?
              {selectedUser?.status 
                ? " This will prevent them from accessing the system." 
                : " This will allow them to access the system again."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmStatusChange} 
              className={selectedUser?.status 
                ? "bg-red-600 text-white hover:bg-red-700" 
                : "bg-green-600 text-white hover:bg-green-700"
              }
            >
              {selectedUser?.status ? 'Deactivate' : 'Activate'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* View User Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription>
              Detailed information about {selectedUser?.fullName}
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <ScrollArea className="h-[60vh] md:h-auto md:max-h-[500px] p-4">
              <div className="space-y-4">
                <div className="flex items-center justify-center mb-6">
                  {selectedUser.imageUrl ? (
                    <img 
                      src={selectedUser.imageUrl} 
                      alt={selectedUser.fullName || ""} 
                      className="w-24 h-24 rounded-full object-cover border-4 border-primary/20" 
                    />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center text-2xl font-bold text-primary">
                      {selectedUser.fullName?.charAt(0) || "U"}
                    </div>
                  )}
                </div>
              
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Full Name</h3>
                    <p className="text-base font-medium">{selectedUser.fullName}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Email</h3>
                    <p className="text-base">{selectedUser.email}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Role</h3>
                    <p className="text-base">{selectedUser.role}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Department</h3>
                    <p className="text-base">{selectedUser.department || "Not assigned"}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Designation</h3>
                    <p className="text-base">{selectedUser.designation || "Not assigned"}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Phone</h3>
                    <p className="text-base">{selectedUser.phone || "Not provided"}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Reporting Manager</h3>
                    <p className="text-base">{selectedUser.reportingManager || "Not assigned"}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Team</h3>
                    <p className="text-base">{selectedUser.team || "Not assigned"}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Employee ID</h3>
                    <p className="text-base">{selectedUser.employeeId || "Not assigned"}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Status</h3>
                    <p className={`text-base font-medium ${selectedUser.status ? "text-green-600" : "text-red-600"}`}>
                      {selectedUser.status ? "Active" : "Inactive"}
                    </p>
                  </div>
                </div>
              </div>
            </ScrollArea>
          )}
          
          <DialogFooter>
            <Button onClick={() => setShowViewDialog(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-5xl max-h-[95vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              Update information for {selectedUser?.fullName}
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto px-1">
            {selectedUser && (
              <UserForm 
                user={selectedUser} 
                onSuccess={() => {
                  setShowEditDialog(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/users"] });
                  toast({
                    title: "User updated",
                    description: "User information has been successfully updated.",
                  });
                }} 
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
