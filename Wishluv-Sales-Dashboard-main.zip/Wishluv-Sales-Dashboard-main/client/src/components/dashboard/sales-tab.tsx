import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  FileText, 
  Search, 
  Filter, 
  IndianRupee,
  Eye,
  CalendarRange, 
  SquareIcon,
  FileBarChart
} from "lucide-react";
import { Sales, Project } from "@shared/schema";

// Extended Sales type for UI display
interface EnhancedSale extends Sales {
  customerType?: string;
  pricePerSqFt?: number;
}

// Card component for sales stats
function SalesStatsCard({
  icon,
  title,
  value,
  description,
  bgClass = "bg-blue-50",
  textClass = "text-blue-900",
  iconClass = "text-blue-500"
}: {
  icon: React.ReactNode;
  title: string;
  value: string | number;
  description: string;
  bgClass?: string;
  textClass?: string;
  iconClass?: string;
}) {
  return (
    <Card className="border-0 shadow-sm overflow-hidden h-full">
      <CardHeader className={`pb-2 ${bgClass} px-3 md:px-4 py-2 md:py-3`}>
        <CardTitle className="text-xs md:text-sm font-medium flex items-center gap-2">
          <span className={`${iconClass} flex-shrink-0`}>{icon}</span>
          <span className={`${textClass} truncate`}>{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 md:p-4">
        <div className="text-lg md:text-xl lg:text-2xl font-bold break-words">{value}</div>
        <p className="text-xs text-gray-500 mt-1 line-clamp-2">{description}</p>
      </CardContent>
    </Card>
  );
}

// Main Sales Tab Component
export function SalesTab() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("all-sales");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filter, setFilter] = useState<boolean>(false);

  // Fetch user's sales data
  const { data: salesData, isLoading } = useQuery<Sales[]>({
    queryKey: ["/api/sales/user"],
    queryFn: async () => {
      const res = await fetch("/api/sales/user");
      if (!res.ok) throw new Error("Failed to fetch sales data");
      return res.json();
    }
  });

  // Fetch project data for lookups
  const { data: projectsData } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const res = await fetch("/api/projects");
      if (!res.ok) throw new Error("Failed to fetch projects");
      return res.json();
    }
  });

  // Calculate summary statistics
  const totalSalesCount = salesData?.length || 0;
  
  // Current month sales
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const thisMonthSales = salesData?.filter(sale => {
    const saleDate = new Date(sale.bookingDate);
    return saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear;
  }) || [];
  
  // Total area sold
  const totalAreaSold = salesData?.reduce((total, sale) => 
    total + parseFloat(sale.areaSold.toString() || "0"), 0) || 0;
  
  // Total revenue
  const totalRevenue = salesData?.reduce((total, sale) => 
    total + parseFloat(sale.finalAmount?.toString() || "0"), 0) || 0;
  
  // Filter sales based on search and enhance with additional UI properties
  const filteredSales: EnhancedSale[] = salesData?.filter(sale => {
    if (!searchQuery) return true;
    
    const searchLower = searchQuery.toLowerCase();
    const customerName = (sale.customerName || "").toLowerCase();
    const project = projectsData?.find(p => p.id === sale.projectId)?.name.toLowerCase() || "";
    
    return customerName.includes(searchLower) || project.includes(searchLower);
  }).map(sale => ({
    ...sale,
    // Add UI helper properties
    customerType: sale.customerName?.includes("Premium") ? "Premium" : undefined,
    pricePerSqFt: sale.baseSalePrice ? parseFloat(sale.baseSalePrice) : undefined
  })) || [];

  // Handle Payment Button Click
  const handlePaymentClick = (sale: Sales) => {
    // Will be implemented later to show payment dialog
    console.log("Payment clicked for:", sale);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-amber-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {/* Total Sales Card */}
        <SalesStatsCard
          icon={<FileBarChart className="h-5 w-5" />}
          title="Total Sales"
          value={totalSalesCount}
          description="Across filtered period"
          bgClass="bg-slate-50"
          textClass="text-slate-700"
          iconClass="text-blue-500"
        />
        
        {/* This Month Card */}
        <SalesStatsCard
          icon={<CalendarRange className="h-5 w-5" />}
          title="This Month"
          value={thisMonthSales.length}
          description={`Sales for ${format(new Date(), "MMM yyyy")}`}
          bgClass="bg-green-50"
          textClass="text-green-700"
          iconClass="text-green-500"
        />
        
        {/* Total Area Sold Card */}
        <SalesStatsCard
          icon={<SquareIcon className="h-5 w-5" />}
          title="Total Area Sold"
          value={totalAreaSold.toLocaleString()}
          description="Square feet coverage"
          bgClass="bg-amber-50"
          textClass="text-amber-700"
          iconClass="text-amber-500"
        />
        
        {/* Total Revenue Card */}
        <SalesStatsCard
          icon={<IndianRupee className="h-5 w-5" />}
          title="Total Revenue"
          value={totalRevenue.toLocaleString()}
          description="Final amount from sales"
          bgClass="bg-purple-50"
          textClass="text-purple-700"
          iconClass="text-purple-500"
        />
      </div>
      
      {/* Tabs for filtering */}
      <div className="flex border-b">
        <button
          onClick={() => setActiveTab("all-sales")}
          className={`px-4 py-2 font-medium text-sm ${activeTab === "all-sales" 
            ? "border-b-2 border-amber-500 text-amber-900" 
            : "text-gray-500 hover:text-gray-700"}`}
        >
          All Sales
        </button>
        <button
          onClick={() => setActiveTab("this-month")}
          className={`px-4 py-2 font-medium text-sm ${activeTab === "this-month" 
            ? "border-b-2 border-amber-500 text-amber-900" 
            : "text-gray-500 hover:text-gray-700"}`}
        >
          This Month
        </button>
        <button
          onClick={() => setActiveTab("this-year")}
          className={`px-4 py-2 font-medium text-sm ${activeTab === "this-year" 
            ? "border-b-2 border-amber-500 text-amber-900" 
            : "text-gray-500 hover:text-gray-700"}`}
        >
          This Year
        </button>
        
        <div className="ml-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setFilter(!filter)}
            className="text-amber-700 border-amber-300 hover:bg-amber-50"
          >
            <Filter className="h-4 w-4 mr-1" />
            Filter
          </Button>
        </div>
      </div>
      
      {/* Sales Table */}
      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Booking Date</TableHead>
              <TableHead>Project</TableHead>
              <TableHead className="hidden md:table-cell">Sales Executive</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Agreement Status</TableHead>
              <TableHead className="hidden md:table-cell">Area (sq. ft.)</TableHead>
              <TableHead className="hidden sm:table-cell">BSP (₹ per sq. ft.)</TableHead>
              <TableHead>Final Amount</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {!filteredSales || filteredSales.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                  No sales found
                </TableCell>
              </TableRow>
            ) : (
              filteredSales.map((sale) => (
                <TableRow key={sale.id}>
                  <TableCell>
                    {format(new Date(sale.bookingDate), "MMM dd, yyyy")}
                  </TableCell>
                  <TableCell>
                    {projectsData?.find((p) => p.id === sale.projectId)?.name || "Unknown"}
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    {user?.fullName || "Unknown"}
                  </TableCell>
                  <TableCell>
                    {sale.customerName || "N/A"}
                    {sale.customerType === "Premium" && (
                      <span className="ml-2 inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        ⭐
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className={`inline-flex justify-center items-center w-14 px-3 py-1 rounded-md text-xs font-medium text-white ${
                      sale.bookingDone === "Yes" 
                        ? "bg-green-500" 
                        : "bg-red-500"
                    }`}>
                      {sale.bookingDone || "No"}
                    </span>
                    {sale.bookingDone === "Yes" && sale.agreementDate && (
                      <div className="mt-1 text-[10px] text-green-600">
                        {format(new Date(sale.agreementDate), "MMM dd, yyyy")}
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    {parseFloat(sale.areaSold.toString()).toLocaleString()}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    ₹{sale.pricePerSqFt?.toLocaleString() || "N/A"}
                  </TableCell>
                  <TableCell className="font-semibold">
                    ₹{parseFloat(sale.finalAmount || "0").toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handlePaymentClick(sale)}
                      className="h-8 text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                    >
                      Payment
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}