import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { Activity, Project, Sales, User } from "@shared/schema";

interface CalendarDay {
  date: number;
  isCurrentMonth: boolean;
  isToday: boolean;
  activities?: string[];
}

export function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [hoveredDay, setHoveredDay] = useState<number | null>(null);
  
  // Fetch all the data we need to populate the calendar
  const { data: activities = [], isLoading: isLoadingActivities } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });
  
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });
  
  const { data: users = [], isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });
  
  const { data: sales = [], isLoading: isLoadingSales } = useQuery<Sales[]>({
    queryKey: ["/api/sales"],
  });
  
  // Determine if any data is still loading
  const isLoading = isLoadingActivities || isLoadingProjects || isLoadingUsers || isLoadingSales;
  
  // Go to previous month
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  // Go to next month
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };
  
  // Format month and year
  const formatMonthYear = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };
  
  // Generate activities map based on real data
  const activityMap = useMemo(() => {
    const map: Record<string, string[]> = {};
    
    // Function to get user's name by ID
    const getUserName = (userId: number): string => {
      const user = users.find(u => u.id === userId);
      return user ? (user.fullName || user.username) : 'Unknown User';
    };
    
    // Process activities
    activities.forEach(activity => {
      if (!activity.timestamp) return;
      
      try {
        const date = new Date(activity.timestamp);
        const day = date.getDate();
        const month = date.getMonth();
        const year = date.getFullYear();
        
        // Create key in format "YYYY-MM-DD"
        const key = `${year}-${month}-${day}`;
        
        if (!map[key]) {
          map[key] = [];
        }
        
        // Add activity description
        map[key].push(activity.description);
      } catch (error) {
        // Skip invalid dates
      }
    });
    
    // Process projects (project added)
    projects.forEach(project => {
      if (!project.createdAt) return;
      
      try {
        const date = new Date(project.createdAt);
        const day = date.getDate();
        const month = date.getMonth();
        const year = date.getFullYear();
        
        // Create key in format "YYYY-MM-DD"
        const key = `${year}-${month}-${day}`;
        
        if (!map[key]) {
          map[key] = [];
        }
        
        const userName = getUserName(project.createdBy);
        map[key].push(`Project Added: ${project.name} by ${userName}`);
      } catch (error) {
        // Skip invalid dates
      }
    });
    
    // Process sales
    sales.forEach(sale => {
      if (!sale.createdAt) return;
      
      try {
        const date = new Date(sale.createdAt);
        const day = date.getDate();
        const month = date.getMonth();
        const year = date.getFullYear();
        
        // Create key in format "YYYY-MM-DD"
        const key = `${year}-${month}-${day}`;
        
        if (!map[key]) {
          map[key] = [];
        }
        
        const executiveName = getUserName(sale.salesExecutiveId);
        map[key].push(`Sales Made: ${sale.bookingAmount} by ${executiveName}`);
      } catch (error) {
        // Skip invalid dates
      }
    });
    
    return map;
  }, [activities, projects, users, sales]);
  
  // Generate days for the calendar
  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    // First day of the month
    const firstDay = new Date(year, month, 1);
    // Get the day of the week (0 = Sunday, 1 = Monday, etc.)
    let firstDayOfWeek = firstDay.getDay();
    // Adjust to make Monday the first day (0)
    firstDayOfWeek = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1;
    
    // Last day of the month
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    
    // Get previous month's last days to fill the first week
    const prevMonth = new Date(year, month, 0);
    const prevMonthDays = prevMonth.getDate();
    
    const today = new Date();
    const isCurrentMonthAndYear = today.getMonth() === month && today.getFullYear() === year;
    
    const days: CalendarDay[] = [];
    
    // Add days from previous month
    for (let i = 1; i <= firstDayOfWeek; i++) {
      days.push({
        date: prevMonthDays - firstDayOfWeek + i,
        isCurrentMonth: false,
        isToday: false
      });
    }
    
    // Add days from current month
    for (let i = 1; i <= daysInMonth; i++) {
      // Get activities for this day
      const key = `${year}-${month}-${i}`;
      const dayActivities = activityMap[key] || [];
      
      days.push({
        date: i,
        isCurrentMonth: true,
        isToday: isCurrentMonthAndYear && today.getDate() === i,
        activities: dayActivities.length > 0 ? dayActivities : undefined
      });
    }
    
    // Add days from next month to complete 6 rows (42 days)
    const remainingDays = 42 - days.length;
    for (let i = 1; i <= remainingDays; i++) {
      days.push({
        date: i,
        isCurrentMonth: false,
        isToday: false
      });
    }
    
    return days;
  };
  
  const calendarDays = generateCalendarDays();
  
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between p-2 sm:py-2 sm:px-3">
        <CardTitle className="text-sm sm:text-base md:text-lg">{formatMonthYear(currentDate)}</CardTitle>
        <div className="flex space-x-1">
          <Button variant="outline" size="icon" className="h-6 w-6 sm:h-7 sm:w-7" onClick={prevMonth}>
            <ChevronLeft className="h-3 w-3 sm:h-4 sm:w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-6 w-6 sm:h-7 sm:w-7" onClick={nextMonth}>
            <ChevronRight className="h-3 w-3 sm:h-4 sm:w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-6 w-6 sm:h-7 sm:w-7">
            <Calendar className="h-3 w-3 sm:h-4 sm:w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-1 md:p-4">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full py-8">
            <Loader2 className="h-8 w-8 animate-spin text-orange-500 mb-2" />
            <p className="text-sm text-muted-foreground">Loading calendar data...</p>
          </div>
        ) : (
          <>
            {/* Calendar Header */}
            <div className="grid grid-cols-7 gap-0.5 md:gap-1 text-center text-[10px] md:text-xs text-neutral-500 mb-0.5 md:mb-1">
              <div>M</div>
              <div>T</div>
              <div>W</div>
              <div>T</div>
              <div>F</div>
              <div>S</div>
              <div>S</div>
            </div>
            
            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-0.5 md:gap-1 text-center mb-2 md:mb-4">
              {calendarDays.map((day, index) => (
                <div key={index} className="aspect-square relative">
                  <div
                    className={cn(
                      "h-full flex items-center justify-center rounded-full cursor-pointer text-[10px] md:text-xs lg:text-sm",
                      day.isCurrentMonth 
                        ? day.isToday 
                          ? "bg-yellow-400 text-black font-medium" 
                          : "hover:bg-neutral-100"
                        : "text-neutral-400 hover:bg-neutral-100",
                      day.activities && day.activities.length > 0 && "border border-orange-300"
                    )}
                    onMouseEnter={() => day.isCurrentMonth && setHoveredDay(day.date)}
                    onTouchStart={() => day.isCurrentMonth && setHoveredDay(day.date === hoveredDay ? null : day.date)}
                    onMouseLeave={() => setHoveredDay(null)}
                  >
                    {day.date}
                    {day.activities && day.activities.length > 0 && (
                      <span className="absolute bottom-0.5 right-0.5 w-1.5 h-1.5 bg-orange-500 rounded-full"></span>
                    )}
                  </div>
                  
                  {/* Hover tooltip with activities */}
                  {hoveredDay === day.date && day.activities && day.activities.length > 0 && (
                    <div className="absolute z-20 bg-white shadow-lg rounded-md p-2 w-56 sm:w-64 left-1/2 -translate-x-1/2 sm:-left-20 sm:translate-x-0 top-full mt-1 text-left max-w-[calc(100vw-2rem)]">
                      <div className="text-[10px] md:text-xs font-semibold mb-1 text-blue-500 border-b pb-1">
                        Activities for {day.date} {formatMonthYear(currentDate).split(' ')[0]}
                      </div>
                      <ul className="text-[10px] md:text-xs space-y-1 max-h-32 md:max-h-40 overflow-y-auto">
                        {day.activities.map((activity, i) => (
                          <li key={i} className="flex items-start">
                            <span className="mr-1 text-blue-500 flex-shrink-0">•</span>
                            <span className="text-slate-700 line-clamp-3">{activity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            {/* Legend */}
            <div className="flex items-center justify-end text-[10px] md:text-xs text-neutral-500">
              <div className="flex items-center mr-2 md:mr-3">
                <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-blue-400 rounded-full mr-0.5 md:mr-1"></div>
                <span>Today</span>
              </div>
              <div className="flex items-center">
                <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-green-500 rounded-full mr-0.5 md:mr-1"></div>
                <span>Activities</span>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
