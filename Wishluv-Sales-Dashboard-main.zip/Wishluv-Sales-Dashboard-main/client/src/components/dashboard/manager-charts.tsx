import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Activity } from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart as RechartsBarChart,
  Bar,
  LineChart,
  Line,
  ComposedChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

// Sample data for development until backend endpoints are ready
const monthlyData = [
  { month: 1, monthName: "Jan", totalSales: 1250000, totalArea: 2500, salesCount: 5 },
  { month: 2, monthName: "Feb", totalSales: 1750000, totalArea: 3500, salesCount: 7 },
  { month: 3, monthName: "Mar", totalSales: 2100000, totalArea: 4200, salesCount: 9 },
  { month: 4, monthName: "Apr", totalSales: 1850000, totalArea: 3700, salesCount: 8 },
  { month: 5, monthName: "May", totalSales: 3180000, totalArea: 6360, salesCount: 12 }
];

const ytdData = [
  { week: 4, label: "Week 4", date: "2025-01-28", totalSales: 1250000, totalArea: 2500, salesCount: 5 },
  { week: 8, label: "Week 8", date: "2025-02-25", totalSales: 3000000, totalArea: 6000, salesCount: 12 },
  { week: 12, label: "Week 12", date: "2025-03-25", totalSales: 5100000, totalArea: 10200, salesCount: 21 },
  { week: 16, label: "Week 16", date: "2025-04-22", totalSales: 6950000, totalArea: 13900, salesCount: 29 },
  { week: 20, label: "Week 20", date: "2025-05-16", totalSales: 10130000, totalArea: 20260, salesCount: 41 }
];

export default function ManagerCharts() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
      {/* Monthly Sales Graph */}
      <Card className="border shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart className="h-5 w-5 text-blue-500" /> Monthly Sales Graph
          </CardTitle>
          <CardDescription>
            Monthly sales performance across your team for the current year
          </CardDescription>
        </CardHeader>
        <CardContent className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={monthlyData}
              margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis 
                dataKey="monthName" 
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: '#eee' }}
              />
              <YAxis 
                yAxisId="left"
                tickFormatter={(value) => 
                  value >= 1000000 
                    ? `₹${(value/1000000).toFixed(1)}M` 
                    : value >= 1000 
                      ? `₹${(value/1000).toFixed(0)}K` 
                      : `₹${value}`
                }
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: '#eee' }}
              />
              <YAxis 
                yAxisId="right" 
                orientation="right"
                tickFormatter={(value) => 
                  value >= 1000 
                    ? `${(value/1000).toFixed(1)}K` 
                    : `${value}`
                }
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: '#eee' }}
              />
              <Tooltip 
                formatter={(value, name) => {
                  if (name === "totalSales") return [`₹${Number(value).toLocaleString()}`, "Revenue"];
                  if (name === "totalArea") return [`${Number(value).toLocaleString()} sq.ft.`, "Area Sold"];
                  if (name === "salesCount") return [value, "Deals Closed"];
                  return [value, name];
                }}
                labelFormatter={(label) => `Month: ${label}`}
              />
              <Legend 
                verticalAlign="top" 
                height={36}
                formatter={(value) => {
                  if (value === "totalSales") return "Revenue";
                  if (value === "totalArea") return "Area Sold";
                  if (value === "salesCount") return "Deals Closed";
                  return value;
                }}
              />
              <Bar 
                dataKey="totalSales" 
                fill="#8884d8" 
                yAxisId="left"
                barSize={20}
                name="totalSales"
              />
              <Line 
                type="monotone" 
                dataKey="totalArea" 
                stroke="#82ca9d" 
                strokeWidth={2}
                yAxisId="right"
                name="totalArea"
                dot={{ fill: '#82ca9d', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      
      {/* Year-to-Date Performance Graph */}
      <Card className="border shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-green-500" /> Year-to-Date Performance
          </CardTitle>
          <CardDescription>
            Cumulative sales performance across your team this year
          </CardDescription>
        </CardHeader>
        <CardContent className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={ytdData}
              margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis 
                dataKey="label" 
                tick={{ fontSize: 12 }}
                interval={Math.max(1, Math.floor(ytdData.length / 6))}
                tickLine={false}
                axisLine={{ stroke: '#eee' }}
              />
              <YAxis 
                tickFormatter={(value) => 
                  value >= 1000000 
                    ? `₹${(value/1000000).toFixed(1)}M` 
                    : value >= 1000 
                      ? `₹${(value/1000).toFixed(0)}K` 
                      : `₹${value}`
                }
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: '#eee' }}
              />
              <Tooltip 
                formatter={(value) => [`₹${Number(value).toLocaleString()}`, "Total Revenue"]}
                labelFormatter={(label) => {
                  const dataEntry = ytdData.find(item => item.label === label);
                  return `${label} (${dataEntry?.date || ''})`;
                }}
              />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="totalSales" 
                name="Total Revenue" 
                stroke="#4f46e5" 
                fill="#4f46e5" 
                fillOpacity={0.2}
                strokeWidth={2}
                activeDot={{ r: 6 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}