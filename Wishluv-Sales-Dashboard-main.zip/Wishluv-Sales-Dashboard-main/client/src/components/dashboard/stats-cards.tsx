import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { Building, Users, FileText, PieChart } from "lucide-react";
import { Project, User, Department, Sales } from "@shared/schema";

export function StatsCards() {
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });
  
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });
  
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: ["/api/departments"],
  });
  
  // Use monthly sales for the "Sales This Month" card
  const { data: sales = [] } = useQuery<Sales[]>({
    queryKey: ["/api/sales-monthly"],
  });

  // Card animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  // Define stats cards data
  const stats = [
    {
      title: "Total Projects",
      value: projects.length || 0,
      icon: <FileText className="h-5 w-5 text-white" />,
      color: "from-blue-400 to-blue-600",
      increase: "+12% from last month"
    },
    {
      title: "Team Members",
      value: users.length || 0,
      icon: <Users className="h-5 w-5 text-white" />,
      color: "from-orange-400 to-orange-600",
      increase: "+3 this week"
    },
    {
      title: "Departments",
      value: departments.length || 0,
      icon: <Building className="h-5 w-5 text-white" />,
      color: "from-purple-400 to-purple-600",
      increase: "No change"
    },
    {
      title: "Sales This Month",
      value: `₹${sales.reduce((total, sale) => total + parseFloat(sale.finalAmount || '0'), 0).toLocaleString()}`,
      icon: <PieChart className="h-5 w-5 text-white" />,
      color: "from-green-400 to-green-600",
      increase: "Based on actual sales data"
    }
  ];

  return (
    <motion.div 
      className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {stats.map((stat, index) => (
        <motion.div key={index} variants={item}>
          <Card className="overflow-hidden border-none shadow-md h-full">
            <div className={`bg-gradient-to-r ${stat.color} h-2`}></div>
            <CardContent className="p-3 md:p-4 h-full flex flex-col justify-between">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-xs md:text-sm font-medium text-neutral-500 truncate">{stat.title}</p>
                  <h4 className="text-base md:text-xl lg:text-2xl font-bold mt-1 break-words">
                    {typeof stat.value === 'number' && stat.value > 999 
                      ? `${(stat.value / 1000).toFixed(1)}k` 
                      : stat.value}
                  </h4>
                  <p className="text-[10px] md:text-xs text-neutral-400 mt-1 line-clamp-2">{stat.increase}</p>
                </div>
                <div className={`p-2 md:p-2.5 lg:p-3 rounded-full bg-gradient-to-r ${stat.color} flex-shrink-0`}>
                  {stat.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
}