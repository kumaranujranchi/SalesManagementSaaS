import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Target, Calendar, TrendingUp, ArrowUp, ArrowDown } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { getMonthName } from "@/lib/date-utils";

export function TargetAchievementDetail() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"monthly" | "ytd">("monthly");
  
  const now = new Date();
  const currentMonth = now.getMonth() + 1; // 1-12
  const currentYear = now.getFullYear();
  
  // Only fetch data if user is in Sales department
  const { data: achievement, isLoading, error, refetch } = useQuery({
    queryKey: ["/api/targets/achievement", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      // Add a timestamp parameter to avoid browser caching
      const timestamp = new Date().getTime();
      const res = await fetch(`/api/targets/achievement/${user.id}?fresh=true&ts=${timestamp}`);
      
      if (!res.ok) {
        throw new Error("Failed to fetch achievement data");
      }
      return res.json();
    },
    enabled: !!user?.id && user?.department === "Sales",
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 5000 // Consider data fresh for 5 seconds
  });
  
  // Periodically refetch data to ensure we have the latest achievements
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 30000); // Refresh every 30 seconds
    
    return () => clearInterval(interval);
  }, [refetch]);
  
  // Handle errors from the query
  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch achievement data",
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  // Loading state
  if (isLoading) {
    return (
      <Card className="shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-lg">
            <Target className="mr-2 h-5 w-5" />
            <Skeleton className="h-4 w-36" />
          </CardTitle>
          <CardDescription>
            <Skeleton className="h-3 w-24" />
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-32 w-full" />
        </CardContent>
      </Card>
    );
  }
  
  // No data state
  if (!achievement || !achievement.monthlyBreakdown || achievement.monthlyBreakdown.length === 0) {
    return (
      <Card className="shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-lg">
            <Target className="mr-2 h-5 w-5" />
            Target vs Achievement
          </CardTitle>
          <CardDescription>No target data available</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm">Please ask your manager to set a monthly target.</p>
        </CardContent>
      </Card>
    );
  }
  
  // Sort monthly data by year and month (most recent first)
  const sortedMonthlyData = [...achievement.monthlyBreakdown].sort((a, b) => {
    if (a.year !== b.year) return b.year - a.year;
    return b.month - a.month;
  });
  
  // Get current month data
  const currentMonthData = sortedMonthlyData.find(
    (m) => m.month === currentMonth && m.year === currentYear
  ) || { 
    month: currentMonth, 
    year: currentYear, 
    target: user?.monthlyTarget || 0, 
    achieved: 0,
    percentageAchieved: 0
  };
  
  // Calculate YTD values
  const ytdTarget = achievement.totalTarget || 0;
  const ytdAchieved = achievement.totalAchievement || 0;
  const ytdPercentage = ytdTarget > 0 ? Math.min(Math.round((ytdAchieved / ytdTarget) * 100), 100) : 0;
  
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Target className="mr-2 h-5 w-5" />
            Target vs Achievement
          </div>
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "monthly" | "ytd")} className="w-auto">
            <TabsList className="grid grid-cols-2 h-8">
              <TabsTrigger value="monthly" className="text-xs">Monthly</TabsTrigger>
              <TabsTrigger value="ytd" className="text-xs">Year to Date</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardTitle>
        <CardDescription>
          Track your performance against targets
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <TabsContent value="monthly" className="m-0 space-y-4">
          {/* Current Month Summary */}
          <div className="bg-primary/5 p-4 rounded-md">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-md font-semibold">
                {getMonthName(currentMonthData.month)} {currentMonthData.year}
              </h3>
              <div>
                {currentMonthData.percentageAchieved >= 100 ? (
                  <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-200">
                    Target Achieved
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-amber-100 text-amber-800 hover:bg-amber-200">
                    In Progress
                  </Badge>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-3">
              <div>
                <p className="text-xs text-muted-foreground">Target</p>
                <p className="text-lg font-semibold">{currentMonthData.target?.toLocaleString() || 0} sqft</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Achieved</p>
                <p className="text-lg font-semibold">{currentMonthData.achieved?.toLocaleString() || 0} sqft</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Progress</p>
                <p className="text-lg font-semibold">{currentMonthData.percentageAchieved?.toFixed(0) || 0}%</p>
              </div>
            </div>
            
            <Progress 
              value={currentMonthData.percentageAchieved || 0} 
              className="h-2" 
            />
          </div>
          
          {/* Monthly Breakdown */}
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Month</TableHead>
                  <TableHead className="text-right">Target (sqft)</TableHead>
                  <TableHead className="text-right">Achievement (sqft)</TableHead>
                  <TableHead className="text-right">Progress</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedMonthlyData.map((month, index) => {
                  const progress = month.target > 0 
                    ? Math.min(Math.round((month.achieved / month.target) * 100), 100) 
                    : 0;
                    
                  return (
                    <TableRow key={index}>
                      <TableCell>
                        {getMonthName(month.month)} {month.year}
                      </TableCell>
                      <TableCell className="text-right">
                        {month.target ? month.target.toLocaleString() : '0'}
                      </TableCell>
                      <TableCell className="text-right">
                        {month.achieved ? month.achieved.toLocaleString() : '0'}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end">
                          <span className="mr-2">{progress}%</span>
                          <div className="w-12 bg-muted rounded-full h-2 overflow-hidden">
                            <div 
                              className={`h-full ${progress >= 100 ? 'bg-green-500' : 'bg-primary'}`}
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="ytd" className="m-0 space-y-4">
          {/* YTD Summary */}
          <div className="bg-primary/5 p-4 rounded-md">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-md font-semibold">
                Year to Date Summary - {currentYear}
              </h3>
              <div>
                {achievement.isPositive ? (
                  <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-200 flex items-center gap-1">
                    <ArrowUp className="h-3 w-3" /> Positive
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-amber-100 text-amber-800 hover:bg-amber-200 flex items-center gap-1">
                    <ArrowDown className="h-3 w-3" /> Need to improve
                  </Badge>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-3">
              <div>
                <p className="text-xs text-muted-foreground">YTD Target</p>
                <p className="text-lg font-semibold">{ytdTarget.toLocaleString()} sqft</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">YTD Achievement</p>
                <p className="text-lg font-semibold">{ytdAchieved.toLocaleString()} sqft</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">YTD Progress</p>
                <p className="text-lg font-semibold">{ytdPercentage}%</p>
              </div>
            </div>
            
            <Progress 
              value={ytdPercentage} 
              className="h-2"
            />
          </div>
          
          {/* YTD Breakdown by Quarter */}
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Quarter</TableHead>
                  <TableHead className="text-right">Target (sqft)</TableHead>
                  <TableHead className="text-right">Achievement (sqft)</TableHead>
                  <TableHead className="text-right">Difference</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {/* Group data by quarter */}
                {[
                  { name: 'Q1 (Jan-Mar)', months: [1, 2, 3] },
                  { name: 'Q2 (Apr-Jun)', months: [4, 5, 6] },
                  { name: 'Q3 (Jul-Sep)', months: [7, 8, 9] },
                  { name: 'Q4 (Oct-Dec)', months: [10, 11, 12] }
                ].map((quarter, index) => {
                  // Filter months for current year and this quarter
                  const quarterData = sortedMonthlyData.filter(
                    m => m.year === currentYear && quarter.months.includes(m.month)
                  );
                  
                  // Calculate totals
                  const quarterTarget = quarterData.reduce((sum, m) => sum + (m.target || 0), 0);
                  const quarterAchieved = quarterData.reduce((sum, m) => sum + (m.achieved || 0), 0);
                  const difference = quarterAchieved - quarterTarget;
                  const progress = quarterTarget > 0 ? Math.round((quarterAchieved / quarterTarget) * 100) : 0;
                  
                  // Skip if no data for this quarter
                  if (quarterData.length === 0 && !quarter.months.includes(currentMonth) && 
                      quarter.months[0] > currentMonth) {
                    return null;
                  }
                  
                  return (
                    <TableRow key={index}>
                      <TableCell>{quarter.name}</TableCell>
                      <TableCell className="text-right">{quarterTarget.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{quarterAchieved.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <span className={
                          difference > 0 
                            ? 'text-green-600 flex items-center justify-end gap-1' 
                            : (difference < 0 ? 'text-red-600 flex items-center justify-end gap-1' : '')
                        }>
                          {difference > 0 && <ArrowUp className="h-3 w-3" />}
                          {difference < 0 && <ArrowDown className="h-3 w-3" />}
                          {difference > 0 ? '+' : ''}{difference.toLocaleString()}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                }).filter(Boolean)}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </CardContent>
      
      <CardFooter className="border-t pt-4 text-xs text-muted-foreground">
        <div className="flex items-center space-x-1">
          <Calendar className="h-3 w-3" />
          <span>Data as of {formatDate(new Date())}</span>
        </div>
      </CardFooter>
    </Card>
  );
}

function formatDate(date: Date): string {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  
  const day = date.getDate();
  const month = date.getMonth();
  const year = date.getFullYear();
  
  return `${months[month]} ${day}, ${year}`;
}