import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Leaderboard, User } from "@shared/schema";

interface LeaderboardEntry extends Leaderboard {
  user?: User;
}

interface LeaderboardItemProps {
  initials: string;
  achievement: string;
}

function LeaderboardItem({ initials, achievement }: LeaderboardItemProps) {
  return (
    <li className="flex items-center pb-3 border-b border-neutral-200">
      <Avatar className="h-7 w-7 md:h-8 md:w-8 bg-primary text-black font-medium text-xs md:text-sm flex-shrink-0">
        <AvatarFallback>{initials}</AvatarFallback>
      </Avatar>
      <div className="ml-2 md:ml-3 min-w-0"> {/* min-w-0 ensures text truncation works properly */}
        <p className="text-neutral-800 text-xs md:text-sm line-clamp-2">{achievement}</p>
      </div>
    </li>
  );
}

export function UserLeaderboard() {
  const { data: leaderboardData, isLoading: leaderboardLoading, error: leaderboardError } = useQuery<Leaderboard[]>({
    queryKey: ["/api/leaderboard"],
  });
  
  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const isLoading = leaderboardLoading || usersLoading;
  
  // Combine leaderboard entries with user data
  const enrichedLeaderboard: LeaderboardEntry[] = leaderboardData && users 
    ? leaderboardData.map(entry => ({
        ...entry,
        user: users.find(user => user.id === entry.userId)
      }))
    : [];

  // Show leaderboard entries or defaults if none are available
  const leaderboardEntries = enrichedLeaderboard.length > 0 
    ? enrichedLeaderboard.slice(0, 3)
    : [
        { id: 1, userId: 1, achievement: "Shubham Kumar Reached 10,000 Sq ft", score: 100, user: { id: 1, fullName: "Shubham Kumar" } as User },
        { id: 2, userId: 2, achievement: "Gaurav Sinha Closed 1200 sq ft in Crystal City", score: 80, user: { id: 2, fullName: "Gaurav Sinha" } as User },
        { id: 3, userId: 3, achievement: "Jessica Lee: $4500 sales", score: 70, user: { id: 3, fullName: "Jessica Lee" } as User }
      ];

  // Helper function to get initials from a name
  const getInitials = (name?: string) => {
    if (!name) return "??";
    return name
      .split(' ')
      .map(part => part[0]?.toUpperCase())
      .join('')
      .slice(0, 2);
  };

  return (
    <Card className="h-full">
      <CardHeader className="p-4 md:p-6">
        <CardTitle className="text-base md:text-lg">User Leaderboard</CardTitle>
      </CardHeader>
      <CardContent className="p-4 md:p-6">
        {isLoading ? (
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <Skeleton className="h-8 w-8 rounded-full" />
              <Skeleton className="h-5 w-full" />
            </div>
            <div className="flex items-center space-x-4">
              <Skeleton className="h-8 w-8 rounded-full" />
              <Skeleton className="h-5 w-full" />
            </div>
            <div className="flex items-center space-x-4">
              <Skeleton className="h-8 w-8 rounded-full" />
              <Skeleton className="h-5 w-full" />
            </div>
          </div>
        ) : leaderboardError ? (
          <p className="text-red-500">Failed to load leaderboard</p>
        ) : (
          <ul className="space-y-3">
            {leaderboardEntries.map(entry => (
              <LeaderboardItem 
                key={entry.id} 
                initials={getInitials(entry.user?.fullName)} 
                achievement={entry.achievement} 
              />
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
