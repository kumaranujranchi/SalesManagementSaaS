import { useState, useEffect } from "react";
import { Cloud, Loader2, Thermometer } from "lucide-react";

// Updated interface to match wttr.in API structure
interface WttrWeatherData {
  current_condition: {
    temp_C: string;
    FeelsLikeC: string;
    humidity: string;
    weatherDesc: { value: string }[];
    weatherIconUrl: { value: string }[];
  }[];
  nearest_area: {
    areaName: { value: string }[];
    country: { value: string }[];
  }[];
}

export function WeatherInfo() {
  const [weatherData, setWeatherData] = useState<WttrWeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchWeather() {
      try {
        setLoading(true);
        
        // Fetch weather for Patna
        const city = "Patna,Bihar,IN";
        console.log("Fetching weather for:", city);
        
        const response = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Weather API error: ${response.status}`);
        }
        
        const data = await response.json();
        console.log("Weather data received:", data);
        
        // Save the raw data as is since we're using wttr.in format
        setWeatherData(data);
        setError(null);
      } catch (err) {
        console.error("Failed to fetch weather data:", err);
        setError("Weather updates unavailable");
      } finally {
        setLoading(false);
      }
    }
    
    fetchWeather();
    
    // Refresh every 30 minutes
    const intervalId = setInterval(fetchWeather, 30 * 60 * 1000);
    
    return () => clearInterval(intervalId);
  }, []);
  
  if (loading) {
    return (
      <div className="flex items-center gap-1 text-orange-100 animate-pulse">
        <Loader2 className="h-3 sm:h-3.5 w-3 sm:w-3.5 animate-spin" />
        <span className="text-[10px] sm:text-xs">Loading weather...</span>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex items-center gap-1 text-orange-100">
        <Cloud className="h-3 sm:h-3.5 w-3 sm:w-3.5" />
        <span className="text-[10px] sm:text-xs">{error}</span>
      </div>
    );
  }
  
  if (!weatherData?.current_condition?.[0]) {
    return (
      <div className="flex items-center gap-1 text-orange-100">
        <Cloud className="h-3 sm:h-3.5 w-3 sm:w-3.5" />
        <span className="text-[10px] sm:text-xs">Weather data unavailable</span>
      </div>
    );
  }
  
  const currentWeather = weatherData.current_condition[0];
  const location = weatherData.nearest_area?.[0]?.areaName?.[0]?.value || "Patna";
  const country = weatherData.nearest_area?.[0]?.country?.[0]?.value || "India";
  const description = currentWeather.weatherDesc?.[0]?.value || "";
  
  return (
    <div className="flex items-center gap-1 sm:gap-1.5 text-amber-900">
      <Thermometer className="h-3.5 sm:h-4 w-3.5 sm:w-4" />
      <span className="text-[10px] sm:text-xs font-medium">
        {location}, {country}: {currentWeather.temp_C}°C, {description}
      </span>
    </div>
  );
}