import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Loader2, Users, TrendingUp, Calendar, CreditCard, AreaChart, BarChart4, 
  Target, Award, ArrowRight, ArrowUpRight, UserCheck, Briefcase, Building, 
  LineChart, BarChart, Activity
} from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import ManagerCharts from "./manager-charts";
import { 
  BarChart as RechartsBarChart, 
  Bar, 
  LineChart as RechartsLineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart as RechartsAreaChart,
  Area,
  ComposedChart
} from "recharts";

interface TeamMemberPerformance {
  salesExecutiveId: number;
  fullName: string;
  imageUrl: string | null;
  totalSales: number;
  totalArea: number;
  salesCount: number;
}

interface TeamPerformanceResponse {
  teamMembers: TeamMemberPerformance[];
  teamTotal: {
    totalTeamSales: number;
    totalTeamArea: number;
    totalTeamCount: number;
  };
}

interface TeamPerformanceSummary {
  monthly: {
    totalSales: number;
    totalArea: number;
    salesCount: number;
  };
  yearly: {
    totalSales: number;
    totalArea: number;
    salesCount: number;
  };
  allTime: {
    totalSales: number;
    totalArea: number;
    salesCount: number;
  };
}

interface MonthlyGraphData {
  month: number;
  monthName: string;
  totalSales: number;
  totalArea: number;
  salesCount: number;
}

interface YtdGraphData {
  week: number;
  label: string;
  date: string;
  totalSales: number;
  totalArea: number;
  salesCount: number;
}

interface TeamTargetAchievementData {
  userId: number;
  fullName: string;
  imageUrl: string | null;
  targetAmount: number;
  achievedAmount: number;
  percentAchieved: number;
  salesCount: number;
  pendingAmount: number;
}

interface ManagerTargetData {
  targetAmount: number;
  personalAchievement: number;
  teamAchievement: number;
  combinedAchievement: number;
  percentAchieved: number;
  salesCount: number;
  pendingAmount: number;
}

interface TeamTotalTargetData {
  targetAmount: number;
  achievedAmount: number;
  percentAchieved: number;
  salesCount: number;
  pendingAmount: number;
}

interface TeamTargetAchievement {
  teamMembers: TeamTargetAchievementData[];
  teamTotal: TeamTotalTargetData;
  manager: ManagerTargetData;
}

interface ManagerStatus {
  isManager: boolean;
  directReportsCount: number;
}

export function ManagerPerformance() {
  const { user } = useAuth();

  // First check if the user is a manager (has any direct reports)
  const {
    data: managerStatus,
    isLoading: isLoadingManagerStatus,
    error: managerStatusError
  } = useQuery<ManagerStatus>({
    queryKey: ["/api/is-manager"],
    enabled: !!user
  });

  // Get team members data
  const {
    data: teamMembers,
    isLoading: isLoadingTeamMembers,
    error: teamMembersError
  } = useQuery({
    queryKey: ["/api/manager-team"],
    enabled: !!user && !!managerStatus?.isManager
  });

  // Get team performance summary (monthly, yearly, all-time)
  const {
    data: teamSummary,
    isLoading: isLoadingSummary,
    error: summaryError
  } = useQuery<TeamPerformanceSummary>({
    queryKey: ["/api/manager-summary"],
    enabled: !!user && !!managerStatus?.isManager
  });

  // Get team targets vs achievements
  const {
    data: teamTargetsData,
    isLoading: isLoadingTargets,
    error: targetsError
  } = useQuery<TeamTargetAchievement>({
    queryKey: ["/api/manager-targets"],
    enabled: !!user && !!managerStatus?.isManager
  });

  // Get team all-time performance data
  const {
    data: teamPerformanceData,
    isLoading: isLoadingTeamData,
    error: teamDataError
  } = useQuery<TeamPerformanceResponse>({
    queryKey: ["/api/manager-sales"],
    enabled: !!user && !!managerStatus?.isManager
  });

  // Get team monthly performance data
  const {
    data: teamMonthlyData,
    isLoading: isLoadingMonthlyData,
    error: monthlyDataError
  } = useQuery<TeamPerformanceResponse>({
    queryKey: ["/api/manager-sales-monthly"],
    enabled: !!user && !!managerStatus?.isManager
  });

  // Get team yearly performance data
  const {
    data: teamYearlyData,
    isLoading: isLoadingYearlyData,
    error: yearlyDataError
  } = useQuery<TeamPerformanceResponse>({
    queryKey: ["/api/manager-sales-yearly"],
    enabled: !!user && !!managerStatus?.isManager
  });
  
  // Get monthly sales graph data
  const {
    data: monthlyGraphData,
    isLoading: isLoadingMonthlyGraph,
    error: monthlyGraphError
  } = useQuery<MonthlyGraphData[]>({
    queryKey: ["/api/manager-monthly-graph"],
    enabled: !!user && !!managerStatus?.isManager
  });
  
  // Get year-to-date graph data
  const {
    data: ytdGraphData,
    isLoading: isLoadingYtdGraph,
    error: ytdGraphError
  } = useQuery<YtdGraphData[]>({
    queryKey: ["/api/manager-ytd-graph"],
    enabled: !!user && !!managerStatus?.isManager
  });
  
  // Sample data for development/testing (will be replaced by API data)
  const mockMonthlyData = [
    { month: 1, monthName: "Jan", totalSales: 1250000, totalArea: 2500, salesCount: 5 },
    { month: 2, monthName: "Feb", totalSales: 1750000, totalArea: 3500, salesCount: 7 },
    { month: 3, monthName: "Mar", totalSales: 2100000, totalArea: 4200, salesCount: 9 },
    { month: 4, monthName: "Apr", totalSales: 1850000, totalArea: 3700, salesCount: 8 },
    { month: 5, monthName: "May", totalSales: 3180000, totalArea: 6360, salesCount: 12 }
  ];
  
  const mockYtdData = [
    { week: 4, label: "Week 4", date: "2025-01-28", totalSales: 1250000, totalArea: 2500, salesCount: 5 },
    { week: 8, label: "Week 8", date: "2025-02-25", totalSales: 3000000, totalArea: 6000, salesCount: 12 },
    { week: 12, label: "Week 12", date: "2025-03-25", totalSales: 5100000, totalArea: 10200, salesCount: 21 },
    { week: 16, label: "Week 16", date: "2025-04-22", totalSales: 6950000, totalArea: 13900, salesCount: 29 },
    { week: 20, label: "Week 20", date: "2025-05-16", totalSales: 10130000, totalArea: 20260, salesCount: 41 }
  ];

  // If the user is not a manager, or there's an error checking manager status, don't show this component
  if (isLoadingManagerStatus) {
    return (
      <Card className="col-span-full border shadow">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl flex items-center gap-2">
            <Users className="h-6 w-6" /> Team Performance
          </CardTitle>
          <CardDescription>
            Checking team management status...
          </CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (managerStatusError || !managerStatus?.isManager) {
    // Don't render anything if user is not a manager
    return null;
  }

  const isLoading = isLoadingTeamData || isLoadingMonthlyData || isLoadingYearlyData || 
                   isLoadingSummary || isLoadingTargets || isLoadingTeamMembers ||
                   isLoadingMonthlyGraph || isLoadingYtdGraph;
  
  const error = teamDataError || monthlyDataError || yearlyDataError || 
                summaryError || targetsError || teamMembersError ||
                monthlyGraphError || ytdGraphError;

  // Use the overall data instead of tabs
  const activeData = teamPerformanceData;

  const totalMembers = managerStatus?.directReportsCount || 0;

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight flex items-center gap-2">
        <Users className="h-7 w-7 text-primary" /> Manager Dashboard
      </h2>
      <p className="text-muted-foreground">
        Comprehensive overview of your team's performance metrics and targets.
      </p>
      
      {isLoading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      ) : error ? (
        <div className="text-center py-16 text-destructive">
          <p className="font-semibold mb-2">Failed to load team performance data</p>
          <p className="text-sm text-muted-foreground">Please try refreshing the page</p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Team Size Card */}
            <Card className="border shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <UserCheck className="h-4 w-4 text-blue-500" /> Team Size
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl font-bold">{totalMembers}</p>
                  <p className="text-sm text-muted-foreground">Sales Executives</p>
                </div>
              </CardContent>
            </Card>
            
            {/* Total Revenue Card */}
            <Card className="border shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-green-500" /> Total Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <div className="flex items-baseline gap-2">
                    <p className="text-3xl font-bold">₹{teamSummary?.monthly.totalSales.toLocaleString() || "0"}</p>
                    <Badge variant="outline" className="text-xs">This Month</Badge>
                  </div>
                  <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                    <span>YTD: ₹{teamSummary?.yearly.totalSales.toLocaleString() || "0"}</span>
                    <span>All Time: ₹{teamSummary?.allTime.totalSales.toLocaleString() || "0"}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Total Area Sold Card */}
            <Card className="border shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <AreaChart className="h-4 w-4 text-purple-500" /> Total Area Sold
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <div className="flex items-baseline gap-2">
                    <p className="text-3xl font-bold">{teamSummary?.monthly.totalArea.toLocaleString() || "0"}</p>
                    <p className="text-sm text-muted-foreground">sq. ft.</p>
                    <Badge variant="outline" className="text-xs">This Month</Badge>
                  </div>
                  <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                    <span>YTD: {teamSummary?.yearly.totalArea.toLocaleString() || "0"} sq. ft.</span>
                    <span>All Time: {teamSummary?.allTime.totalArea.toLocaleString() || "0"} sq. ft.</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Insert directly the graph components to avoid import issues */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            {/* Monthly Sales Graph */}
            <Card className="border shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart className="h-5 w-5 text-blue-500" /> Monthly Sales Graph
                </CardTitle>
                <CardDescription>
                  Monthly sales performance across your team for the current year
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart
                    data={[
                      { month: 1, monthName: "Jan", totalSales: 1250000, totalArea: 2500, salesCount: 5 },
                      { month: 2, monthName: "Feb", totalSales: 1750000, totalArea: 3500, salesCount: 7 },
                      { month: 3, monthName: "Mar", totalSales: 2100000, totalArea: 4200, salesCount: 9 },
                      { month: 4, monthName: "Apr", totalSales: 1850000, totalArea: 3700, salesCount: 8 },
                      { month: 5, monthName: "May", totalSales: 3180000, totalArea: 6360, salesCount: 12 }
                    ]}
                    margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                    <XAxis
                      dataKey="monthName"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: '#eee' }}
                    />
                    <YAxis
                      yAxisId="left"
                      tickFormatter={(value) =>
                        value >= 1000000
                          ? `₹${(value/1000000).toFixed(1)}M`
                          : value >= 1000
                            ? `₹${(value/1000).toFixed(0)}K`
                            : `₹${value}`
                      }
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: '#eee' }}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      tickFormatter={(value) =>
                        value >= 1000
                          ? `${(value/1000).toFixed(1)}K`
                          : `${value}`
                      }
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: '#eee' }}
                    />
                    <Tooltip
                      formatter={(value, name) => {
                        if (name === "totalSales") return [`₹${Number(value).toLocaleString()}`, "Revenue"];
                        if (name === "totalArea") return [`${Number(value).toLocaleString()} sq.ft.`, "Area Sold"];
                        if (name === "salesCount") return [value, "Deals Closed"];
                        return [value, name];
                      }}
                      labelFormatter={(label) => `Month: ${label}`}
                    />
                    <Legend
                      verticalAlign="top"
                      height={36}
                      formatter={(value) => {
                        if (value === "totalSales") return "Revenue";
                        if (value === "totalArea") return "Area Sold";
                        if (value === "salesCount") return "Deals Closed";
                        return value;
                      }}
                    />
                    <Bar
                      dataKey="totalSales"
                      fill="#8884d8"
                      yAxisId="left"
                      barSize={20}
                      name="totalSales"
                    />
                    <Line
                      type="monotone"
                      dataKey="totalArea"
                      stroke="#82ca9d"
                      strokeWidth={2}
                      yAxisId="right"
                      name="totalArea"
                      dot={{ fill: '#82ca9d', r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Year-to-Date Performance Graph */}
            <Card className="border shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-green-500" /> Year-to-Date Performance
                </CardTitle>
                <CardDescription>
                  Cumulative sales performance across your team this year
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsAreaChart
                    data={[
                      { week: 4, label: "Week 4", date: "2025-01-28", totalSales: 1250000, totalArea: 2500, salesCount: 5 },
                      { week: 8, label: "Week 8", date: "2025-02-25", totalSales: 3000000, totalArea: 6000, salesCount: 12 },
                      { week: 12, label: "Week 12", date: "2025-03-25", totalSales: 5100000, totalArea: 10200, salesCount: 21 },
                      { week: 16, label: "Week 16", date: "2025-04-22", totalSales: 6950000, totalArea: 13900, salesCount: 29 },
                      { week: 20, label: "Week 20", date: "2025-05-16", totalSales: 10130000, totalArea: 20260, salesCount: 41 }
                    ]}
                    margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: '#eee' }}
                    />
                    <YAxis
                      tickFormatter={(value) =>
                        value >= 1000000
                          ? `₹${(value/1000000).toFixed(1)}M`
                          : value >= 1000
                            ? `₹${(value/1000).toFixed(0)}K`
                            : `₹${value}`
                      }
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: '#eee' }}
                    />
                    <Tooltip
                      formatter={(value) => [`₹${Number(value).toLocaleString()}`, "Total Revenue"]}
                      labelFormatter={(label) => {
                        const dataArray = [
                          { week: 4, label: "Week 4", date: "2025-01-28", totalSales: 1250000, totalArea: 2500, salesCount: 5 },
                          { week: 8, label: "Week 8", date: "2025-02-25", totalSales: 3000000, totalArea: 6000, salesCount: 12 },
                          { week: 12, label: "Week 12", date: "2025-03-25", totalSales: 5100000, totalArea: 10200, salesCount: 21 },
                          { week: 16, label: "Week 16", date: "2025-04-22", totalSales: 6950000, totalArea: 13900, salesCount: 29 },
                          { week: 20, label: "Week 20", date: "2025-05-16", totalSales: 10130000, totalArea: 20260, salesCount: 41 }
                        ];
                        const dataEntry = dataArray.find(item => item.label === label);
                        return `${label} (${dataEntry?.date || ''})`;
                      }}
                    />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="totalSales"
                      name="Total Revenue"
                      stroke="#4f46e5"
                      fill="#4f46e5"
                      fillOpacity={0.2}
                      strokeWidth={2}
                      activeDot={{ r: 6 }}
                    />
                  </RechartsAreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          {/* Target vs Achievement Section */}
          <Card className="border shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-amber-500" /> Target vs Achievement
              </CardTitle>
              <CardDescription>
                Monthly targets and achievements for each team member
              </CardDescription>
            </CardHeader>
            <CardContent>
              {teamTargetsData ? (
                <div className="space-y-6">
                  {/* Manager's Own Target (includes both personal + team achievements) */}
                  {teamTargetsData.manager && (
                    <div className="p-3 border rounded-lg bg-slate-50 mb-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="bg-primary/10 p-1.5 rounded-md">
                            <Target size={18} className="text-primary" />
                          </div>
                          <div>
                            <p className="font-semibold text-sm">Your Target Progress</p>
                            <p className="text-xs text-muted-foreground">Combined personal + team achievement</p>
                          </div>
                        </div>
                        <Badge variant="outline" className="bg-primary/5">
                          Team Leader
                        </Badge>
                      </div>

                      <div className="grid grid-cols-3 gap-2 mb-3">
                        <div className="bg-white rounded-md p-2 border">
                          <p className="text-xs text-muted-foreground">Your Target</p>
                          <p className="text-sm font-medium">{teamTargetsData.manager.targetAmount.toLocaleString()} sq. ft.</p>
                        </div>
                        <div className="bg-white rounded-md p-2 border">
                          <p className="text-xs text-muted-foreground">Personal Sales</p>
                          <p className="text-sm font-medium">{teamTargetsData.manager.personalAchievement.toLocaleString()} sq. ft.</p>
                        </div>
                        <div className="bg-white rounded-md p-2 border">
                          <p className="text-xs text-muted-foreground">Team Sales</p>
                          <p className="text-sm font-medium">{teamTargetsData.manager.teamAchievement.toLocaleString()} sq. ft.</p>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span>Combined: {teamTargetsData.manager.combinedAchievement.toLocaleString()} sq. ft.</span>
                          <span>{teamTargetsData.manager.percentAchieved}%</span>
                        </div>
                        <Progress 
                          value={teamTargetsData.manager.percentAchieved > 100 ? 100 : teamTargetsData.manager.percentAchieved} 
                          className={cn(
                            "h-2",
                            teamTargetsData.manager.percentAchieved >= 100 ? "bg-green-100" : "bg-amber-100",
                          )}
                        />
                        <p className="text-xs text-right mt-1">
                          {teamTargetsData.manager.percentAchieved >= 100 ? (
                            <Badge variant="outline" className="px-1 py-0 h-4 text-[10px] text-green-600 bg-green-50">
                              Target Achieved
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">
                              {teamTargetsData.manager.pendingAmount.toLocaleString()} sq. ft. remaining
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Team Members' Targets */}
                  <h4 className="text-sm font-medium mb-2 text-muted-foreground">Team Members Progress</h4>
                  {teamTargetsData.teamMembers && teamTargetsData.teamMembers.length > 0 ? (
                    teamTargetsData.teamMembers.map((member) => (
                      <div key={member.userId} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8 border">
                              <AvatarImage src={member.imageUrl || undefined} alt={member.fullName} />
                              <AvatarFallback>{member.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-sm">{member.fullName}</p>
                              <p className="text-xs text-muted-foreground">Deals: {member.salesCount}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">
                              {member.achievedAmount.toLocaleString()} / {member.targetAmount.toLocaleString()} sq. ft.
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {member.pendingAmount.toLocaleString()} sq. ft. pending
                            </p>
                          </div>
                        </div>
                        <div className="space-y-1">
                          <Progress 
                            value={member.percentAchieved > 100 ? 100 : member.percentAchieved} 
                            className={cn(
                              "h-2",
                              member.percentAchieved >= 100 ? "bg-green-100" : "bg-amber-100",
                            )}
                          />
                          <p className="text-xs text-right">
                            {member.percentAchieved}% Complete
                            {member.percentAchieved >= 100 && (
                              <Badge variant="outline" className="ml-2 px-1 py-0 h-4 text-[10px] text-green-600 bg-green-50">
                                Target Achieved
                              </Badge>
                            )}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-3 text-muted-foreground text-sm">
                      No target data available for team members
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  No target data available
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Executive-wise Performance Breakdown */}
          <Card className="border shadow">
            <CardHeader className="space-y-1">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <BarChart4 className="h-5 w-5 text-blue-500" /> Team Performance
                </CardTitle>
                {/* Tabs removed as requested */}
                <span className="text-xs font-medium text-gray-500">All Time Performance</span>
              </div>
              <CardDescription>
                Executive-wise breakdown of sales and revenue
              </CardDescription>
            </CardHeader>
            <CardContent className="pl-0 pr-0">
              {activeData && activeData.teamMembers && activeData.teamMembers.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50 hover:bg-muted/50">
                      <TableHead className="text-center">#</TableHead>
                      <TableHead>Executive</TableHead>
                      <TableHead className="text-right">Revenue</TableHead>
                      <TableHead className="text-right">Area Sold</TableHead>
                      <TableHead className="text-right">Deals</TableHead>
                      <TableHead className="text-right">Contribution</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activeData.teamMembers
                      .sort((a, b) => b.totalSales - a.totalSales)
                      .map((member, index) => {
                        const contribution = activeData.teamTotal.totalTeamSales > 0
                          ? Math.round((member.totalSales / activeData.teamTotal.totalTeamSales) * 100)
                          : 0;
                          
                        return (
                          <TableRow key={member.salesExecutiveId}>
                            <TableCell className="text-center font-medium text-muted-foreground">
                              {index + 1}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-7 w-7 border">
                                  <AvatarImage src={member.imageUrl || undefined} alt={member.fullName} />
                                  <AvatarFallback>
                                    {member.fullName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="font-medium">{member.fullName}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-right font-medium">
                              ₹{member.totalSales.toLocaleString()}
                            </TableCell>
                            <TableCell className="text-right">
                              {member.totalArea.toLocaleString()} sq. ft.
                            </TableCell>
                            <TableCell className="text-right">
                              {member.salesCount}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-2">
                                <p className="text-sm font-medium">{contribution}%</p>
                                <div className="w-16 h-2 bg-gray-100 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-primary" 
                                    style={{ width: `${contribution}%` }}
                                  />
                                </div>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No team performance data available for this period
                </div>
              )}
            </CardContent>
            {activeData && activeData.teamTotal && (
              <CardFooter className="border-t bg-muted/20 flex justify-between px-6 py-4">
                <div>
                  <p className="text-sm font-medium">Team Total</p>
                  <p className="text-xs text-muted-foreground">All Time Performance</p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-sm font-medium">₹{activeData.teamTotal.totalTeamSales.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Total Revenue</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{activeData.teamTotal.totalTeamArea.toLocaleString()} sq. ft.</p>
                    <p className="text-xs text-muted-foreground">Total Area</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{activeData.teamTotal.totalTeamCount}</p>
                    <p className="text-xs text-muted-foreground">Total Deals</p>
                  </div>
                </div>
              </CardFooter>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}