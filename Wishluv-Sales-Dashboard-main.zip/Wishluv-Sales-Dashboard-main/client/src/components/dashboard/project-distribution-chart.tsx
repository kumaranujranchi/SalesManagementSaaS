import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend, 
  Tooltip 
} from "recharts";
import { motion } from "framer-motion";
import { Project } from "@shared/schema";
import { useEffect, useState } from "react";

// Define colors for the pie chart - using brighter colors for better visibility
const COLORS = ['#FF9F40', '#36A2EB', '#9966FF', '#4BC0C0', '#FF6384'];

// Custom label component with controlled font size
const CustomLabel = (props: any) => {
  const { cx, cy, midAngle, innerRadius, outerRadius, percent, index } = props;
  const RADIAN = Math.PI / 180;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  
  // Only show percentage value with better contrast
  const percentValue = `${(percent * 100).toFixed(0)}%`;
  
  return (
    <text 
      x={x} 
      y={y} 
      fill="white" 
      textAnchor="middle" 
      dominantBaseline="central"
      fontSize={12}
      fontWeight="bold"
      stroke="black"
      strokeWidth={0.5}
      paintOrder="stroke"
    >
      {percentValue}
    </text>
  );
};

export function ProjectDistributionChart() {
  const { data: projects, isLoading, error } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  // Process data for the pie chart
  const generateProjectTypeData = (projects?: Project[]) => {
    if (!projects || projects.length === 0) {
      // Sample data if no projects available
      return [
        { name: 'Land', value: 30 },
        { name: 'Apartment', value: 45 },
        { name: 'Duplex', value: 25 },
      ];
    }

    // Count project types
    const typeCounts: Record<string, number> = {};
    
    projects.forEach(project => {
      const type = project.projectType || 'Unknown';
      typeCounts[type] = (typeCounts[type] || 0) + 1;
    });

    // Convert to array format for PieChart
    return Object.entries(typeCounts).map(([name, value]) => ({ name, value }));
  };

  const pieData = generateProjectTypeData(projects);

  // Animation variants for the pie chart
  const containerVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.5,
        delay: 0.1
      }
    }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <Card className="h-full overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50">
          <CardTitle className="text-lg font-semibold text-indigo-700">Project Distribution</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {isLoading ? (
            <div className="pt-6">
              <Skeleton className="h-[180px] w-full" />
            </div>
          ) : error ? (
            <p className="text-red-500">Failed to load project data</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={75}
                  innerRadius={35}
                  paddingAngle={3}
                  fill="#8884d8"
                  dataKey="value"
                  label={<CustomLabel />}
                  stroke="#ffffff"
                  strokeWidth={2}
                  animationBegin={0}
                  animationDuration={1000}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value, name) => [`${value} projects`, `${name}`]}
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.98)',
                    borderRadius: '8px',
                    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.15)',
                    border: '1px solid #eaeaea',
                    fontSize: '13px',
                    padding: '8px 12px',
                    color: '#333',
                    fontWeight: '500'
                  }}
                  wrapperStyle={{ zIndex: 1000 }}
                  labelStyle={{ fontWeight: 'bold', marginBottom: '5px' }}
                />
                <Legend 
                  layout="horizontal" 
                  verticalAlign="bottom" 
                  align="center"
                  wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}
                  iconSize={12}
                  formatter={(value, entry) => <span style={{ color: '#333', fontWeight: 'bold' }}>{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}