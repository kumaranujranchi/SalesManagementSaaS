import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Users, TrendingUp, Calendar } from "lucide-react";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { SalesDesignation } from "../../lib/sales-designation";

interface TeamMemberPerformance {
  salesExecutiveId: number;
  fullName: string;
  team: string;
  totalSales: number;
  totalArea: number;
  salesCount: number;
}

export function TeamPerformance() {
  const { user } = useAuth();
  const [selectedTeam, setSelectedTeam] = useState<string | undefined>(
    user?.designation === SalesDesignation.TEAM_LEADER && user.team ? user.team : undefined
  );
  
  // Only Sales Head can select different teams
  const canSelectTeam = user?.designation === SalesDesignation.SALES_HEAD;
  
  // Handle team selection change (only for Sales Head)
  const handleTeamChange = (value: string) => {
    setSelectedTeam(value === "all" ? undefined : value);
  };

  // Query for team monthly performance
  const { 
    data: monthlyData, 
    isLoading: monthlyLoading, 
    error: monthlyError 
  } = useQuery<TeamMemberPerformance[]>({
    queryKey: ["/api/team-sales-monthly", selectedTeam],
    queryFn: async () => {
      const url = selectedTeam 
        ? `/api/team-sales-monthly?team=${encodeURIComponent(selectedTeam)}` 
        : "/api/team-sales-monthly";
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch monthly team data");
      return res.json();
    },
    enabled: user?.designation === SalesDesignation.TEAM_LEADER || user?.designation === SalesDesignation.SALES_HEAD
  });

  // Query for team yearly performance
  const { 
    data: yearlyData, 
    isLoading: yearlyLoading, 
    error: yearlyError 
  } = useQuery<TeamMemberPerformance[]>({
    queryKey: ["/api/team-sales-yearly", selectedTeam],
    queryFn: async () => {
      const url = selectedTeam 
        ? `/api/team-sales-yearly?team=${encodeURIComponent(selectedTeam)}` 
        : "/api/team-sales-yearly";
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch yearly team data");
      return res.json();
    },
    enabled: user?.designation === SalesDesignation.TEAM_LEADER || user?.designation === SalesDesignation.SALES_HEAD
  });

  // Query for team all-time performance
  const { 
    data: allTimeData, 
    isLoading: allTimeLoading, 
    error: allTimeError 
  } = useQuery<TeamMemberPerformance[]>({
    queryKey: ["/api/team-sales", selectedTeam],
    queryFn: async () => {
      const url = selectedTeam 
        ? `/api/team-sales?team=${encodeURIComponent(selectedTeam)}` 
        : "/api/team-sales";
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch all-time team data");
      return res.json();
    },
    enabled: user?.designation === SalesDesignation.TEAM_LEADER || user?.designation === SalesDesignation.SALES_HEAD
  });

  // If user is not a Team Leader or Sales Head, don't show this component
  if (user?.designation !== SalesDesignation.TEAM_LEADER && user?.designation !== SalesDesignation.SALES_HEAD) {
    return null;
  }

  const isLoading = monthlyLoading || yearlyLoading || allTimeLoading;
  const hasError = monthlyError || yearlyError || allTimeError;

  // Format currency for display
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Format number with commas for display
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-IN').format(num);
  };

  return (
    <Card className="col-span-12">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <Users className="h-5 w-5" /> 
              {user?.designation === SalesDesignation.TEAM_LEADER && user.team
                ? `${user.team} Performance` 
                : "Team Performance"}
            </CardTitle>
            <CardDescription>
              {user?.designation === SalesDesignation.TEAM_LEADER 
                ? "Monitor your team members' sales performance" 
                : "Monitor all sales teams' performance"}
            </CardDescription>
          </div>
          
          {canSelectTeam && (
            <Select onValueChange={handleTeamChange} defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Team" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Teams</SelectLabel>
                  <SelectItem value="all">All Teams</SelectItem>
                  <SelectItem value="Team Manish">Team Manish</SelectItem>
                  <SelectItem value="Team Kaustuv">Team Kaustuv</SelectItem>
                  <SelectItem value="Team Awinash">Team Awinash</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="monthly" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="monthly" className="flex items-center gap-1">
              <Calendar className="h-4 w-4" /> Monthly
            </TabsTrigger>
            <TabsTrigger value="yearly" className="flex items-center gap-1">
              <TrendingUp className="h-4 w-4" /> Yearly
            </TabsTrigger>
            <TabsTrigger value="all-time" className="flex items-center gap-1">
              <Users className="h-4 w-4" /> All Time
            </TabsTrigger>
          </TabsList>
          
          {isLoading && (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          
          {hasError && (
            <div className="flex justify-center items-center h-64 text-red-500">
              Error loading team performance data. Please try again later.
            </div>
          )}
          
          {!isLoading && !hasError && (
            <>
              <TabsContent value="monthly">
                <div className="rounded-md border">
                  <div className="w-full overflow-auto">
                    <table className="w-full caption-bottom text-sm">
                      <thead className="[&_tr]:border-b">
                        <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                          <th className="h-12 px-4 text-left align-middle font-medium">Rank</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Sales Executive</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Team</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Total Sales</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Area Sold (sq.ft)</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Sales Count</th>
                        </tr>
                      </thead>
                      <tbody className="[&_tr:last-child]:border-0">
                        {monthlyData && monthlyData.length > 0 ? (
                          monthlyData.map((member, index) => (
                            <tr 
                              key={member.salesExecutiveId} 
                              className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                            >
                              <td className="p-4 align-middle">{index + 1}</td>
                              <td className="p-4 align-middle font-medium">{member.fullName}</td>
                              <td className="p-4 align-middle">{member.team || '-'}</td>
                              <td className="p-4 align-middle">{formatCurrency(Number(member.totalSales))}</td>
                              <td className="p-4 align-middle">{formatNumber(Number(member.totalArea))}</td>
                              <td className="p-4 align-middle">{member.salesCount}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={6} className="p-4 text-center">No monthly sales data available</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="yearly">
                <div className="rounded-md border">
                  <div className="w-full overflow-auto">
                    <table className="w-full caption-bottom text-sm">
                      <thead className="[&_tr]:border-b">
                        <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                          <th className="h-12 px-4 text-left align-middle font-medium">Rank</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Sales Executive</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Team</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Total Sales</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Area Sold (sq.ft)</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Sales Count</th>
                        </tr>
                      </thead>
                      <tbody className="[&_tr:last-child]:border-0">
                        {yearlyData && yearlyData.length > 0 ? (
                          yearlyData.map((member, index) => (
                            <tr 
                              key={member.salesExecutiveId} 
                              className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                            >
                              <td className="p-4 align-middle">{index + 1}</td>
                              <td className="p-4 align-middle font-medium">{member.fullName}</td>
                              <td className="p-4 align-middle">{member.team || '-'}</td>
                              <td className="p-4 align-middle">{formatCurrency(Number(member.totalSales))}</td>
                              <td className="p-4 align-middle">{formatNumber(Number(member.totalArea))}</td>
                              <td className="p-4 align-middle">{member.salesCount}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={6} className="p-4 text-center">No yearly sales data available</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="all-time">
                <div className="rounded-md border">
                  <div className="w-full overflow-auto">
                    <table className="w-full caption-bottom text-sm">
                      <thead className="[&_tr]:border-b">
                        <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                          <th className="h-12 px-4 text-left align-middle font-medium">Rank</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Sales Executive</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Team</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Total Sales</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Area Sold (sq.ft)</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Sales Count</th>
                        </tr>
                      </thead>
                      <tbody className="[&_tr:last-child]:border-0">
                        {allTimeData && allTimeData.length > 0 ? (
                          allTimeData.map((member, index) => (
                            <tr 
                              key={member.salesExecutiveId} 
                              className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                            >
                              <td className="p-4 align-middle">{index + 1}</td>
                              <td className="p-4 align-middle font-medium">{member.fullName}</td>
                              <td className="p-4 align-middle">{member.team || '-'}</td>
                              <td className="p-4 align-middle">{formatCurrency(Number(member.totalSales))}</td>
                              <td className="p-4 align-middle">{formatNumber(Number(member.totalArea))}</td>
                              <td className="p-4 align-middle">{member.salesCount}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={6} className="p-4 text-center">No sales data available</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </TabsContent>
            </>
          )}
        </Tabs>
      </CardContent>
    </Card>
  );
}