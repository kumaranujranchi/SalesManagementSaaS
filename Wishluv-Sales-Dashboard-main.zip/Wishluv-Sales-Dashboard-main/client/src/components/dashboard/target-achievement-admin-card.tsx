import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Target, TrendingUp } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { getMonthName } from "@/lib/date-utils";

interface TargetAchievementAdminCardProps {
  userId: number;
  userName: string;
  target?: number;
}

export function TargetAchievementAdminCard({ userId, userName, target = 0 }: TargetAchievementAdminCardProps) {
  const { toast } = useToast();
  const [progress, setProgress] = useState(0);
  
  const now = new Date();
  const currentMonth = now.getMonth() + 1; // 1-12
  const currentYear = now.getFullYear();
  
  const { data: achievement, isLoading, error, refetch } = useQuery({
    queryKey: ["/api/targets/achievement", userId],
    queryFn: async () => {
      // Add cache busting parameters
      const timestamp = new Date().getTime();
      const res = await fetch(`/api/targets/achievement/${userId}?fresh=true&ts=${timestamp}`);
      if (!res.ok) {
        throw new Error("Failed to fetch achievement data");
      }
      return res.json();
    },
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 5000 // Consider data fresh for 5 seconds
  });
  
  // Periodically refetch achievement data
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 30000); // Refresh every 30 seconds
    
    return () => clearInterval(interval);
  }, [refetch]);
  
  // Handle errors from the query
  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch achievement data",
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  // Process achievement data when it's available
  useEffect(() => {
    if (achievement) {
      // Calculate the percentage for current month
      const monthData = achievement.monthlyBreakdown?.find(
        (m: any) => m.month === currentMonth && m.year === currentYear
      );
      
      if (monthData) {
        const currentTarget = monthData.target || target || 0;
        const achieved = monthData.achieved || 0;
        const percentage = currentTarget > 0 ? Math.min(Math.round((achieved / currentTarget) * 100), 100) : 0;
        
        setProgress(percentage);
      }
    }
  }, [achievement, target, currentMonth, currentYear]);
  
  // Loading state
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">
            <Skeleton className="h-4 w-36" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-2 w-full mb-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <Skeleton className="h-3 w-16" />
            <Skeleton className="h-3 w-16" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // No data state
  if (!achievement) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">{userName}</CardTitle>
          <CardDescription className="text-xs">No target data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-2 text-xs text-muted-foreground">
            <Target className="h-3 w-3 mr-1" />
            <span>No target set</span>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Get current month data
  const currentMonthData = achievement.monthlyBreakdown?.find(
    (m: any) => m.month === currentMonth && m.year === currentYear
  ) || { target: target || 0, achieved: 0 };
  
  const currentTarget = currentMonthData.target || target || 0;
  const currentAchieved = currentMonthData.achieved || 0;
  
  // Full card with data
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">{userName}</CardTitle>
        <CardDescription className="text-xs">
          {getMonthName(currentMonth)} {currentYear}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Progress value={progress} className="h-2 mb-1" />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{progress}%</span>
          <span>
            {currentAchieved.toLocaleString()} / {currentTarget.toLocaleString()} sqft
          </span>
        </div>
      </CardContent>
      {achievement.totalAchieved && achievement.totalAchieved > 0 && (
        <CardFooter className="border-t pt-2 pb-2 text-xs text-muted-foreground">
          <div className="flex items-center space-x-1">
            <TrendingUp className="h-3 w-3" />
            <span>
              YTD: {achievement.yearProgress || 0}% ({(achievement.totalAchieved || 0).toLocaleString()} sqft)
            </span>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}