import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Project } from "@shared/schema";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { Building, Calendar, Clock } from "lucide-react";
import { format } from "date-fns";

export function ProjectDetails() {
  const { data: projects = [], isLoading, error } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  // Sort projects by creation date (newest first)
  const recentProjects = projects.length > 0 
    ? [...projects]
        .sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        })
        .slice(0, 3) // Show only the 3 most recent projects
    : [];

  // Get status badge styling based on status
  const getStatusBadgeStyle = (status: string | null) => {
    if (!status) return "bg-gray-200 text-gray-800";
    
    switch (status.toLowerCase()) {
      case 'running':
      case 'in progress':
        return "bg-green-100 text-green-800";
      case 'on_hold':
      case 'delayed':
        return "bg-amber-100 text-amber-800";
      case 'closed':
      case 'completed':
        return "bg-blue-100 text-blue-800";
      case 'pending':
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Format deadline date
  const formatDeadline = (date: Date | string | null) => {
    if (!date) return "Not set";
    try {
      return format(new Date(date), "MMM d, yyyy");
    } catch (e) {
      return "Invalid date";
    }
  };

  // Format the creation date
  const formatCreatedAt = (date: Date | string | null) => {
    if (!date) return "Unknown";
    try {
      return format(new Date(date), "MMM d, yyyy");
    } catch (e) {
      return "Unknown date";
    }
  };

  return (
    <Card className="h-full shadow-md">
      <CardHeader className="bg-gradient-to-r from-slate-50 to-blue-50 pb-3">
        <CardTitle className="flex items-center gap-2 text-blue-700">
          <Building className="h-5 w-5" />
          Recent Projects
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-full" />
          </div>
        ) : error ? (
          <p className="text-red-500">Failed to load project details</p>
        ) : recentProjects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Building className="h-12 w-12 text-muted-foreground mb-3 opacity-30" />
            <h3 className="text-lg font-medium mb-1">No Projects Found</h3>
            <p className="text-sm text-muted-foreground max-w-xs">
              Create your first project to see it here
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentProjects.map((project, index) => (
              <motion.div 
                key={project.id}
                className="p-3 border rounded-md bg-white hover:bg-slate-50 transition-colors"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="flex flex-wrap justify-between items-start mb-2 gap-1">
                  <h3 className="font-medium text-blue-700 text-sm md:text-base line-clamp-1 mr-2">{project.name}</h3>
                  <div>
                    <Badge className={cn("font-medium text-[10px] md:text-xs px-1.5 md:px-2 py-0.5", getStatusBadgeStyle(project.status))}>
                      {project.status || 'Unknown'}
                    </Badge>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-xs md:text-sm">
                  <div className="flex items-center gap-1 text-slate-500">
                    <Calendar className="h-3 md:h-3.5 w-3 md:w-3.5 flex-shrink-0" />
                    <span className="whitespace-nowrap">Created:</span>
                  </div>
                  <div className="text-slate-700 truncate">
                    {formatCreatedAt(project.createdAt)}
                  </div>
                  
                  <div className="flex items-center gap-1 text-slate-500">
                    <Clock className="h-3 md:h-3.5 w-3 md:w-3.5 flex-shrink-0" />
                    <span className="whitespace-nowrap">Deadline:</span>
                  </div>
                  <div className="text-slate-700 truncate">
                    {formatDeadline(project.deadline)}
                  </div>
                </div>
                
                {project.description && (
                  <p className="text-[10px] md:text-xs text-slate-600 mt-2 line-clamp-2">
                    {project.description}
                  </p>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
