import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Target, TrendingUp, CalendarDays } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { getMonthName } from "@/lib/date-utils";

export function TargetAchievementCard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [progress, setProgress] = useState(0);
  const [achievementSummary, setAchievementSummary] = useState<any>(null);
  
  const now = new Date();
  const currentMonth = now.getMonth() + 1; // 1-12
  const currentYear = now.getFullYear();
  
  // Only fetch data if user is in Sales department
  const { data: achievement, isLoading, error, refetch } = useQuery({
    queryKey: ["/api/targets/achievement", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      // Add cache busting parameters
      const timestamp = new Date().getTime();
      const res = await fetch(`/api/targets/achievement/${user.id}?fresh=true&ts=${timestamp}`);
      
      if (!res.ok) {
        throw new Error("Failed to fetch achievement data");
      }
      return res.json();
    },
    enabled: !!user?.id && user?.department === "Sales",
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 5000 // Consider data fresh for 5 seconds
  });
  
  // Periodically refetch achievement data to ensure we have latest sales data
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 30000); // Refresh every 30 seconds
    
    return () => clearInterval(interval);
  }, [refetch]);
  
  // Handle errors from the query
  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch achievement data",
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  // Process achievement data when it's available
  useEffect(() => {
    if (achievement) {
      setAchievementSummary(achievement);
      
      // Calculate the percentage for current month
      const monthData = achievement.monthlyBreakdown?.find(
        (m: any) => m.month === currentMonth && m.year === currentYear
      );
      
      if (monthData) {
        const target = monthData.target || user?.monthlyTarget || 0;
        const achieved = monthData.achieved || 0;
        const percentage = target > 0 ? Math.min(Math.round((achieved / target) * 100), 100) : 0;
        
        // Animate progress bar
        let startValue = 0;
        const animationDuration = 1500; // ms
        const startTime = Date.now();
        
        const animateProgress = () => {
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / animationDuration, 1);
          setProgress(Math.floor(progress * percentage));
          
          if (progress < 1) {
            requestAnimationFrame(animateProgress);
          }
        };
        
        requestAnimationFrame(animateProgress);
      }
    }
  }, [achievement, user?.monthlyTarget, currentMonth, currentYear]);
  
  // Skip if not a sales user - after hooks but before rendering
  if (user?.department !== "Sales") {
    return null;
  }
  
  // Loading state
  if (isLoading) {
    return (
      <Card className="bg-primary/10">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-lg">
            <Target className="mr-2 h-5 w-5" />
            <Skeleton className="h-4 w-36" />
          </CardTitle>
          <CardDescription>
            <Skeleton className="h-3 w-24" />
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-2 w-full mb-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <Skeleton className="h-3 w-16" />
            <Skeleton className="h-3 w-16" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // No data state
  if (!achievementSummary) {
    return (
      <Card className="bg-primary/10">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-lg">
            <Target className="mr-2 h-5 w-5" />
            Sales Target
          </CardTitle>
          <CardDescription>No target data available</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm">Please ask your manager to set a monthly target.</p>
        </CardContent>
      </Card>
    );
  }

  // Get current month data
  const currentMonthData = achievementSummary.monthlyBreakdown?.find(
    (m: any) => m.month === currentMonth && m.year === currentYear
  ) || { target: user?.monthlyTarget || 0, achieved: 0 };
  
  // Ensure values are numbers, not null/undefined
  const currentTarget = currentMonthData.target || 0;
  const currentAchieved = currentMonthData.achieved || 0;
  const totalAchieved = achievementSummary.totalAchieved || 0;
  const yearProgress = achievementSummary.yearProgress || 0;
  
  // Full card with data
  return (
    <Card className="bg-primary/10">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-lg">
          <Target className="mr-2 h-5 w-5" />
          Sales Target
        </CardTitle>
        <CardDescription>
          {getMonthName(currentMonth)} {currentYear} Performance
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Progress value={progress} className="h-2 mb-2" />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Progress: {progress}%</span>
          <span>
            {currentAchieved.toLocaleString()} / {currentTarget.toLocaleString()} sqft
          </span>
        </div>
      </CardContent>
      <CardFooter className="border-t pt-4 text-xs text-muted-foreground">
        <div className="flex items-center space-x-1">
          <TrendingUp className="h-3 w-3" />
          <span>
            {totalAchieved.toLocaleString()} sqft total for {currentYear}
          </span>
        </div>
        <div className="ml-auto flex items-center space-x-1">
          <CalendarDays className="h-3 w-3" />
          <span>YTD Performance: {yearProgress}%</span>
        </div>
      </CardFooter>
    </Card>
  );
}