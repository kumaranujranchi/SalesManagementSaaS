import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Area, 
  AreaChart, 
  ResponsiveContainer, 
  Tooltip, 
  XAxis, 
  YAxis,
  CartesianGrid,
  Legend,
  Bar,
  BarChart,
  Cell
} from "recharts";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { format, parseISO, startOfMonth, endOfMonth, eachMonthOfInterval, subMonths } from "date-fns";

export function SalesOverviewChart() {
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [periodType, setPeriodType] = useState<'ytd' | 'quarterly'>('ytd');
  
  // Query yearly sales data for chart
  const { data: salesData, isLoading, error } = useQuery<any[]>({
    queryKey: ["/api/sales-yearly"],
  });

  // Prepare monthly aggregated data for the chart
  useEffect(() => {
    if (!salesData || salesData.length === 0) return;
    
    // Create empty months array for the past 12 months
    const today = new Date();
    const lastYear = subMonths(today, 11);
    const monthsRange = eachMonthOfInterval({
      start: startOfMonth(lastYear), 
      end: endOfMonth(today)
    });
    
    const monthlyAggregated = monthsRange.map(month => {
      const monthStr = format(month, 'MMM');
      const salesInMonth = salesData.filter(sale => {
        const saleDate = parseISO(sale.bookingDate);
        return (
          saleDate.getMonth() === month.getMonth() && 
          saleDate.getFullYear() === month.getFullYear()
        );
      });
      
      // Calculate totals
      const totalSales = salesInMonth.reduce((total, sale) => {
        const saleAmount = sale.finalAmount ? Number(sale.finalAmount) : 0;
        return total + saleAmount;
      }, 0);
      
      const totalArea = salesInMonth.reduce((total, sale) => {
        return total + (Number(sale.areaSold) || 0);
      }, 0);
      
      return {
        month: monthStr,
        fullMonth: format(month, 'MMMM yyyy'),
        totalSales,
        totalArea,
        count: salesInMonth.length
      };
    });
    
    setMonthlyData(monthlyAggregated);
  }, [salesData]);

  // Format currency values for display
  const formatCurrency = (value: number) => {
    if (value >= 10000000) {
      return `₹${(value / 10000000).toFixed(1)}Cr`;
    } else if (value >= 100000) {
      return `₹${(value / 100000).toFixed(1)}L`;
    } else if (value >= 1000) {
      return `₹${(value / 1000).toFixed(0)}K`;
    }
    return `₹${value}`;
  };

  // Get colors based on value
  const getBarColor = (value: number, index: number) => {
    const baseColors = ['#f97316', '#06b6d4', '#8b5cf6', '#10b981', '#f59e0b'];
    // Use a base color with opacity based on value relative to max
    const maxValue = Math.max(...monthlyData.map(item => item.totalSales));
    const opacity = 0.3 + (value / maxValue) * 0.7;
    return baseColors[index % baseColors.length];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="h-full overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-orange-50 to-yellow-50">
          <div className="flex flex-col md:flex-row md:justify-between md:items-center">
            <div>
              <CardTitle className="text-lg font-semibold text-orange-700">Sales Overview</CardTitle>
              <CardDescription className="text-orange-600 opacity-70 text-sm">
                Monthly trends by revenue and volume
              </CardDescription>
            </div>
            <div className="flex space-x-2 mt-2 md:mt-0">
              <button
                onClick={() => setPeriodType('ytd')}
                className={`px-3 py-1 text-xs rounded-full ${periodType === 'ytd' 
                  ? 'bg-orange-500 text-white' 
                  : 'bg-orange-100 text-orange-700'}`}
              >
                Year to Date
              </button>
              <button
                onClick={() => setPeriodType('quarterly')}
                className={`px-3 py-1 text-xs rounded-full ${periodType === 'quarterly' 
                  ? 'bg-orange-500 text-white' 
                  : 'bg-orange-100 text-orange-700'}`}
              >
                Last 3 Months
              </button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          {isLoading ? (
            <div className="pt-6">
              <Skeleton className="h-[200px] w-full" />
            </div>
          ) : error ? (
            <p className="text-red-500">Failed to load sales data</p>
          ) : monthlyData.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[250px] text-gray-500">
              <p>No sales data available for the selected period.</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart
                data={periodType === 'quarterly' 
                  ? monthlyData.slice(-3) 
                  : monthlyData}
                margin={{ top: 20, right: 10, left: 10, bottom: 30 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                <XAxis 
                  dataKey="month" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 10, fill: '#6B7280' }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 10, fill: '#6B7280' }}
                  tickFormatter={(value) => formatCurrency(value)}
                  width={60}
                />
                <Tooltip 
                  formatter={(value) => [formatCurrency(Number(value)), '']}
                  labelFormatter={(label, items) => {
                    const dataItem = monthlyData.find(item => item.month === label);
                    return dataItem ? dataItem.fullMonth : label;
                  }}
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                    border: 'none',
                    fontSize: '12px'
                  }}
                  wrapperStyle={{ zIndex: 1000 }}
                />
                <Legend 
                  verticalAlign="top" 
                  height={36}
                  iconSize={10}
                  wrapperStyle={{ fontSize: '10px', paddingTop: '5px' }}
                />
                <Bar 
                  dataKey="totalSales" 
                  name="Revenue" 
                  radius={[4, 4, 0, 0]}
                >
                  {monthlyData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getBarColor(entry.totalSales, index)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}