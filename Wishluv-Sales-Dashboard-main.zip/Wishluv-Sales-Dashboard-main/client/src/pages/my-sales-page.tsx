import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  FileText, 
  Search, 
  Filter, 
  Eye, 
  ChevronUp, 
  ChevronDown,
  BarChart as BarChartIcon,
  TrendingUp,
  Trophy,
  Users,
  PieChartIcon,
  Loader2,
  X,
  UserCircle,
  Home,
  Map,
  Calendar,
  IndianRupee,
  CreditCard,
  PieChart,
  InfoIcon,
  Ban
} from "lucide-react";
import { Sales } from "@shared/schema";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend, 
  ResponsiveContainer, 
  Cell,
  PieChart as RechartsChart,
  Pie
} from "recharts";
import { Badge } from "@/components/ui/badge";

// Helper components for Sales Page
function SalesSummaryCard({
  title,
  value,
  description,
  icon,
  trend,
}: {
  title: string;
  value: string | number;
  description?: string;
  icon: React.ReactNode;
  trend?: number;
}) {
  const renderTrend = () => {
    if (trend === undefined) return null;
    
    return (
      <div className={`text-xs font-medium ${trend >= 0 ? "text-green-600" : "text-red-600"}`}>
        {trend >= 0 ? "+" : ""}{trend}%
      </div>
    );
  };

  return (
    <Card className="overflow-hidden border-amber-100 h-full">
      <CardHeader className="bg-amber-50 pb-2">
        <CardTitle className="text-xs md:text-sm font-medium text-amber-900 flex items-center gap-2">
          <span className="flex-shrink-0">{icon}</span>
          <span className="truncate">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 md:p-4 flex flex-col justify-between h-full">
        <div className="text-lg md:text-xl lg:text-2xl font-bold text-amber-950 break-words">{value}</div>
        {description && (
          <p className="text-xs text-amber-700 mt-1 flex items-center justify-between gap-2">
            <span className="truncate flex-1">{description}</span>
            {renderTrend()}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

// Performance Chart Component
function SalesPerformanceChart({ 
  salesData, 
  userSalesData 
}: { 
  salesData: any[]; 
  userSalesData: any[];
}) {
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (!salesData || !userSalesData) return;

    // Process data for chart
    const currentDate = new Date();
    const lastSixMonths: any[] = [];
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(currentDate);
      date.setMonth(currentDate.getMonth() - i);
      const monthName = date.toLocaleString('default', { month: 'short' });
      const year = date.getFullYear();
      const monthYear = `${monthName} ${year}`;
      const month = date.getMonth();
      const fullYear = date.getFullYear();

      // Filter sales data for this month and year
      const teamSalesThisMonth = salesData.filter(sale => {
        const saleDate = new Date(sale.bookingDate);
        return saleDate.getMonth() === month && saleDate.getFullYear() === fullYear;
      });
      
      // Filter user sales data for this month and year
      const userSalesThisMonth = userSalesData.filter(sale => {
        const saleDate = new Date(sale.bookingDate);
        return saleDate.getMonth() === month && saleDate.getFullYear() === fullYear;
      });
      
      // Calculate total sales volume for team and user
      const teamSalesVolume = teamSalesThisMonth.reduce((total, sale) => {
        return total + parseFloat(sale.areaSold || 0);
      }, 0);
      
      const userSalesVolume = userSalesThisMonth.reduce((total, sale) => {
        return total + parseFloat(sale.areaSold || 0);
      }, 0);
      
      lastSixMonths.push({
        name: monthName,
        Team: Math.round(teamSalesVolume),
        You: Math.round(userSalesVolume),
        monthYear
      });
    }
    
    setChartData(lastSixMonths);
  }, [salesData, userSalesData]);

  const colors = {
    Team: "#f59e0b",  // amber-500
    You: "#78350f"    // amber-900
  };

  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-amber-900">Sales Performance Trend</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="name" 
                  fontSize={12}
                  tick={{ fill: '#78350f' }}
                />
                <YAxis 
                  fontSize={12}
                  tick={{ fill: '#78350f' }}
                  label={{ 
                    value: 'Area (sq.ft.)', 
                    angle: -90, 
                    position: 'insideLeft',
                    style: { textAnchor: 'middle', fill: '#78350f' }
                  }}
                />
                <RechartsTooltip 
                  formatter={(value: number) => [`${value.toLocaleString()} sq.ft.`, undefined]}
                  labelFormatter={(label) => {
                    const item = chartData.find(item => item.name === label);
                    return item ? item.monthYear : label;
                  }}
                />
                <Legend />
                <Bar dataKey="Team" fill={colors.Team}>
                  {chartData.map((_, index) => (
                    <Cell key={`cell-team-${index}`} fill={colors.Team} />
                  ))}
                </Bar>
                <Bar dataKey="You" fill={colors.You}>
                  {chartData.map((_, index) => (
                    <Cell key={`cell-you-${index}`} fill={colors.You} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground">No data available</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Team Leaderboard Component
function TeamLeaderboard({ usersData, salesData }: { usersData: any[]; salesData: any[] }) {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  
  if (!usersData || !salesData) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg text-amber-900">Team Leaderboard</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">Loading team data...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate team metrics
  const teamMetrics = usersData
    .filter(u => 
      u.department === "Sales" && 
      u.status && 
      (u.designation === "Sales Executive" || u.designation === "Executive")
    )
    .map(salesUser => {
      const userSalesItems = salesData.filter(sale => 
        sale.salesExecutiveId === salesUser.id
      ) || [];
      
      const totalAreaSold = userSalesItems.reduce((total, sale) => 
        total + parseFloat(sale.areaSold || 0), 0
      );
      
      const totalAmount = userSalesItems.reduce((total, sale) => 
        total + parseFloat(sale.finalAmount || 0), 0
      );
      
      return {
        id: salesUser.id,
        name: salesUser.fullName,
        imageUrl: salesUser.imageUrl,
        team: salesUser.team,
        totalAreaSold,
        totalAmount,
        salesCount: userSalesItems.length
      };
    })
    .sort((a, b) => b.totalAreaSold - a.totalAreaSold)
    .slice(0, 5);

  // Find current user's rank
  const currentUserRank = usersData
    .filter(u => 
      u.department === "Sales" && 
      u.status && 
      (u.designation === "Sales Executive" || u.designation === "Executive")
    )
    .map(salesUser => {
      const userSalesItems = salesData.filter(sale => 
        sale.salesExecutiveId === salesUser.id
      ) || [];
      
      const totalAreaSold = userSalesItems.reduce((total, sale) => 
        total + parseFloat(sale.areaSold || 0), 0
      );
      
      return {
        id: salesUser.id,
        totalAreaSold
      };
    })
    .sort((a, b) => b.totalAreaSold - a.totalAreaSold)
    .findIndex(u => u.id === user?.id) + 1;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-amber-900">Team Leaderboard</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {teamMetrics.length === 0 ? (
            <div className="text-center text-muted-foreground py-4">No data available</div>
          ) : (
            teamMetrics.map((metric, index) => (
              <div 
                key={metric.id} 
                className={`flex items-center justify-between p-3 rounded-md ${
                  metric.id === user?.id 
                    ? "bg-amber-50 border border-amber-200" 
                    : "hover:bg-gray-50"
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <div className="h-10 w-10 rounded-full overflow-hidden bg-amber-100 flex items-center justify-center">
                      {metric.imageUrl ? (
                        <img 
                          src={metric.imageUrl} 
                          alt={metric.name} 
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span className="text-lg font-semibold text-amber-700">
                          {metric.name?.charAt(0)}
                        </span>
                      )}
                    </div>
                    <div className="absolute -top-1 -left-1 bg-amber-100 rounded-full p-0.5">
                      {index === 0 ? (
                        <Trophy className="h-5 w-5 text-amber-500" />
                      ) : (
                        <div className="h-5 w-5 rounded-full bg-amber-500 flex items-center justify-center text-white font-bold text-xs">
                          {index + 1}
                        </div>
                      )}
                    </div>
                  </div>
                  <div>
                    <div className="font-medium text-amber-900">{metric.name}</div>
                    <div className="text-xs text-amber-700">{metric.team}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-amber-900">{metric.totalAreaSold.toLocaleString()} sq.ft.</div>
                  <div className="text-xs text-amber-700">{metric.salesCount} sales</div>
                </div>
              </div>
            ))
          )}
          
          {user && currentUserRank > 5 && (
            <div className="mt-2 p-3 bg-amber-50 rounded-md border border-amber-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-900 font-medium">
                    {currentUserRank}
                  </div>
                  <div className="font-medium text-amber-900">Your Rank</div>
                </div>
                <div className="text-amber-900 font-medium">Keep going! 💪</div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Sales Details Dialog Component
function SalesDetailsDialog({
  open,
  onOpenChange,
  selectedSale,
  projectsData = [],
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedSale: Sales | null;
  projectsData?: any[];
}) {
  const [activeTab, setActiveTab] = useState("details");
  const [totalPayments, setTotalPayments] = useState(0);
  const [remainingBalance, setRemainingBalance] = useState(0);

  // Fetch payment data for the sale
  const { data: paymentData } = useQuery<any[]>({
    queryKey: ["/api/payments", selectedSale?.id],
    queryFn: async () => {
      if (!selectedSale) return [];
      const res = await fetch(`/api/payments/${selectedSale.id}`);
      if (!res.ok) {
        throw new Error("Failed to fetch payment data");
      }
      return res.json();
    },
    enabled: !!selectedSale && open,
  });

  // Calculate total payments and remaining balance
  useEffect(() => {
    if (selectedSale && paymentData) {
      const total = paymentData.reduce(
        (sum, payment) => sum + parseFloat(payment.amount || "0"),
        0
      );
      setTotalPayments(total);
      
      const finalAmount = parseFloat(selectedSale.finalAmount || "0");
      setRemainingBalance(finalAmount - total);
    }
  }, [selectedSale, paymentData]);

  const getProjectName = (projectId: number) => {
    const project = projectsData.find((p) => p.id === projectId);
    return project ? project.name : "Unknown Project";
  };

  // Prepare chart data for payment types
  const getPaymentTypeChartData = () => {
    if (!paymentData || paymentData.length === 0) return [];
    
    // Count occurrences of each payment type
    const typeCounts: Record<string, number> = {};
    paymentData.forEach(payment => {
      const type = payment.paymentType || "Unknown";
      typeCounts[type] = (typeCounts[type] || 0) + parseFloat(payment.amount);
    });
    
    return Object.entries(typeCounts).map(([name, value]) => ({
      name,
      value,
    }));
  };
  
  const chartData = getPaymentTypeChartData();
  const COLORS = ['#f59e0b', '#d97706', '#b45309', '#92400e', '#78350f', '#fcd34d'];

  if (!selectedSale) return null;

  // Check if agreement is done
  const agreementStatus = selectedSale.bookingDone === "Yes";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl text-amber-900">
              Sale Details
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="absolute right-4 top-4"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <Tabs
          defaultValue="details"
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="details" className="text-amber-900">
              <FileText className="h-4 w-4 mr-2" />
              Details
            </TabsTrigger>
            <TabsTrigger value="payments" className="text-amber-900">
              <CreditCard className="h-4 w-4 mr-2" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-amber-900">
              <PieChart className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Details Tab */}
          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-semibold text-amber-900 mb-2">Customer Information</h3>
                <Card>
                  <CardContent className="p-4 space-y-3">
                    <div>
                      <Label className="text-xs text-amber-700">Customer Name</Label>
                      <div className="font-medium text-amber-900">{selectedSale.customerName || 'N/A'}</div>
                    </div>
                    <div>
                      <Label className="text-xs text-amber-700">Contact Number</Label>
                      <div className="font-medium text-amber-900">{selectedSale.customerMobile || 'N/A'}</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <h3 className="text-sm font-semibold text-amber-900 mb-2">Sale Information</h3>
                <Card>
                  <CardContent className="p-4 space-y-3">
                    <div>
                      <Label className="text-xs text-amber-700">Booking Date</Label>
                      <div className="font-medium text-amber-900">
                        {selectedSale.bookingDate ? format(new Date(selectedSale.bookingDate), 'dd MMM yyyy') : 'N/A'}
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs text-amber-700">Project</Label>
                      <div className="font-medium text-amber-900">{getProjectName(selectedSale.projectId)}</div>
                    </div>
                    <div>
                      <Label className="text-xs text-amber-700">Agreement Status</Label>
                      <div className="font-medium">
                        {selectedSale.cancelledAt ? (
                          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300 font-medium">
                            Cancelled
                          </Badge>
                        ) : agreementStatus ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 font-medium">
                            Yes
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 font-medium">
                            No
                          </Badge>
                        )}
                        {selectedSale.agreementDate && !selectedSale.cancelledAt && (
                          <span className="ml-2 text-xs text-amber-700">
                            {format(new Date(selectedSale.agreementDate), 'dd MMM yyyy')}
                          </span>
                        )}
                        {selectedSale.cancelledAt && (
                          <span className="ml-2 text-xs text-red-600">
                            Cancelled on {format(new Date(selectedSale.cancelledAt), 'dd MMM yyyy')}
                          </span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            <h3 className="text-sm font-semibold text-amber-900 mb-2">Financial Details</h3>
            <Card>
              <CardContent className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-xs text-amber-700">Area Sold</Label>
                  <div className="font-medium text-amber-900">{parseFloat(selectedSale.areaSold).toLocaleString()} sq.ft.</div>
                </div>
                <div>
                  <Label className="text-xs text-amber-700">Base Sale Price</Label>
                  <div className="font-medium text-amber-900">₹{parseFloat(selectedSale.baseSalePrice || "0").toLocaleString()}/sq.ft.</div>
                </div>
                <div>
                  <Label className="text-xs text-amber-700">Final Amount</Label>
                  <div className="font-medium text-amber-900">₹{parseFloat(selectedSale.finalAmount || "0").toLocaleString()}</div>
                </div>
                <div>
                  <Label className="text-xs text-amber-700">Amount Paid</Label>
                  <div className="font-medium text-green-600">₹{parseFloat(selectedSale.amountPaid || "0").toLocaleString()}</div>
                </div>
                <div>
                  <Label className="text-xs text-amber-700">Total Paid</Label>
                  <div className="font-medium text-green-600">₹{totalPayments.toLocaleString()}</div>
                </div>
                <div>
                  <Label className="text-xs text-amber-700">Balance Due</Label>
                  <div className="font-medium text-red-600">₹{remainingBalance.toLocaleString()}</div>
                </div>
                <div>
                  <Label className="text-xs text-amber-700">Payment Status</Label>
                  <div className="font-medium">
                    {remainingBalance <= 0 ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Fully Paid
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                        Partial Payment
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Cancellation Information - Only show for cancelled sales */}
            {selectedSale.cancelledAt && (
              <>
                <h3 className="text-sm font-semibold text-red-800 mb-2 flex items-center">
                  <Ban className="h-4 w-4 mr-2" />
                  Cancellation Information
                </h3>
                <Card className="border-red-200 bg-red-50">
                  <CardContent className="p-4 space-y-3">
                    <div>
                      <Label className="text-xs text-red-700">Cancellation Date</Label>
                      <div className="font-medium text-red-800">
                        {format(new Date(selectedSale.cancelledAt), 'dd MMM yyyy')}
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs text-red-700">Cancellation Reason</Label>
                      <div className="font-medium text-red-800">
                        {selectedSale.cancellationReason || 'No reason provided'}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
            
            <h3 className="text-sm font-semibold text-amber-900 mb-2">Additional Information</h3>
            <Card>
              <CardContent className="p-4">
                <p className="text-amber-900">{selectedSale.bookingData || 'No additional information available'}</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments">
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-sm font-semibold text-amber-900">Payment History</h3>
                </div>
                
                <div className="rounded-md border overflow-hidden">
                  {paymentData && paymentData.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-amber-50">
                          <TableHead className="text-amber-900">Date</TableHead>
                          <TableHead className="text-amber-900">Amount</TableHead>
                          <TableHead className="text-amber-900">Type</TableHead>
                          <TableHead className="text-amber-900">Mode</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paymentData.map((payment) => (
                          <TableRow key={payment.id}>
                            <TableCell className="font-medium">
                              {format(new Date(payment.paymentDate), 'dd MMM yyyy')}
                            </TableCell>
                            <TableCell>₹{parseFloat(payment.amount).toLocaleString()}</TableCell>
                            <TableCell>{payment.paymentType}</TableCell>
                            <TableCell>{payment.paymentMode || 'N/A'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="py-8 text-center text-amber-700">
                      No payment records found
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                  <Card className="border-amber-100">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-amber-900">Payment Summary</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-amber-700">Total Amount:</span>
                          <span className="font-medium text-amber-900">₹{parseFloat(selectedSale.finalAmount || "0").toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-amber-700">Paid Amount:</span>
                          <span className="font-medium text-green-600">₹{totalPayments.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-amber-700">Balance:</span>
                          <span className="font-medium text-red-600">₹{remainingBalance.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-amber-700">Paid Percentage:</span>
                          <span className="font-medium text-amber-900">
                            {selectedSale.finalAmount && parseFloat(selectedSale.finalAmount) > 0
                              ? Math.round((totalPayments / parseFloat(selectedSale.finalAmount)) * 100)
                              : 0}%
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <Card>
              <CardContent className="p-4">
                <h3 className="text-sm font-semibold text-amber-900 mb-4">Payment Analytics</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Pie Chart */}
                  <div>
                    <h4 className="text-xs font-medium text-amber-700 mb-2">Payment Type Distribution</h4>
                    <div className="h-[250px] w-full">
                      {chartData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsChart>
                            <Pie
                              data={chartData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                            >
                              {chartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <RechartsTooltip
                              formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Amount']}
                            />
                          </RechartsChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <p className="text-muted-foreground">No payment data available</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Payment Progress */}
                  <div>
                    <h4 className="text-xs font-medium text-amber-700 mb-2">Payment Progress</h4>
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-amber-900">Payment Completion</span>
                          <span className="font-medium text-amber-900">
                            {selectedSale.finalAmount && parseFloat(selectedSale.finalAmount) > 0
                              ? Math.round((totalPayments / parseFloat(selectedSale.finalAmount)) * 100)
                              : 0}%
                          </span>
                        </div>
                        <div className="h-2 relative w-full bg-amber-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-amber-500 rounded-full"
                            style={{
                              width: `${selectedSale.finalAmount && parseFloat(selectedSale.finalAmount) > 0
                                ? Math.min(100, (totalPayments / parseFloat(selectedSale.finalAmount)) * 100)
                                : 0}%`,
                            }}
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 gap-4">
                        <div className="p-4 rounded-md bg-amber-50 border border-amber-100">
                          <div className="flex items-start">
                            <IndianRupee className="h-5 w-5 mr-2 text-amber-700" />
                            <div>
                              <h5 className="font-medium text-amber-900">Payment Rate</h5>
                              <p className="text-sm text-amber-700 mt-1">
                                {paymentData && paymentData.length > 0
                                  ? `Averaging ${Math.round(totalPayments / paymentData.length).toLocaleString()} per payment`
                                  : 'No payment data available'}
                              </p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="p-4 rounded-md bg-amber-50 border border-amber-100">
                          <div className="flex items-start">
                            <InfoIcon className="h-5 w-5 mr-2 text-amber-700" />
                            <div>
                              <h5 className="font-medium text-amber-900">Payment Status</h5>
                              <p className="text-sm text-amber-700 mt-1">
                                {remainingBalance <= 0
                                  ? 'Fully paid! No more payments required.'
                                  : `₹${remainingBalance.toLocaleString()} more to complete payment.`}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export default function MySalesPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [showDetails, setShowDetails] = useState(false);
  const [selectedSale, setSelectedSale] = useState<Sales | null>(null);
  const [showDashboard, setShowDashboard] = useState(true);
  const [filter, setFilter] = useState('all');
  const [sortField, setSortField] = useState('bookingDate');
  const [sortDirection, setSortDirection] = useState('desc');
  const [searchQuery, setSearchQuery] = useState('');
  
  const isMobile = useIsMobile();

  // Fetch sales data
  const { data: salesData, isLoading: isSalesLoading } = useQuery<Sales[]>({
    queryKey: ['/api/sales'],
    queryFn: async () => {
      const res = await fetch('/api/sales');
      if (!res.ok) {
        throw new Error('Failed to fetch sales data');
      }
      return res.json();
    },
  });

  // Fetch projects data
  const { data: projectsData, isLoading: isProjectsLoading } = useQuery({
    queryKey: ['/api/projects'],
    queryFn: async () => {
      const res = await fetch('/api/projects');
      if (!res.ok) {
        throw new Error('Failed to fetch projects data');
      }
      return res.json();
    },
  });

  // Fetch users data
  const { data: usersData, isLoading: isUsersLoading } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const res = await fetch('/api/users');
      if (!res.ok) {
        throw new Error('Failed to fetch users data');
      }
      return res.json();
    },
  });

  // Get sales based on user role (manager or individual)
  const isManager = user?.designation === "Manager" || user?.designation === "Team Leader" || user?.role === "Manager";
  
  // Get all team members under this manager (if user is a manager)
  const teamMembers = usersData ? usersData
    .filter(u => u.reportingManagerId === user?.id && u.status)
    .map(u => u.id) : [];
  
  // Filter sales by the current user or their team
  const userSales = salesData
    ? salesData.filter((sale) => {
        // Direct sales by the user
        const isUserSale = sale.salesExecutiveId === user?.id;
        
        // For managers, include team members' sales
        const isTeamMemberSale = isManager && teamMembers.includes(sale.salesExecutiveId);
        
        // Include if it's either the user's sale or a team member's sale (for managers)
        const includeBasedOnUser = isUserSale || (isManager && isTeamMemberSale);
        
        if (!includeBasedOnUser) return false;
        
        // Filter by date if needed
        switch(filter) {
          case 'today':
            const today = new Date();
            const isToday = new Date(sale.bookingDate).setHours(0,0,0,0) === today.setHours(0,0,0,0);
            if (!isToday) return false;
            break;
          case 'thisMonth':
            const now = new Date();
            const thisMonth = now.getMonth();
            const thisYear = now.getFullYear();
            const saleDate = new Date(sale.bookingDate);
            const isThisMonth = saleDate.getMonth() === thisMonth && saleDate.getFullYear() === thisYear;
            if (!isThisMonth) return false;
            break;
          case 'lastMonth':
            const nowDate = new Date();
            const lastMonth = nowDate.getMonth() === 0 ? 11 : nowDate.getMonth() - 1;
            const lastMonthYear = nowDate.getMonth() === 0 ? nowDate.getFullYear() - 1 : nowDate.getFullYear();
            const lastSaleDate = new Date(sale.bookingDate);
            const isLastMonth = lastSaleDate.getMonth() === lastMonth && lastSaleDate.getFullYear() === lastMonthYear;
            if (!isLastMonth) return false;
            break;
          case 'thisYear':
            const currentYear = new Date().getFullYear();
            const isThisYear = new Date(sale.bookingDate).getFullYear() === currentYear;
            if (!isThisYear) return false;
            break;
        }
        
        // Apply search filter
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          return (
            (sale.customerName && sale.customerName.toLowerCase().includes(query)) ||
            (sale.customerMobile && sale.customerMobile.includes(query))
          );
        }
        
        return true;
      })
    : [];

  // Function to calculate summary data
  function calculateSummaryData() {
    if (!salesData) return { totalSales: 0, totalArea: 0, totalBookings: 0, totalRevenue: 0 };
    
    // Get this month's sales - exclude cancelled sales
    const now = new Date();
    const thisMonth = now.getMonth();
    const thisYear = now.getFullYear();
    
    const thisMonthSales = userSales.filter(sale => {
      const saleDate = new Date(sale.bookingDate);
      return saleDate.getMonth() === thisMonth && 
             saleDate.getFullYear() === thisYear &&
             !sale.cancelledAt;
    });
    
    const totalSales = thisMonthSales.reduce((sum, sale) => sum + parseFloat(sale.finalAmount || "0"), 0);
    const totalArea = thisMonthSales.reduce((sum, sale) => sum + parseFloat(sale.areaSold || "0"), 0);
    const totalRevenue = thisMonthSales.reduce((sum, sale) => sum + (parseFloat(sale.areaSold || "0") * parseFloat(sale.rate || "0")), 0);
    const thisMonthBookings = thisMonthSales.length;
    
    return { totalSales, totalArea, totalBookings: thisMonthBookings, totalRevenue };
  }

  // Calculate trend percentage for the current month vs last month
  function calculateTrend() {
    if (!salesData) return 0;
    
    const now = new Date();
    const thisMonth = now.getMonth();
    const thisYear = now.getFullYear();
    const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
    const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;
    
    const thisMonthArea = userSales.filter(sale => {
      const saleDate = new Date(sale.bookingDate);
      return saleDate.getMonth() === thisMonth && 
             saleDate.getFullYear() === thisYear &&
             !sale.cancelledAt;
    }).reduce((sum, sale) => sum + parseFloat(sale.areaSold || "0"), 0);
    
    const lastMonthArea = userSales.filter(sale => {
      const saleDate = new Date(sale.bookingDate);
      return saleDate.getMonth() === lastMonth && 
             saleDate.getFullYear() === lastMonthYear &&
             !sale.cancelledAt;
    }).reduce((sum, sale) => sum + parseFloat(sale.areaSold || "0"), 0);
    
    if (lastMonthArea === 0) return 100; // If no sales last month, show 100% increase
    
    const trend = ((thisMonthArea - lastMonthArea) / lastMonthArea) * 100;
    return Math.round(trend);
  }
  
  const { totalSales, totalArea, totalBookings, totalRevenue } = calculateSummaryData();
  const performanceTrend = calculateTrend();

  // Show loading state
  if (isSalesLoading || isProjectsLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-amber-600 mb-2" />
          <p className="text-amber-900">Loading sales data...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-amber-900">My Sales</h1>
              <p className="text-amber-800 mt-1">
                {user?.designation === "Sales Executive" || user?.designation === "Executive"
                  ? "Track your sales performance and records" 
                  : "View your team's sales performance and records"}
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <Button
                variant="outline"
                className="h-10 text-amber-700 border-amber-300 hover:bg-amber-50 hover:text-amber-900"
                onClick={() => setShowDashboard(!showDashboard)}
              >
                {showDashboard ? (
                  <>
                    <Eye className="mr-2 h-4 w-4" />
                    View All Sales
                  </>
                ) : (
                  <>
                    <BarChartIcon className="mr-2 h-4 w-4" />
                    Show Dashboard
                  </>
                )}
              </Button>
            </div>
          </div>

          {showDashboard ? (
            <>
              {/* Dashboard */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-6">
                <SalesSummaryCard
                  title="Monthly Bookings"
                  value={totalBookings}
                  description="Total bookings this month"
                  icon={<Calendar className="h-4 w-4 text-amber-600" />}
                />
                <SalesSummaryCard
                  title="Area Sold"
                  value={`${Math.round(totalArea).toLocaleString()} sq.ft.`}
                  description="Total area sold this month"
                  icon={<Map className="h-4 w-4 text-amber-600" />}
                  trend={performanceTrend}
                />
                <SalesSummaryCard
                  title="Monthly Sales Value"
                  value={`₹${Math.round(totalSales).toLocaleString()}`}
                  description="Total sales this month"
                  icon={<IndianRupee className="h-4 w-4 text-amber-600" />}
                />
                <SalesSummaryCard
                  title="Base Revenue"
                  value={`₹${Math.round(totalRevenue).toLocaleString()}`}
                  description="Base revenue this month"
                  icon={<TrendingUp className="h-4 w-4 text-amber-600" />}
                />
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                <SalesPerformanceChart
                  salesData={salesData || []}
                  userSalesData={userSales}
                />
                <TeamLeaderboard
                  usersData={usersData || []}
                  salesData={salesData || []}
                />
              </div>
            </>
          ) : (
            <>
              {/* Sales List */}
              <div className="mb-6 flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-amber-500" />
                    <Input
                      type="search"
                      placeholder="Search by customer name, unit number or phone..."
                      className="w-full pl-8 border-amber-200 focus:border-amber-300 focus:ring focus:ring-amber-200 focus:ring-opacity-50"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  {/* Filter Buttons Group */}
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={filter === "all" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilter("all")}
                      className={`${filter === "all" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      All Time
                    </Button>
                    <Button
                      variant={filter === "today" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilter("today")}
                      className={`${filter === "today" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      Today
                    </Button>
                    <Button
                      variant={filter === "thisMonth" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilter("thisMonth")}
                      className={`${filter === "thisMonth" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      This Month
                    </Button>
                    <Button
                      variant={filter === "lastMonth" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilter("lastMonth")}
                      className={`${filter === "lastMonth" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      Last Month
                    </Button>
                    <Button
                      variant={filter === "thisYear" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilter("thisYear")}
                      className={`${filter === "thisYear" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      This Year
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2 mt-2 sm:mt-0">
                    {/* Sort Field Button Group */}
                    <Button
                      variant={sortField === "bookingDate" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSortField("bookingDate")}
                      className={`${sortField === "bookingDate" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      By Date
                    </Button>
                    <Button
                      variant={sortField === "areaSold" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSortField("areaSold")}
                      className={`${sortField === "areaSold" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      By Area
                    </Button>
                    <Button
                      variant={sortField === "finalAmount" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSortField("finalAmount")}
                      className={`${sortField === "finalAmount" ? "bg-amber-600 hover:bg-amber-700" : "border-amber-200 text-amber-700 hover:bg-amber-50"}`}
                    >
                      By Amount
                    </Button>
                    
                    {/* Sort Direction Button */}
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setSortDirection(sortDirection === "asc" ? "desc" : "asc")}
                      className="border border-amber-200 h-8 w-8"
                    >
                      {sortDirection === "asc" ? (
                        <ChevronUp className="h-4 w-4 text-amber-500" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-amber-500" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>

              {userSales.length === 0 ? (
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-amber-100">
                      <FileText className="h-10 w-10 text-amber-600" />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold text-amber-900">No sales found</h3>
                    <p className="mt-2 text-sm text-amber-700">
                      {searchQuery 
                        ? "No sales match your search criteria." 
                        : "You haven't recorded any sales yet."}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="rounded-md border border-amber-100 overflow-hidden">
                  <Table>
                    <TableHeader className="bg-amber-50">
                      <TableRow>
                        <TableHead className="text-amber-900">Customer</TableHead>
                        <TableHead className="text-amber-900">Project & Unit</TableHead>
                        <TableHead className="text-amber-900">Area</TableHead>
                        <TableHead className="text-amber-900">Amount</TableHead>
                        <TableHead className="text-amber-900">Date</TableHead>
                        <TableHead className="text-amber-900">Agreement</TableHead>
                        <TableHead className="text-amber-900 text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {userSales
                        .sort((a, b) => {
                          if (sortField === "bookingDate") {
                            const dateA = new Date(a.bookingDate).getTime();
                            const dateB = new Date(b.bookingDate).getTime();
                            return sortDirection === "asc" ? dateA - dateB : dateB - dateA;
                          } else if (
                            sortField === "finalAmount" ||
                            sortField === "areaSold"
                          ) {
                            const numA = parseFloat(a[sortField]);
                            const numB = parseFloat(b[sortField]);
                            return sortDirection === "asc" ? numA - numB : numB - numA;
                          } else {
                            const textA = a[sortField].toLowerCase();
                            const textB = b[sortField].toLowerCase();
                            return sortDirection === "asc"
                              ? textA.localeCompare(textB)
                              : textB.localeCompare(textA);
                          }
                        })
                        .map((sale) => {
                          const project = projectsData?.find(
                            (p) => p.id === sale.projectId
                          );
                          
                          return (
                            <TableRow 
                              key={sale.id}
                              className={`relative ${
                                sale.cancelledAt 
                                  ? "bg-red-50 border-red-200 hover:bg-red-100" 
                                  : "hover:bg-amber-50"
                              }`}
                            >
                              <TableCell className="font-medium">
                                {sale.customerName || "No Name"}
                                {sale.customerMobile && (
                                  <div className="text-xs text-amber-600">
                                    {sale.customerMobile}
                                  </div>
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="font-medium">{project?.name || "Unknown Project"}</div>
                                <div className="text-xs text-amber-600">Area: {parseFloat(sale.areaSold).toLocaleString()} sq.ft.</div>
                              </TableCell>
                              <TableCell>{parseFloat(sale.areaSold).toLocaleString()} sq.ft.</TableCell>
                              <TableCell>₹{parseFloat(sale.finalAmount || "0").toLocaleString()}</TableCell>
                              <TableCell>
                                {format(new Date(sale.bookingDate), "dd MMM yyyy")}
                              </TableCell>
                              <TableCell>
                                {sale.cancelledAt ? (
                                  <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300 font-medium">
                                    Cancelled
                                  </Badge>
                                ) : sale.bookingDone === "Yes" ? (
                                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 font-medium">
                                    Yes
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 font-medium">
                                    No
                                  </Badge>
                                )}
                                {sale.agreementDate && !sale.cancelledAt && (
                                  <div className="text-xs text-amber-600 mt-1">
                                    {format(new Date(sale.agreementDate), 'dd MMM yyyy')}
                                  </div>
                                )}
                                {sale.cancelledAt && (
                                  <div className="absolute top-1 right-1 z-10">
                                    <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-semibold bg-red-600 text-white shadow-lg">
                                      <Ban className="h-3 w-3 mr-1" />
                                      CANCELLED
                                    </span>
                                  </div>
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 px-2 text-amber-700"
                                  onClick={() => {
                                    setSelectedSale(sale);
                                    setShowDetails(true);
                                  }}
                                >
                                  <Eye className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </>
          )}

          {/* Sales Details Dialog */}
          <SalesDetailsDialog 
            open={showDetails} 
            onOpenChange={setShowDetails}
            selectedSale={selectedSale}
            projectsData={projectsData}
          />
    </div>
  );
}