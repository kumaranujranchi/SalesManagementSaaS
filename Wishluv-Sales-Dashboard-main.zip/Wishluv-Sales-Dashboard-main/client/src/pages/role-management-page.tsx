import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Edit, Eye, Loader2, Plus, Search, Shield, Trash2, UserSquare2 } from "lucide-react";
import { Role, InsertRole } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertRoleSchema } from "@shared/schema";

type RoleFormValues = z.infer<typeof insertRoleSchema>;

interface Permission {
  id: string;
  name: string;
  category: string;
  description: string;
}

const permissions: Permission[] = [
  { id: "user.view", name: "View users", category: "User Management", description: "Access to view user list" },
  { id: "user.create", name: "Create users", category: "User Management", description: "Access to create new users" },
  { id: "user.edit", name: "Edit users", category: "User Management", description: "Access to edit existing users" },
  { id: "user.delete", name: "Delete users", category: "User Management", description: "Access to delete users" },
  { id: "project.view", name: "View projects", category: "Project Management", description: "Access to view projects" },
  { id: "project.create", name: "Create projects", category: "Project Management", description: "Access to create new projects" },
  { id: "project.edit", name: "Edit projects", category: "Project Management", description: "Access to edit projects" },
  { id: "project.delete", name: "Delete projects", category: "Project Management", description: "Access to delete projects" },
  { id: "department.view", name: "View departments", category: "Department Management", description: "Access to view departments" },
  { id: "department.create", name: "Create departments", category: "Department Management", description: "Access to create new departments" },
  { id: "department.edit", name: "Edit departments", category: "Department Management", description: "Access to edit departments" },
  { id: "department.delete", name: "Delete departments", category: "Department Management", description: "Access to delete departments" },
  { id: "role.view", name: "View roles", category: "Role Management", description: "Access to view roles" },
  { id: "role.create", name: "Create roles", category: "Role Management", description: "Access to create new roles" },
  { id: "role.edit", name: "Edit roles", category: "Role Management", description: "Access to edit roles" },
  { id: "role.delete", name: "Delete roles", category: "Role Management", description: "Access to delete roles" },
  { id: "sales.view", name: "View sales", category: "Sales Management", description: "Access to view sales data" },
  { id: "sales.create", name: "Create sales", category: "Sales Management", description: "Access to create sales entries" },
  { id: "sales.edit", name: "Edit sales", category: "Sales Management", description: "Access to edit sales data" },
  { id: "sales.delete", name: "Delete sales", category: "Sales Management", description: "Access to delete sales entries" },
  { id: "announcement.view", name: "View announcements", category: "Announcements", description: "Access to view announcements" },
  { id: "announcement.create", name: "Create announcements", category: "Announcements", description: "Access to create announcements" },
  { id: "announcement.edit", name: "Edit announcements", category: "Announcements", description: "Access to edit announcements" },
  { id: "announcement.delete", name: "Delete announcements", category: "Announcements", description: "Access to delete announcements" },
  { id: "target.view", name: "View targets", category: "Target Management", description: "Access to view sales targets" },
  { id: "target.create", name: "Create targets", category: "Target Management", description: "Access to create new targets" },
  { id: "target.edit", name: "Edit targets", category: "Target Management", description: "Access to edit existing targets" },
  { id: "target.delete", name: "Delete targets", category: "Target Management", description: "Access to delete targets" },
  { id: "billing.view", name: "View billing", category: "Billing", description: "Access to view billing information" },
  { id: "billing.manage", name: "Manage billing", category: "Billing", description: "Access to manage billing settings" }
];

export default function RoleManagementPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [deletingRole, setDeletingRole] = useState<Role | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);

  const { data: roles, isLoading } = useQuery<Role[]>({
    queryKey: ["/api/roles"],
    onError: () => {
      toast({
        title: "Failed to load roles",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  });

  const form = useForm<RoleFormValues>({
    resolver: zodResolver(insertRoleSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const createRole = useMutation({
    mutationFn: async (data: InsertRole) => {
      const res = await apiRequest("POST", "/api/roles", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Role created",
        description: "The role has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      setShowAddDialog(false);
      form.reset({
        name: "",
        description: "",
      });
      setSelectedPermissions([]);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create role.",
        variant: "destructive",
      });
    },
  });

  const updateRole = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertRole }) => {
      const res = await apiRequest("PUT", `/api/roles/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Role updated",
        description: "The role has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      setShowAddDialog(false);
      setEditingRole(null);
      form.reset({
        name: "",
        description: "",
      });
      setSelectedPermissions([]);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update role.",
        variant: "destructive",
      });
    },
  });

  const deleteRole = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/roles/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Role deleted",
        description: "The role has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      setShowDeleteDialog(false);
      setDeletingRole(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete role.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: RoleFormValues) => {
    // Convert selected permissions array to a JSON string to store in the permissions field
    const permissionsObj = selectedPermissions.reduce((acc, permId) => {
      acc[permId] = true;
      return acc;
    }, {} as Record<string, boolean>);
    
    const roleData = {
      ...data,
      permissions: JSON.stringify(permissionsObj)
    };

    if (editingRole) {
      updateRole.mutate({ id: editingRole.id, data: roleData });
    } else {
      createRole.mutate(roleData);
    }
  };

  const handleEdit = (role: Role) => {
    setEditingRole(role);
    form.reset({
      name: role.name,
      description: role.description || "",
    });
    
    // Parse permissions from JSON string
    try {
      const permissionsObj = role.permissions ? JSON.parse(role.permissions) : {};
      setSelectedPermissions(Object.keys(permissionsObj).filter(key => permissionsObj[key]));
    } catch (error) {
      console.error("Error parsing permissions:", error);
      setSelectedPermissions([]);
    }
    
    setShowAddDialog(true);
  };

  const handleDelete = (role: Role) => {
    setDeletingRole(role);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (deletingRole) {
      deleteRole.mutate(deletingRole.id);
    }
  };

  const closeDialog = () => {
    setShowAddDialog(false);
    setEditingRole(null);
    form.reset({
      name: "",
      description: "",
    });
    setSelectedPermissions([]);
  };

  const togglePermission = (permissionId: string) => {
    setSelectedPermissions(prev => 
      prev.includes(permissionId)
        ? prev.filter(id => id !== permissionId)
        : [...prev, permissionId]
    );
  };

  // Group permissions by category
  const permissionsByCategory = permissions.reduce((acc, permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {} as Record<string, Permission[]>);

  // Filter roles by search term
  const filteredRoles = roles
    ? roles.filter(role =>
        role.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        role.description?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const isPending = createRole.isPending || updateRole.isPending || deleteRole.isPending;

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <div className="mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <h1 className="text-2xl font-bold">Role Management</h1>
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button variant="default" className="mt-4 md:mt-0 px-4 py-2 rounded-md flex items-center bg-primary text-primary-foreground hover:bg-primary/90">
                    <Plus className="mr-2 h-4 w-4" />
                    Add New Role
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>
                      {editingRole ? "Edit Role" : "Add New Role"}
                    </DialogTitle>
                    <DialogDescription>
                      {editingRole 
                        ? "Update role details and permissions." 
                        : "Create a new role with specific permissions."}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={form.handleSubmit(onSubmit)}>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="name" className="text-right text-sm font-medium">
                          Role Name
                        </label>
                        <Input
                          id="name"
                          className="col-span-3"
                          placeholder="Enter role name"
                          {...form.register("name")}
                        />
                        {form.formState.errors.name && (
                          <p className="col-span-3 col-start-2 text-sm text-red-500">
                            {form.formState.errors.name.message}
                          </p>
                        )}
                      </div>
                      <div className="grid grid-cols-4 items-start gap-4">
                        <label htmlFor="description" className="text-right text-sm font-medium mt-2">
                          Description
                        </label>
                        <Textarea
                          id="description"
                          className="col-span-3"
                          placeholder="Enter role description"
                          {...form.register("description")}
                        />
                        {form.formState.errors.description && (
                          <p className="col-span-3 col-start-2 text-sm text-red-500">
                            {form.formState.errors.description.message}
                          </p>
                        )}
                      </div>
                      <div className="grid grid-cols-4 items-start gap-4">
                        <label className="text-right text-sm font-medium mt-2">
                          Permissions
                        </label>
                        <div className="col-span-3 space-y-4">
                          {Object.entries(permissionsByCategory).map(([category, perms]) => (
                            <div key={category} className="space-y-2">
                              <h4 className="font-medium text-sm">{category}</h4>
                              <div className="grid grid-cols-2 gap-2">
                                {perms.map(permission => (
                                  <div key={permission.id} className="flex items-center space-x-2">
                                    <Checkbox 
                                      id={permission.id} 
                                      checked={selectedPermissions.includes(permission.id)}
                                      onCheckedChange={() => togglePermission(permission.id)}
                                    />
                                    <label 
                                      htmlFor={permission.id}
                                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                    >
                                      {permission.name}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={closeDialog}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={isPending}>
                        {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {editingRole ? "Update Role" : "Create Role"}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">TOTAL ROLES</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{roles?.length || 0}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">ADMIN ROLES</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {roles?.filter(r => r.name.toLowerCase().includes('admin')).length || 0}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">CUSTOM ROLES</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {roles?.filter(r => !r.name.toLowerCase().includes('admin')).length || 0}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <CardTitle>Roles</CardTitle>
                    <CardDescription>Manage user roles and permissions</CardDescription>
                  </div>
                  <div className="relative mt-4 md:mt-0">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral-500" />
                    <Input
                      type="search"
                      placeholder="Search roles..."
                      className="pl-9 w-full md:w-[260px]"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Users</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4">
                          <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                          <span className="mt-2 inline-block">Loading roles...</span>
                        </TableCell>
                      </TableRow>
                    ) : filteredRoles.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4">
                          No roles found. {searchTerm ? "Try adjusting your search." : "Create a new role to get started."}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredRoles.map((role) => (
                        <TableRow key={role.id}>
                          <TableCell className="font-medium flex items-center">
                            <Shield className="h-4 w-4 mr-2 text-secondary" />
                            {role.name}
                          </TableCell>
                          <TableCell>{role.description?.split('\n')[0] || "No description"}</TableCell>
                          <TableCell className="flex items-center">
                            <UserSquare2 className="h-4 w-4 mr-2 text-neutral-500" />
                            <span>8</span> {/* This would be dynamic in a real app */}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                              onClick={() => handleEdit(role)}
                            >
                              <span className="sr-only">Edit</span>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                            >
                              <span className="sr-only">View</span>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                              onClick={() => handleDelete(role)}
                              disabled={role.name === "Super Admin"} // Prevent deleting the Super Admin role
                            >
                              <span className="sr-only">Delete</span>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="flex items-center justify-between">
                <div className="text-sm text-neutral-600">
                  Showing {filteredRoles.length} of {roles?.length || 0} roles
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    Previous
                  </Button>
                  <Button variant="outline" size="sm">
                    Next
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
        </main>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the role
              "{deletingRole?.name}" and remove it from all associated users.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 text-white hover:bg-red-700"
              disabled={deleteRole.isPending}
            >
              {deleteRole.isPending ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Deleting...</>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
