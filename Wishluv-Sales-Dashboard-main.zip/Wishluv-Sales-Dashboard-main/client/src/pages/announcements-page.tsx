import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Search, 
  Calendar, 
  UserCircle, 
  Megaphone, 
  Plus, 
  Eye, 
  Edit, 
  Trash2, 
  ThumbsUp, 
  Loader2, 
  BellRing
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

// These would typically come from your schema.ts file
interface Announcement {
  id: number;
  title: string;
  content: string;
  createdBy: number;
  createdAt: string;
  authorName?: string;
  isImportant?: boolean;
}

interface AnnouncementsPageProps {
  viewOnly?: boolean;
}

export default function AnnouncementsPage({ viewOnly = false }: AnnouncementsPageProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [isImportant, setIsImportant] = useState(false);

  // Fetch announcements from the API
  const { data: announcements = [], isLoading } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
    // Get users to get full names for display
    select: (data) => {
      return data.map(announcement => {
        // Find the user who created this announcement
        const creator = announcement.createdBy === user?.id ? user : undefined;
        return {
          ...announcement,
          authorName: creator ? creator.fullName : `User ${announcement.createdBy}`
        };
      });
    }
  });

  // Filter announcements by search term
  const filteredAnnouncements = announcements
    ? announcements.filter(announcement =>
        announcement.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        announcement.content.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const createAnnouncement = useMutation({
    mutationFn: async (data: { title: string; content: string; isImportant: boolean }) => {
      const response = await apiRequest("POST", "/api/announcements", {
        title: data.title,
        content: data.content,
        isImportant: data.isImportant
      });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Announcement created",
        description: "Your announcement has been published successfully.",
      });
      
      // Invalidate the announcements cache
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      
      setShowAddDialog(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create announcement.",
        variant: "destructive",
      });
    },
  });

  const deleteAnnouncement = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/announcements/${id}`);
      return id;
    },
    onSuccess: () => {
      toast({
        title: "Announcement deleted",
        description: "The announcement has been deleted successfully.",
      });
      
      // Invalidate the announcements cache
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      
      setShowDeleteDialog(false);
      setSelectedAnnouncement(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete announcement.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setTitle("");
    setContent("");
    setIsImportant(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createAnnouncement.mutate({
      title,
      content,
      isImportant
    });
  };

  const handleViewAnnouncement = (announcement: Announcement) => {
    setSelectedAnnouncement(announcement);
    setShowViewDialog(true);
  };

  const handleDeleteAnnouncement = (announcement: Announcement) => {
    setSelectedAnnouncement(announcement);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (selectedAnnouncement) {
      deleteAnnouncement.mutate(selectedAnnouncement.id);
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-neutral-100">
      <div className="flex-1 flex flex-col">
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <div className="mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <h1 className="text-2xl font-bold">Announcements</h1>
              
              {!viewOnly && (
                <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                  <DialogTrigger asChild>
                    <Button variant="default" className="mt-4 md:mt-0 px-4 py-2 rounded-md flex items-center bg-primary text-primary-foreground hover:bg-primary/90">
                      <Plus className="mr-2 h-4 w-4" />
                      Create Announcement
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[550px]">
                    <DialogHeader>
                      <DialogTitle>Create Announcement</DialogTitle>
                      <DialogDescription>
                        Create a new announcement for your team.
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit}>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <label htmlFor="title" className="text-right text-sm font-medium">
                            Title
                          </label>
                          <Input
                            id="title"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            className="col-span-3"
                            placeholder="Enter announcement title"
                            required
                          />
                        </div>
                        <div className="grid grid-cols-4 items-start gap-4">
                          <label htmlFor="content" className="text-right text-sm font-medium mt-2">
                            Content
                          </label>
                          <Textarea
                            id="content"
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                            className="col-span-3"
                            placeholder="Enter announcement content"
                            rows={5}
                            required
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <label className="text-right text-sm font-medium">
                            Important
                          </label>
                          <div className="col-span-3 flex items-center">
                            <input
                              type="checkbox"
                              id="important"
                              checked={isImportant}
                              onChange={(e) => setIsImportant(e.target.checked)}
                              className="h-4 w-4 text-secondary focus:ring-secondary rounded"
                            />
                            <label htmlFor="important" className="ml-2 text-sm">
                              Mark as important announcement
                            </label>
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                          Cancel
                        </Button>
                        <Button 
                          type="submit" 
                          disabled={createAnnouncement.isPending || !title || !content}
                        >
                          {createAnnouncement.isPending ? (
                            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Publishing...</>
                          ) : (
                            "Publish Announcement"
                          )}
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              )}
            </div>
            
            <div className="mb-6 relative">
              <Search className="absolute left-2.5 top-2.5 h-5 w-5 text-neutral-500" />
              <Input
                type="search"
                placeholder="Search announcements..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            {isLoading ? (
              <div className="flex justify-center items-center p-12">
                <Loader2 className="h-8 w-8 animate-spin text-secondary" />
              </div>
            ) : filteredAnnouncements.length === 0 ? (
              <div className="text-center p-12 bg-white rounded-lg shadow">
                <Megaphone className="h-12 w-12 mx-auto text-neutral-300 mb-4" />
                <h3 className="text-xl font-medium mb-2">No announcements found</h3>
                <p className="text-neutral-500 mb-6">
                  {searchTerm 
                    ? "No announcements match your search criteria." 
                    : "There are no announcements yet."}
                </p>
                {!viewOnly && !searchTerm && (
                  <Button 
                    onClick={() => setShowAddDialog(true)}
                    variant="default"
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Create First Announcement
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredAnnouncements.map((announcement) => (
                  <Card key={announcement.id} className={announcement.isImportant ? "border-yellow-400 border-2" : ""}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center mb-1">
                            {announcement.isImportant && (
                              <div className="mr-2 bg-yellow-100 text-yellow-800 text-xs px-2 py-0.5 rounded-full">
                                Important
                              </div>
                            )}
                            <div className="text-sm text-neutral-500 flex items-center">
                              <Calendar className="h-3 w-3 mr-1" />
                              {new Date(announcement.createdAt).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </div>
                          </div>
                          <CardTitle className="text-xl">{announcement.title}</CardTitle>
                          <CardDescription className="flex items-center mt-1">
                            <UserCircle className="h-4 w-4 mr-1" />
                            Posted by {announcement.authorName}
                          </CardDescription>
                        </div>
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleViewAnnouncement(announcement)}
                          >
                            <span className="sr-only">View</span>
                            <Eye className="h-4 w-4" />
                          </Button>
                          
                          {!viewOnly && (
                            <>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <span className="sr-only">Edit</span>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0"
                                onClick={() => handleDeleteAnnouncement(announcement)}
                              >
                                <span className="sr-only">Delete</span>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-neutral-700 line-clamp-2">{announcement.content}</p>
                    </CardContent>
                    <CardFooter className="pt-0 flex justify-between items-center">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleViewAnnouncement(announcement)}
                      >
                        Read More
                      </Button>
                      <div className="flex items-center text-neutral-500 text-sm">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <ThumbsUp className="h-4 w-4" />
                        </Button>
                        <span className="ml-1">12</span>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
      
      {/* View Announcement Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="sm:max-w-[650px]">
          {selectedAnnouncement && (
            <>
              <DialogHeader>
                <div className="flex items-center space-x-2">
                  <BellRing className="h-5 w-5 text-secondary" />
                  <DialogTitle className="text-xl">{selectedAnnouncement.title}</DialogTitle>
                </div>
                <DialogDescription className="flex items-center mt-2">
                  <UserCircle className="h-4 w-4 mr-1" />
                  Posted by {selectedAnnouncement.authorName} on {new Date(selectedAnnouncement.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </DialogDescription>
                {selectedAnnouncement.isImportant && (
                  <div className="mt-2 inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-0.5 rounded-full">
                    Important
                  </div>
                )}
              </DialogHeader>
              <div className="py-4">
                <p className="whitespace-pre-line text-neutral-700">{selectedAnnouncement.content}</p>
              </div>
              <DialogFooter>
                <div className="flex items-center mr-auto text-neutral-500">
                  <Button variant="ghost" size="sm" className="h-8 p-2">
                    <ThumbsUp className="h-4 w-4 mr-1" />
                    <span>Like</span>
                  </Button>
                  <span className="ml-1 text-sm">12 likes</span>
                </div>
                <Button variant="outline" onClick={() => setShowViewDialog(false)}>
                  Close
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      {!viewOnly && (
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the announcement
                "{selectedAnnouncement?.title}".
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={confirmDelete}
                className="bg-red-600 text-white hover:bg-red-700"
                disabled={deleteAnnouncement.isPending}
              >
                {deleteAnnouncement.isPending ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Deleting...</>
                ) : (
                  "Delete"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}