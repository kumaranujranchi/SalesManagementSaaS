import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ModalSelect } from "@/components/ui/modal-select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar, Clock, MapPin, Building2, User, CheckCircle, XCircle, Filter, Car, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const approvalSchema = z.object({
  status: z.enum(['approved', 'declined']),
  assignedDriverId: z.number().optional(),
});

type ApprovalFormData = z.infer<typeof approvalSchema>;

export default function AdminSiteVisitManagementPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedVisit, setSelectedVisit] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [expandedVisitId, setExpandedVisitId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [projectFilter, setProjectFilter] = useState<string>('all');

  const form = useForm<ApprovalFormData>({
    resolver: zodResolver(approvalSchema),
    defaultValues: {
      status: 'approved',
      assignedDriverId: undefined,
    },
  });

  // Fetch all site visits
  const { data: siteVisits = [], isLoading } = useQuery({
    queryKey: ['/api/site-visits'],
  });

  // Fetch users for driver assignment
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
  });

  // Fetch projects for filtering
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
  });

  const approveMutation = useMutation({
    mutationFn: async ({ visitId, data }: { visitId: number; data: ApprovalFormData }) => {
      const res = await apiRequest("PUT", `/api/site-visits/${visitId}/approve`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Site visit updated",
        description: "The site visit request has been updated successfully.",
      });
      setIsDialogOpen(false);
      setSelectedVisit(null);
      form.reset();
      // Invalidate all site visit related queries to ensure data consistency
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits'] });
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/sales'] });
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/driver'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update site visit request",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (visitId: number) => {
      const res = await apiRequest("DELETE", `/api/site-visits/${visitId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Site visit deleted",
        description: "The site visit request has been deleted successfully.",
      });
      // Invalidate all site visit related queries to ensure data consistency across all views
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits'] });
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/sales'] });
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/driver'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete site visit request",
        variant: "destructive",
      });
    },
  });

  const handleApproval = (visit: any) => {
    setSelectedVisit(visit);
    setIsDialogOpen(true);
    form.reset({
      status: 'approved',
      assignedDriverId: undefined,
    });
  };

  const toggleVisitExpansion = (visitId: number) => {
    setExpandedVisitId(expandedVisitId === visitId ? null : visitId);
  };

  const handleDelete = (visitId: number) => {
    if (window.confirm("Are you sure you want to delete this site visit request? This action cannot be undone.")) {
      deleteMutation.mutate(visitId);
    }
  };

  const onSubmit = (data: ApprovalFormData) => {
    if (selectedVisit) {
      approveMutation.mutate({
        visitId: selectedVisit.id,
        data,
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary">Pending</Badge>;
      case 'approved':
        return <Badge variant="default" className="bg-green-500">Approved</Badge>;
      case 'declined':
        return <Badge variant="destructive">Declined</Badge>;
      case 'completed':
        return <Badge variant="outline" className="border-blue-500 text-blue-600">Completed</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="border-orange-500 text-orange-600">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getProjectNames = (projectIds: string) => {
    try {
      const ids = JSON.parse(projectIds);
      return ids
        .map((id: number) => projects.find((p: any) => p.id === id)?.name)
        .filter(Boolean)
        .join(', ');
    } catch {
      return 'Unknown Projects';
    }
  };

  const getUserName = (userId: number) => {
    const user = users.find((u: any) => u.id === userId);
    return user ? user.fullName : 'Unknown User';
  };

  const drivers = users.filter((user: any) => user.role === 'Driver' || user.designation === 'Driver');

  // Filter site visits
  const filteredSiteVisits = siteVisits.filter((visit: any) => {
    if (statusFilter !== 'all' && visit.status !== statusFilter) return false;
    if (dateFilter && visit.visitDate !== dateFilter) return false;
    if (projectFilter !== 'all') {
      try {
        const projectIds = JSON.parse(visit.projectIds);
        if (!projectIds.includes(parseInt(projectFilter))) return false;
      } catch {
        return false;
      }
    }
    return true;
  });

  const pendingCount = siteVisits.filter((visit: any) => visit.status === 'pending').length;
  const approvedCount = siteVisits.filter((visit: any) => visit.status === 'approved').length;
  const completedCount = siteVisits.filter((visit: any) => visit.status === 'completed').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-7xl mx-auto space-y-4 md:space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm border p-4 md:p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h1 className="text-xl md:text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent break-words">
                Site Visit Management
              </h1>
              <p className="text-sm md:text-base text-gray-600 mt-1">Review and manage customer site visit requests</p>
            </div>
            <div className="flex items-center gap-2 md:gap-3 bg-gray-50 rounded-lg px-3 md:px-4 py-2 flex-shrink-0">
              <User className="h-4 md:h-5 w-4 md:w-5 text-blue-600" />
              <span className="text-xs md:text-sm font-medium text-gray-700 truncate">{user?.fullName}</span>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6">
          <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200 shadow-lg hover:shadow-xl transition-all duration-200">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs md:text-sm font-medium text-orange-700 truncate">Pending Approval</p>
                  <p className="text-2xl md:text-3xl font-bold text-orange-600">{pendingCount}</p>
                  <p className="text-xs text-orange-600 mt-1 truncate">Awaiting review</p>
                </div>
                <div className="bg-orange-100 p-2 md:p-3 rounded-full flex-shrink-0">
                  <Clock className="h-5 w-5 md:h-8 md:w-8 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 shadow-lg hover:shadow-xl transition-all duration-200">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs md:text-sm font-medium text-green-700 truncate">Approved</p>
                  <p className="text-2xl md:text-3xl font-bold text-green-600">{approvedCount}</p>
                  <p className="text-xs text-green-600 mt-1 truncate">Ready for visit</p>
                </div>
                <div className="bg-green-100 p-2 md:p-3 rounded-full flex-shrink-0">
                  <CheckCircle className="h-5 w-5 md:h-8 md:w-8 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 shadow-lg hover:shadow-xl transition-all duration-200">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs md:text-sm font-medium text-blue-700 truncate">Completed</p>
                  <p className="text-2xl md:text-3xl font-bold text-blue-600">{completedCount}</p>
                  <p className="text-xs text-blue-600 mt-1 truncate">Successfully done</p>
                </div>
                <div className="bg-blue-100 p-2 md:p-3 rounded-full flex-shrink-0">
                  <Car className="h-5 w-5 md:h-8 md:w-8 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-gray-50 to-slate-50 border-gray-200 shadow-lg hover:shadow-xl transition-all duration-200">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs md:text-sm font-medium text-gray-700 truncate">Total Requests</p>
                  <p className="text-2xl md:text-3xl font-bold text-gray-900">{Array.isArray(siteVisits) ? siteVisits.length : 0}</p>
                  <p className="text-xs text-gray-600 mt-1 truncate">All time requests</p>
                </div>
                <div className="bg-gray-100 p-2 md:p-3 rounded-full flex-shrink-0">
                  <Building2 className="h-5 w-5 md:h-8 md:w-8 text-gray-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="shadow-lg border-0 bg-white">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-t-lg p-4 md:p-6">
            <CardTitle className="flex items-center gap-2 text-lg md:text-xl">
              <Filter className="h-5 w-5 md:h-6 md:w-6" />
              <span className="truncate">Filter Site Visit Requests</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <ModalSelect
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                  placeholder="All Statuses"
                  options={[
                    { value: 'all', label: 'All Statuses' },
                    { value: 'pending', label: 'Pending' },
                    { value: 'approved', label: 'Approved' },
                    { value: 'declined', label: 'Declined' },
                    { value: 'completed', label: 'Completed' }
                  ]}
                />
              </div>

              <div className="space-y-2">
                <Label>Visit Date</Label>
                <Input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Project</Label>
                <ModalSelect
                  value={projectFilter}
                  onValueChange={setProjectFilter}
                  placeholder="All Projects"
                  options={[
                    { value: 'all', label: 'All Projects' },
                    ...(projects?.map((project: any) => ({
                      value: project.id.toString(),
                      label: project.name
                    })) || [])
                  ]}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Site Visits List */}
        <Card className="shadow-lg border-0 bg-white">
          <CardHeader className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-t-lg p-4 md:p-6">
            <CardTitle className="text-lg md:text-xl">Site Visit Requests</CardTitle>
          </CardHeader>
          <CardContent className="p-3 md:p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
              </div>
            ) : filteredSiteVisits.length === 0 ? (
              <div className="text-center py-12">
                <MapPin className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Site Visits Found</h3>
                <p className="text-gray-500">No site visits match your current filters</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredSiteVisits.map((visit: any) => {
                  const isExpanded = expandedVisitId === visit.id;
                  return (
                    <div key={visit.id} className="bg-gradient-to-r from-white to-blue-50 border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-200">
                      {/* Collapsed Header - Always Visible */}
                      <div 
                        className="p-4 cursor-pointer hover:bg-blue-50/50 transition-colors duration-200"
                        onClick={() => toggleVisitExpansion(visit.id)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                              <h3 className="text-lg font-semibold text-gray-900">{visit.customerName}</h3>
                              <p className="text-sm text-gray-500">Request #{visit.id} • {new Date(visit.visitDate).toLocaleDateString()} at {visit.visitTime}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-3">
                            {getStatusBadge(visit.status)}
                            {isExpanded ? (
                              <ChevronUp className="h-5 w-5 text-gray-400" />
                            ) : (
                              <ChevronDown className="h-5 w-5 text-gray-400" />
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Expanded Details - Conditionally Visible */}
                      {isExpanded && (
                        <div className="px-6 pb-6 border-t border-gray-100 bg-white/50">
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4 mt-4">
                            <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                              <User className="h-5 w-5 text-blue-600" />
                              <div>
                                <p className="text-xs text-gray-500 font-medium">Sales Executive</p>
                                <p className="text-sm font-semibold">{getUserName(visit.salesExecutiveId)}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                              <Calendar className="h-5 w-5 text-green-600" />
                              <div>
                                <p className="text-xs text-gray-500 font-medium">Visit Date</p>
                                <p className="text-sm font-semibold">{new Date(visit.visitDate).toLocaleDateString()}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                              <Clock className="h-5 w-5 text-orange-600" />
                              <div>
                                <p className="text-xs text-gray-500 font-medium">Time</p>
                                <p className="text-sm font-semibold">{visit.visitTime}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                              <MapPin className="h-5 w-5 text-red-600" />
                              <div>
                                <p className="text-xs text-gray-500 font-medium">Pickup Location</p>
                                <p className="text-sm font-semibold">{visit.pickupLocation}</p>
                              </div>
                            </div>
                          </div>

                          <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                            <div className="flex items-center gap-2 mb-1">
                              <Building2 className="h-4 w-4 text-purple-600" />
                              <p className="text-xs text-gray-500 font-medium">Projects to Visit</p>
                            </div>
                            <p className="text-sm font-semibold">{getProjectNames(visit.projectIds)}</p>
                          </div>

                          {visit.notes && (
                            <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                              <p className="text-xs text-gray-500 font-medium mb-1">Notes</p>
                              <p className="text-sm text-gray-700">{visit.notes}</p>
                            </div>
                          )}

                          {visit.assignedDriverId && (
                            <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                              <div className="flex items-center gap-2 mb-1">
                                <Car className="h-4 w-4 text-indigo-600" />
                                <p className="text-xs text-gray-500 font-medium">Assigned Driver</p>
                              </div>
                              <p className="text-sm font-semibold">{getUserName(visit.assignedDriverId)}</p>
                            </div>
                          )}

                          {visit.status === 'completed' && visit.startOdometer && visit.endOdometer && (
                            <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                              <div className="flex items-center gap-2 mb-2">
                                <Car className="h-4 w-4 text-green-600" />
                                <p className="text-xs text-gray-500 font-medium">Trip Details</p>
                              </div>
                              <div className="grid grid-cols-3 gap-3 text-xs">
                                <div>
                                  <p className="text-gray-500">Start Reading</p>
                                  <p className="font-semibold">{visit.startOdometer} km</p>
                                </div>
                                <div>
                                  <p className="text-gray-500">End Reading</p>
                                  <p className="font-semibold">{visit.endOdometer} km</p>
                                </div>
                                <div>
                                  <p className="text-gray-500">Distance</p>
                                  <p className="font-semibold text-blue-600">
                                    {(parseFloat(visit.endOdometer) - parseFloat(visit.startOdometer)).toFixed(1)} km
                                  </p>
                                </div>
                              </div>
                            </div>
                          )}

                          {visit.status === 'completed' && visit.remarks && (
                            <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                              <p className="text-xs text-gray-500 font-medium mb-1">Completion Remarks</p>
                              <p className="text-sm text-gray-700">{visit.remarks}</p>
                            </div>
                          )}

                          <div className="flex gap-3">
                            {visit.status === 'pending' && (
                              <Button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleApproval(visit);
                                }}
                                className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium py-3 rounded-lg shadow-lg transform transition-all duration-200 hover:scale-[1.02]"
                              >
                                Review Request
                              </Button>
                            )}
                            <Button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(visit.id);
                              }}
                              variant="outline"
                              className="flex items-center gap-2 px-4 py-3 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
                              disabled={deleteMutation.isPending}
                            >
                              <Trash2 className="h-4 w-4" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Approval Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Review Site Visit Request</DialogTitle>
            </DialogHeader>
            
            {selectedVisit && (
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                  <h3 className="font-semibold text-lg mb-3 text-blue-900">Request Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <p className="text-gray-500 font-medium">Customer</p>
                      <p className="font-semibold text-gray-900">{selectedVisit.customerName}</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <p className="text-gray-500 font-medium">Sales Executive</p>
                      <p className="font-semibold text-gray-900">{getUserName(selectedVisit.salesExecutiveId)}</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <p className="text-gray-500 font-medium">Visit Date</p>
                      <p className="font-semibold text-gray-900">{new Date(selectedVisit.visitDate).toLocaleDateString()}</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <p className="text-gray-500 font-medium">Time</p>
                      <p className="font-semibold text-gray-900">{selectedVisit.visitTime}</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg shadow-sm md:col-span-2">
                      <p className="text-gray-500 font-medium">Pickup Location</p>
                      <p className="font-semibold text-gray-900">{selectedVisit.pickupLocation}</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg shadow-sm md:col-span-2">
                      <p className="text-gray-500 font-medium">Projects to Visit</p>
                      <p className="font-semibold text-gray-900">{getProjectNames(selectedVisit.projectIds)}</p>
                    </div>
                    {selectedVisit.notes && (
                      <div className="bg-white p-3 rounded-lg shadow-sm md:col-span-2">
                        <p className="text-gray-500 font-medium">Notes</p>
                        <p className="font-semibold text-gray-900">{selectedVisit.notes}</p>
                      </div>
                    )}
                  </div>
                </div>

                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Decision</Label>
                    <ModalSelect
                      value={form.watch('status')}
                      onValueChange={(value) => form.setValue('status', value as 'approved' | 'declined')}
                      placeholder="Select decision"
                      options={[
                        { value: 'approved', label: 'Approve' },
                        { value: 'declined', label: 'Decline' }
                      ]}
                    />
                  </div>

                  {form.watch('status') === 'approved' && (
                    <div className="space-y-2">
                      <Label>Assign Driver</Label>
                      <ModalSelect
                        value={form.watch('assignedDriverId')?.toString()}
                        onValueChange={(value) => form.setValue('assignedDriverId', parseInt(value))}
                        placeholder="Select a driver"
                        options={drivers.map((driver: any) => ({
                          value: driver.id.toString(),
                          label: driver.fullName
                        }))}
                      />
                    </div>
                  )}

                  <div className="flex justify-end gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={approveMutation.isPending}
                    >
                      {approveMutation.isPending ? "Updating..." : "Submit Decision"}
                    </Button>
                  </div>
                </form>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}