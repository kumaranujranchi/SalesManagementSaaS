import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { ActivityFeed } from "@/components/dashboard/activity-feed";
import { ProjectDetails } from "@/components/dashboard/project-details";
import { UserLeaderboard } from "@/components/dashboard/user-leaderboard";
import { CalendarView } from "@/components/dashboard/calendar-view";
import { SalesOverviewChart } from "@/components/dashboard/sales-overview-chart";
import { ProjectDistributionChart } from "@/components/dashboard/project-distribution-chart";
import { PaymentCollectionChart } from "@/components/dashboard/payment-collection-chart";
import { StatsCards } from "@/components/dashboard/stats-cards";
import { WeatherInfo } from "@/components/dashboard/weather-info";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { LogOut, UserPlus, FolderPlus, FileText, Building, Settings, Bell } from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";

export default function DashboardPage() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const { logoutMutation, user } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of your account.",
    });
  };
  
  const quickLinks = [
    { icon: <UserPlus className="h-4 w-4 mr-2" />, label: "Add Employee", onClick: () => navigate("/users") },
    { icon: <FolderPlus className="h-4 w-4 mr-2" />, label: "New Project", onClick: () => navigate("/projects") },
    { icon: <FileText className="h-4 w-4 mr-2" />, label: "Create Report", onClick: () => navigate("/sales") },
    { icon: <Building className="h-4 w-4 mr-2" />, label: "Add Department", onClick: () => navigate("/departments") },
    { icon: <Settings className="h-4 w-4 mr-2" />, label: "System Settings", onClick: () => navigate("/roles") },
  ];
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gradient-to-br from-orange-50 via-white to-indigo-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <header className="bg-white shadow-sm z-10 px-4 py-3 md:py-2 flex flex-col md:flex-row justify-between items-start md:items-center">
          <motion.h1 
            className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-orange-500 to-amber-500 bg-clip-text text-transparent"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Dashboard
            <span className="block md:hidden text-xs text-gray-500 mt-1 font-normal">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </span>
          </motion.h1>
          <div className="flex items-center gap-3 self-end md:self-auto">
            <Button variant="ghost" size="icon" className="text-neutral-600">
              <Bell className="h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="hidden md:flex items-center gap-2 hover:bg-red-50 hover:text-red-600 transition-colors"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </div>
        </header>
        
        <main className="flex-1 p-3 md:p-6 overflow-auto pb-28 md:pb-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            {/* Welcome Message */}
            <Card className="mb-4 md:mb-6 bg-gradient-to-r from-orange-500 to-amber-500 text-white border-none shadow-lg">
              <CardContent className="p-4 md:p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div>
                    <h2 className="text-lg md:text-2xl font-bold">Welcome back, {user?.fullName || (user?.username === 'admin' ? 'Administrator' : 'User')}!</h2>
                    <p className="text-orange-100 mt-1 text-sm md:text-base">Here's what's happening with your projects today.</p>
                  </div>
                  <div className="hidden md:flex flex-col gap-1">
                    <p className="text-sm text-orange-100">Today is {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                    <WeatherInfo />
                  </div>
                  <div className="md:hidden flex mt-2">
                    <WeatherInfo />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Stats Cards */}
            <div className="mb-4 md:mb-6">
              <StatsCards />
            </div>
            
            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-4 md:mb-6">
              <SalesOverviewChart />
              <ProjectDistributionChart />
            </div>
            
            {/* Payment Collection Chart */}
            <div className="mb-4 md:mb-6">
              <PaymentCollectionChart />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-7 gap-4 md:gap-6">
              {/* Left Column (4/7) */}
              <div className="lg:col-span-4 space-y-4 md:space-y-6">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <ActivityFeed />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  <ProjectDetails />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <UserLeaderboard />
                </motion.div>
              </div>
              
              {/* Right Column (3/7) */}
              <div className="lg:col-span-3 space-y-4 md:space-y-6">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <CalendarView />
                </motion.div>
                
                {/* Quick Links section removed as requested */}
              </div>
            </div>
          </motion.div>
          

        </main>
      </div>
    </div>
  );
}
