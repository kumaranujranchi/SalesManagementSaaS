import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Building2, User, Plus, Edit, X, Eye, ChevronDown, Car } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const siteVisitSchema = z.object({
  customerName: z.string().min(1, "Customer name is required"),
  visitDate: z.string().min(1, "Visit date is required"),
  visitTime: z.string().min(1, "Visit time is required"),
  pickupLocation: z.string().min(1, "Pickup location is required"),
  projectIds: z.array(z.number()).min(1, "At least one project must be selected"),
  notes: z.string().optional(),
});

type SiteVisitFormData = z.infer<typeof siteVisitSchema>;

export default function SiteVisitRequestPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedProjects, setSelectedProjects] = useState<number[]>([]);
  const [editingVisit, setEditingVisit] = useState<any>(null);
  const [showAllVisits, setShowAllVisits] = useState(false);
  const [expandedVisit, setExpandedVisit] = useState<number | null>(null);

  const form = useForm<SiteVisitFormData>({
    resolver: zodResolver(siteVisitSchema),
    defaultValues: {
      customerName: "",
      visitDate: "",
      visitTime: "",
      pickupLocation: "",
      projectIds: [],
      notes: "",
    },
  });

  // Fetch projects
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
  });

  // Fetch user's site visit requests
  const { data: siteVisits = [], isLoading } = useQuery({
    queryKey: ['/api/site-visits/sales', user?.id],
    queryFn: () => fetch(`/api/site-visits/sales/${user?.id}`).then(res => res.json()),
    enabled: !!user?.id,
  });

  // Fetch all site visits for viewing
  const { data: allVisits = [], isLoading: allVisitsLoading } = useQuery({
    queryKey: ['/api/site-visits'],
    enabled: showAllVisits,
  });

  const createSiteVisitMutation = useMutation({
    mutationFn: async (data: SiteVisitFormData) => {
      const res = await apiRequest("POST", "/api/site-visits", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Site visit request created",
        description: "Your request has been submitted for approval.",
      });
      form.reset();
      setSelectedProjects([]);
      setEditingVisit(null);
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/sales', user?.id] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create site visit request",
        variant: "destructive",
      });
    },
  });

  const updateSiteVisitMutation = useMutation({
    mutationFn: async ({ visitId, data }: { visitId: number; data: SiteVisitFormData }) => {
      const res = await apiRequest("PUT", `/api/site-visits/${visitId}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Site visit updated",
        description: "Your site visit request has been updated successfully.",
      });
      form.reset();
      setSelectedProjects([]);
      setEditingVisit(null);
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/sales', user?.id] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update site visit request",
        variant: "destructive",
      });
    },
  });

  const cancelSiteVisitMutation = useMutation({
    mutationFn: async (visitId: number) => {
      const res = await apiRequest("PUT", `/api/site-visits/${visitId}/cancel`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Site visit cancelled",
        description: "Your site visit request has been cancelled successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/sales', user?.id] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel site visit request",
        variant: "destructive",
      });
    },
  });

  const handleProjectToggle = (projectId: number) => {
    const updatedProjects = selectedProjects.includes(projectId)
      ? selectedProjects.filter(id => id !== projectId)
      : [...selectedProjects, projectId];
    
    setSelectedProjects(updatedProjects);
    form.setValue('projectIds', updatedProjects);
  };

  const onSubmit = (data: SiteVisitFormData) => {
    const submitData = {
      ...data,
      projectIds: selectedProjects,
    };
    
    if (editingVisit) {
      updateSiteVisitMutation.mutate({ visitId: editingVisit.id, data: submitData });
    } else {
      createSiteVisitMutation.mutate(submitData);
    }
  };

  const handleEdit = (visit: any) => {
    setEditingVisit(visit);
    const projectIds = JSON.parse(visit.projectIds);
    setSelectedProjects(projectIds);
    form.reset({
      customerName: visit.customerName,
      visitDate: visit.visitDate,
      visitTime: visit.visitTime,
      pickupLocation: visit.pickupLocation,
      projectIds: projectIds,
      notes: visit.notes || "",
    });
  };

  const handleCancel = (visitId: number) => {
    if (window.confirm("Are you sure you want to cancel this site visit request?")) {
      cancelSiteVisitMutation.mutate(visitId);
    }
  };

  const handleCancelEdit = () => {
    setEditingVisit(null);
    form.reset();
    setSelectedProjects([]);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary">Pending</Badge>;
      case 'approved':
        return <Badge variant="default" className="bg-green-500">Approved</Badge>;
      case 'declined':
        return <Badge variant="destructive">Declined</Badge>;
      case 'completed':
        return <Badge variant="outline" className="border-blue-500 text-blue-600">Completed</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="border-orange-500 text-orange-600">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getProjectNames = (projectIds: string) => {
    try {
      const ids = JSON.parse(projectIds);
      const projectNames = ids.map((id: number) => {
        const project = projects.find((p: any) => p.id === id);
        return project ? project.name : `Project ${id}`;
      });
      return projectNames.join(', ');
    } catch {
      return 'No projects selected';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-7xl mx-auto space-y-4 md:space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm border p-4 md:p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h1 className="text-xl md:text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent break-words">
                Site Visit Management
              </h1>
              <p className="text-sm md:text-base text-gray-600 mt-1">Request and track your customer site visits</p>
            </div>
            <div className="flex items-center gap-2 md:gap-3 bg-gray-50 rounded-lg px-3 md:px-4 py-2 flex-shrink-0">
              <User className="h-4 md:h-5 w-4 md:w-5 text-blue-600" />
              <span className="text-xs md:text-sm font-medium text-gray-700 truncate">{user?.fullName}</span>
            </div>
          </div>
        </div>

        {/* Request Form */}
        <Card className="shadow-lg border-0 bg-white">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg p-4 md:p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <CardTitle className="flex items-center gap-2 text-lg md:text-xl min-w-0 flex-1">
                <Plus className="h-5 w-5 md:h-6 md:w-6 flex-shrink-0" />
                <span className="truncate">{editingVisit ? 'Edit Site Visit Request' : 'Create New Site Visit Request'}</span>
              </CardTitle>
              <div className="flex gap-2 flex-shrink-0">
                <Button
                  onClick={() => setShowAllVisits(!showAllVisits)}
                  variant="outline"
                  size="sm"
                  className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                >
                  <Eye className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2" />
                  {showAllVisits ? 'Hide All Visits' : 'View All Visits'}
                </Button>
                {editingVisit && (
                  <Button
                    onClick={handleCancelEdit}
                    variant="outline"
                    className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel Edit
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="customerName" className="text-sm font-semibold text-gray-700">Customer Name</Label>
                  <Input
                    id="customerName"
                    {...form.register("customerName")}
                    placeholder="Enter customer name"
                    className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                  {form.formState.errors.customerName && (
                    <p className="text-sm text-red-600">{form.formState.errors.customerName.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pickupLocation" className="text-sm font-semibold text-gray-700">Pickup Location</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="pickupLocation"
                      {...form.register("pickupLocation")}
                      placeholder="Enter pickup address"
                      className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  {form.formState.errors.pickupLocation && (
                    <p className="text-sm text-red-600">{form.formState.errors.pickupLocation.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="visitDate" className="text-sm font-semibold text-gray-700">Visit Date</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="visitDate"
                      type="date"
                      {...form.register("visitDate")}
                      className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>
                  {form.formState.errors.visitDate && (
                    <p className="text-sm text-red-600">{form.formState.errors.visitDate.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="visitTime" className="text-sm font-semibold text-gray-700">Visit Time</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="visitTime"
                      type="time"
                      {...form.register("visitTime")}
                      className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  {form.formState.errors.visitTime && (
                    <p className="text-sm text-red-600">{form.formState.errors.visitTime.message}</p>
                  )}
                </div>
              </div>

              {/* Project Selection */}
              <div className="space-y-4">
                <Label className="text-sm font-semibold text-gray-700">Select Projects to Visit</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {projects.map((project: any) => (
                    <div
                      key={project.id}
                      className={`border-2 rounded-xl p-4 cursor-pointer transition-all duration-200 transform hover:scale-[1.02] ${
                        selectedProjects.includes(project.id)
                          ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-indigo-50 shadow-lg'
                          : 'border-gray-200 hover:border-blue-300 hover:shadow-md bg-white'
                      }`}
                      onClick={() => handleProjectToggle(project.id)}
                    >
                      <div className="flex items-start gap-3">
                        <div onClick={(e) => e.stopPropagation()}>
                          <Checkbox
                            checked={selectedProjects.includes(project.id)}
                            onCheckedChange={() => handleProjectToggle(project.id)}
                            className="mt-1"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <div className={`p-2 rounded-lg ${
                              selectedProjects.includes(project.id) 
                                ? 'bg-blue-100' 
                                : 'bg-gray-100'
                            }`}>
                              <Building2 className={`h-4 w-4 ${
                                selectedProjects.includes(project.id) 
                                  ? 'text-blue-600' 
                                  : 'text-gray-500'
                              }`} />
                            </div>
                            <h3 className="font-semibold text-gray-900">{project.name}</h3>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{project.description}</p>
                          <div className="flex items-center gap-2">
                            <Badge variant={selectedProjects.includes(project.id) ? "default" : "outline"} className="text-xs">
                              {project.projectType}
                            </Badge>
                            {project.location && (
                              <span className="text-xs text-gray-500 flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                {project.location}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                {form.formState.errors.projectIds && (
                  <p className="text-sm text-red-600">{form.formState.errors.projectIds.message}</p>
                )}
              </div>

              {/* Notes Section */}
              <div className="space-y-2">
                <Label htmlFor="notes" className="text-sm font-semibold text-gray-700">Additional Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  {...form.register("notes")}
                  placeholder="Enter any additional comments, special requests, or important information..."
                  className="min-h-[100px] border-gray-300 focus:border-blue-500 focus:ring-blue-500 resize-none"
                  rows={4}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-4 rounded-xl shadow-lg transform transition-all duration-200 hover:scale-[1.02] hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                disabled={createSiteVisitMutation.isPending || updateSiteVisitMutation.isPending}
              >
                {(createSiteVisitMutation.isPending || updateSiteVisitMutation.isPending) ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    {editingVisit ? 'Updating Request...' : 'Creating Request...'}
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Plus className="h-5 w-5" />
                    {editingVisit ? 'Update Site Visit Request' : 'Submit Site Visit Request'}
                  </div>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Previous Requests */}
        <Card className="shadow-lg border-0 bg-white">
          <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg">
            <CardTitle className="text-xl">Your Site Visit Requests</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
              </div>
            ) : siteVisits.length === 0 ? (
              <div className="text-center py-12">
                <MapPin className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Site Visit Requests</h3>
                <p className="text-gray-500">Create your first site visit request using the form above</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {siteVisits.map((visit: any) => (
                  <div key={visit.id} className="bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-xl p-6 hover:shadow-md transition-all duration-200">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{visit.customerName}</h3>
                          <p className="text-sm text-gray-500">Site Visit Request #{visit.id}</p>
                        </div>
                      </div>
                      {getStatusBadge(visit.status)}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                        <Calendar className="h-5 w-5 text-blue-600" />
                        <div>
                          <p className="text-xs text-gray-500 font-medium">Visit Date</p>
                          <p className="text-sm font-semibold">{new Date(visit.visitDate).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                        <Clock className="h-5 w-5 text-green-600" />
                        <div>
                          <p className="text-xs text-gray-500 font-medium">Time</p>
                          <p className="text-sm font-semibold">{visit.visitTime}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                        <MapPin className="h-5 w-5 text-red-600" />
                        <div>
                          <p className="text-xs text-gray-500 font-medium">Pickup Location</p>
                          <p className="text-sm font-semibold">{visit.pickupLocation}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-white rounded-lg p-3 shadow-sm">
                        <Building2 className="h-5 w-5 text-purple-600" />
                        <div>
                          <p className="text-xs text-gray-500 font-medium">Projects</p>
                          <p className="text-sm font-semibold">{getProjectNames(visit.projectIds)}</p>
                        </div>
                      </div>
                    </div>
                    {visit.notes && (
                      <div className="mt-4 bg-white rounded-lg p-3 shadow-sm">
                        <p className="text-xs text-gray-500 font-medium mb-1">Notes</p>
                        <p className="text-sm text-gray-700">{visit.notes}</p>
                      </div>
                    )}
                    
                    {/* Action buttons for Sales Executive */}
                    {(visit.status === 'pending' || visit.status === 'declined') && (
                      <div className="mt-4 pt-4 border-t border-gray-200 flex gap-2">
                        <Button
                          onClick={() => handleEdit(visit)}
                          variant="outline"
                          size="sm"
                          className="flex items-center gap-1"
                        >
                          <Edit className="h-4 w-4" />
                          Edit
                        </Button>
                        <Button
                          onClick={() => handleCancel(visit.id)}
                          variant="outline"
                          size="sm"
                          className="flex items-center gap-1 text-orange-600 border-orange-300 hover:bg-orange-50"
                        >
                          <X className="h-4 w-4" />
                          Cancel
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* All Site Visits Modal */}
        {showAllVisits && (
          <Card className="shadow-lg border-0 bg-white mt-6">
            <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
              <CardTitle className="text-xl flex items-center gap-2">
                <Eye className="h-6 w-6" />
                All Site Visits
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {allVisitsLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full" />
                </div>
              ) : allVisits?.length === 0 ? (
                <div className="text-center py-12">
                  <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Site Visits Found</h3>
                  <p className="text-gray-500">There are no site visits scheduled in the system</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {allVisits?.map((visit: any, index: number) => (
                    <Collapsible
                      key={visit.id}
                      open={expandedVisit === visit.id}
                      onOpenChange={(isOpen) => setExpandedVisit(isOpen ? visit.id : null)}
                    >
                      <div className="border border-gray-200 rounded-lg">
                        <CollapsibleTrigger asChild>
                          <div className="flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                                <User className="h-5 w-5 text-purple-600" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-900">{visit.customerName}</h4>
                                <p className="text-sm text-gray-500">
                                  {new Date(visit.visitDate).toLocaleDateString()} at {visit.visitTime}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {getStatusBadge(visit.status)}
                              <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${expandedVisit === visit.id ? 'rotate-180' : ''}`} />
                            </div>
                          </div>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="px-4 pb-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-gray-100">
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-gray-400" />
                              <span className="text-sm">{visit.pickupLocation}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Building2 className="h-4 w-4 text-gray-400" />
                              <span className="text-sm">{getProjectNames(visit.projectIds)}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4 text-gray-400" />
                              <span className="text-sm">
                                Sales Executive: {visit.salesExecutiveName || 'N/A'}
                              </span>
                            </div>
                            {visit.driver && (
                              <div className="flex items-center gap-2">
                                <Car className="h-4 w-4 text-gray-400" />
                                <span className="text-sm">Driver: {visit.driver.fullName}</span>
                              </div>
                            )}
                            {visit.notes && (
                              <div className="md:col-span-2 lg:col-span-3">
                                <p className="text-sm text-gray-600">
                                  <strong>Notes:</strong> {visit.notes}
                                </p>
                              </div>
                            )}
                          </div>
                        </CollapsibleContent>
                      </div>
                    </Collapsible>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}