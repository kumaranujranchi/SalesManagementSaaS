import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ProjectCard } from "@/components/project-management/project-card";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  CalendarIcon, 
  CheckCircle2, 
  Clock, 
  Edit, 
  Eye, 
  FileText, 
  Filter, 
  Plus, 
  Search, 
  Trash2, 
  Users 
} from "lucide-react";
import { Project, InsertProject } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertProjectSchema } from "@shared/schema";

// Extend the project schema for the form
const projectFormSchema = insertProjectSchema.extend({
  deadlineStr: z.string().optional(),
  projectType: z.enum(["Land", "Apartment", "Duplex"]),
  status: z.enum(["running", "closed", "on_hold"]).default("running"),
  imageUrl: z.string().url("Please enter a valid URL").optional(),
  location: z.string().min(5, "Location must be at least 5 characters"),
}).omit({ createdBy: true, createdAt: true });

type ProjectFormValues = z.infer<typeof projectFormSchema>;

export default function ProjectManagementPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  
  const { data: projects, isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    onError: () => {
      toast({
        title: "Failed to load projects",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  });
  
  const createProject = useMutation({
    mutationFn: async (data: InsertProject) => {
      const res = await apiRequest("POST", "/api/projects", data);
      try {
        const json = await res.json();
        return json;
      } catch (error) {
        console.error("Error parsing response:", error);
        throw new Error("Failed to parse server response");
      }
    },
    onSuccess: () => {
      toast({
        title: "Project created",
        description: "The project has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setShowAddDialog(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create project.",
        variant: "destructive",
      });
    },
  });
  
  const updateProject = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertProject> }) => {
      const res = await apiRequest("PATCH", `/api/projects/${id}`, data);
      try {
        const json = await res.json();
        return json;
      } catch (error) {
        console.error("Error parsing response:", error);
        throw new Error("Failed to parse server response");
      }
    },
    onSuccess: () => {
      toast({
        title: "Project updated",
        description: "The project has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setShowEditDialog(false);
      setSelectedProject(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update project.",
        variant: "destructive",
      });
    },
  });
  
  const deleteProject = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/projects/${id}`);
      try {
        const json = await res.json();
        return json;
      } catch (error) {
        console.error("Error parsing response:", error);
        throw new Error("Failed to parse server response");
      }
    },
    onSuccess: () => {
      toast({
        title: "Project deleted",
        description: "The project has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setShowDeleteDialog(false);
      setSelectedProject(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete project.",
        variant: "destructive",
      });
    },
  });
  
  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      name: "",
      description: "",
      status: "running",
      projectType: "Land",
      imageUrl: "",
      location: "",
      deadlineStr: "",
    },
  });
  
  const onSubmit = (data: ProjectFormValues) => {
    const { deadlineStr, ...rest } = data;
    const deadline = deadlineStr ? new Date(deadlineStr) : undefined;
    
    createProject.mutate({
      ...rest,
      deadline,
      createdBy: 1, // This would come from the authenticated user in a real app
    });
  };
  
  // Filter projects by search term and status
  const filteredProjects = projects
    ? projects.filter(project => 
        project.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        (statusFilter === "All" || project.status === statusFilter.toLowerCase())
      )
    : [];
  
  // Event handlers for project actions
  const handleEditProject = (project: Project) => {
    setSelectedProject(project);
    
    // Set form values for editing
    form.reset({
      name: project.name,
      description: project.description || "",
      status: (project.status as "running" | "closed" | "on_hold") || "running",
      projectType: (project.projectType as "Land" | "Apartment" | "Duplex") || "Land",
      imageUrl: project.imageUrl || "",
      location: project.location || "",
      deadlineStr: project.deadline ? new Date(project.deadline).toISOString().split('T')[0] : "",
    });
    
    setShowEditDialog(true);
  };
  
  const handleViewProject = (project: Project) => {
    setSelectedProject(project);
    setShowViewDialog(true);
  };
  
  const handleDeleteProject = (project: Project) => {
    setSelectedProject(project);
    setShowDeleteDialog(true);
  };
  
  const handleUpdateProject = (data: ProjectFormValues) => {
    if (!selectedProject) return;
    
    const { deadlineStr, ...rest } = data;
    const deadline = deadlineStr ? new Date(deadlineStr) : undefined;
    
    updateProject.mutate({
      id: selectedProject.id,
      data: {
        ...rest,
        deadline,
      }
    });
  };
  
  const confirmDeleteProject = () => {
    if (!selectedProject) return;
    deleteProject.mutate(selectedProject.id);
  };
  
  const getStatusBadgeStyle = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'running':
        return "bg-green-100 text-green-800";
      case 'on_hold':
        return "bg-yellow-100 text-yellow-800";
      case 'closed':
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-blue-100 text-blue-800";
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <div className="mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <h1 className="text-2xl font-bold">Project Management</h1>
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button variant="default" className="mt-4 md:mt-0 flex items-center">
                    <Plus className="mr-2 h-4 w-4" />
                    Add New Project
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[550px]">
                  <DialogHeader>
                    <DialogTitle>Add New Project</DialogTitle>
                    <DialogDescription>
                      Create a new project and assign it to a team.
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={form.handleSubmit(onSubmit)}>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="name" className="text-right text-sm font-medium">
                          Project Name
                        </label>
                        <Input
                          id="name"
                          className="col-span-3"
                          placeholder="Enter project name"
                          {...form.register("name")}
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="description" className="text-right text-sm font-medium">
                          Description
                        </label>
                        <Textarea
                          id="description"
                          className="col-span-3"
                          placeholder="Enter project description"
                          {...form.register("description")}
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="projectType" className="text-right text-sm font-medium">
                          Project Type
                        </label>
                        <Select
                          defaultValue={form.getValues().projectType}
                          onValueChange={(value) => form.setValue("projectType", value as "Land" | "Apartment" | "Duplex")}
                        >
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select project type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Land">Land</SelectItem>
                            <SelectItem value="Apartment">Apartment</SelectItem>
                            <SelectItem value="Duplex">Duplex</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="imageUrl" className="text-right text-sm font-medium">
                          Image URL
                        </label>
                        <Input
                          id="imageUrl"
                          className="col-span-3"
                          placeholder="Enter project image URL"
                          {...form.register("imageUrl")}
                        />
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="location" className="text-right text-sm font-medium">
                          Location
                        </label>
                        <Textarea
                          id="location"
                          className="col-span-3"
                          placeholder="Enter full project address"
                          {...form.register("location")}
                        />
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="status" className="text-right text-sm font-medium">
                          Status
                        </label>
                        <Select
                          defaultValue={form.getValues().status}
                          onValueChange={(value) => form.setValue("status", value as "running" | "closed" | "on_hold")}
                        >
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="running">Running</SelectItem>
                            <SelectItem value="closed">Closed</SelectItem>
                            <SelectItem value="on_hold">On Hold</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      

                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createProject.isPending}>
                        {createProject.isPending ? "Creating..." : "Create Project"}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">TOTAL PROJECTS</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{projects?.length || 0}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">RUNNING</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {projects?.filter(p => p.status?.toLowerCase() === 'running').length || 0}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">ON HOLD</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {projects?.filter(p => p.status?.toLowerCase() === 'on_hold').length || 0}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">CLOSED</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {projects?.filter(p => p.status?.toLowerCase() === 'closed').length || 0}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <CardTitle>Projects</CardTitle>
                    <CardDescription>Manage and track your construction projects</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2 mt-4 md:mt-0">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral-500" />
                      <Input
                        type="search"
                        placeholder="Search projects..."
                        className="pl-9 w-[200px] md:w-[260px]"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <Select
                      value={statusFilter}
                      onValueChange={setStatusFilter}
                    >
                      <SelectTrigger className="w-[130px]">
                        <SelectValue placeholder="Filter Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All">All Statuses</SelectItem>
                        <SelectItem value="running">Running</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                        <SelectItem value="on_hold">On Hold</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="list" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-4">
                    <TabsTrigger value="list" className="flex items-center justify-center">
                      <FileText className="mr-2 h-4 w-4" />
                      List View
                    </TabsTrigger>
                    <TabsTrigger value="board" className="flex items-center justify-center">
                      <Columns className="mr-2 h-4 w-4" />
                      Board View
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="list">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Project Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Deadline</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoading ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-4">
                              Loading projects...
                            </TableCell>
                          </TableRow>
                        ) : filteredProjects.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-4">
                              No projects found. Try adjusting your filters or create a new project.
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredProjects.map((project) => (
                            <TableRow key={project.id}>
                              <TableCell className="font-medium">{project.name}</TableCell>
                              <TableCell>{project.projectType || "N/A"}</TableCell>
                              <TableCell>
                                {project.location 
                                  ? (project.location.length > 20 
                                    ? project.location.substring(0, 20) + '...' 
                                    : project.location)
                                  : "N/A"}
                              </TableCell>
                              <TableCell>
                                <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${getStatusBadgeStyle(project.status)}`}>
                                  {project.status}
                                </span>
                              </TableCell>
                              <TableCell>
                                {project.deadline 
                                  ? new Date(project.deadline).toLocaleDateString() 
                                  : "No deadline"}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleEditProject(project)}
                                >
                                  <span className="sr-only">Edit</span>
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleViewProject(project)}
                                >
                                  <span className="sr-only">View</span>
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleDeleteProject(project)}
                                >
                                  <span className="sr-only">Delete</span>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </TabsContent>
                  
                  <TabsContent value="board">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-4">
                        <div className="bg-green-50 p-2 rounded-md">
                          <h3 className="font-medium text-green-700 flex items-center mb-2">
                            <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                            Running
                          </h3>
                          
                          {filteredProjects
                            .filter(p => p.status?.toLowerCase() === 'running')
                            .map(project => (
                              <ProjectCard 
                                key={project.id}
                                project={project}
                                statusColor="border-green-500"
                                onEdit={handleEditProject}
                                onView={handleViewProject}
                              />
                            ))}
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="bg-blue-50 p-2 rounded-md">
                          <h3 className="font-medium text-blue-700 flex items-center mb-2">
                            <span className="h-2 w-2 rounded-full bg-blue-700 mr-2"></span>
                            On Hold
                          </h3>
                          
                          {filteredProjects
                            .filter(p => p.status?.toLowerCase() === 'on_hold')
                            .map(project => (
                              <ProjectCard 
                                key={project.id}
                                project={project}
                                statusColor="border-blue-500"
                                onEdit={handleEditProject}
                                onView={handleViewProject}
                              />
                            ))}
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="bg-gray-50 p-2 rounded-md">
                          <h3 className="font-medium text-gray-700 flex items-center mb-2">
                            <span className="h-2 w-2 rounded-full bg-gray-700 mr-2"></span>
                            Closed
                          </h3>
                          
                          {filteredProjects
                            .filter(p => p.status?.toLowerCase() === 'closed')
                            .map(project => (
                              <ProjectCard 
                                key={project.id}
                                project={project}
                                statusColor="border-gray-500"
                                onEdit={handleEditProject}
                                onView={handleViewProject}
                              />
                            ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  

                </Tabs>
              </CardContent>
              <CardFooter className="flex items-center justify-between">
                <div className="text-sm text-neutral-600">
                  Showing {filteredProjects.length} of {projects?.length || 0} projects
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    Previous
                  </Button>
                  <Button variant="outline" size="sm">
                    Next
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
          
          {/* View Project Dialog */}
          <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
            <DialogContent className="sm:max-w-[550px]">
              {selectedProject && (
                <>
                  <DialogHeader>
                    <DialogTitle>Project Details</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    {selectedProject.imageUrl && (
                      <div className="w-full h-40 relative overflow-hidden rounded-md mb-2">
                        <img 
                          src={selectedProject.imageUrl} 
                          alt={selectedProject.name} 
                          className="w-full h-full object-cover"
                          onError={(e) => e.currentTarget.style.display = 'none'}
                        />
                      </div>
                    )}
                    
                    <div>
                      <h3 className="text-lg font-bold">{selectedProject.name}</h3>
                      <p className="text-neutral-600 mt-1">{selectedProject.description}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Project Type</p>
                        <p>{selectedProject.projectType}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Status</p>
                        <p className="capitalize">{selectedProject.status}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Location</p>
                        <p>{selectedProject.location}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Deadline</p>
                        <p>{selectedProject.deadline 
                          ? new Date(selectedProject.deadline).toLocaleDateString() 
                          : "No deadline"}
                        </p>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={() => setShowViewDialog(false)}>
                      Close
                    </Button>
                  </DialogFooter>
                </>
              )}
            </DialogContent>
          </Dialog>
          
          {/* Edit Project Dialog */}
          <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Edit Project</DialogTitle>
                <DialogDescription>
                  Update project details and information.
                </DialogDescription>
              </DialogHeader>
              
              {selectedProject && (
                <form onSubmit={form.handleSubmit(handleUpdateProject)}>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <label htmlFor="name" className="text-right text-sm font-medium">
                        Project Name
                      </label>
                      <Input
                        id="name"
                        className="col-span-3"
                        placeholder="Enter project name"
                        {...form.register("name")}
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <label htmlFor="description" className="text-right text-sm font-medium">
                        Description
                      </label>
                      <Textarea
                        id="description"
                        className="col-span-3"
                        placeholder="Enter project description"
                        {...form.register("description")}
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <label htmlFor="projectType" className="text-right text-sm font-medium">
                        Project Type
                      </label>
                      <Select
                        value={form.getValues().projectType}
                        onValueChange={(value) => form.setValue("projectType", value as "Land" | "Apartment" | "Duplex")}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select project type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Land">Land</SelectItem>
                          <SelectItem value="Apartment">Apartment</SelectItem>
                          <SelectItem value="Duplex">Duplex</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <label htmlFor="imageUrl" className="text-right text-sm font-medium">
                        Image URL
                      </label>
                      <Input
                        id="imageUrl"
                        className="col-span-3"
                        placeholder="Enter project image URL"
                        {...form.register("imageUrl")}
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <label htmlFor="location" className="text-right text-sm font-medium">
                        Location
                      </label>
                      <Textarea
                        id="location"
                        className="col-span-3"
                        placeholder="Enter full project address"
                        {...form.register("location")}
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <label htmlFor="status" className="text-right text-sm font-medium">
                        Status
                      </label>
                      <Select
                        value={form.getValues().status}
                        onValueChange={(value) => form.setValue("status", value as "running" | "closed" | "on_hold")}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="running">Running</SelectItem>
                          <SelectItem value="closed">Closed</SelectItem>
                          <SelectItem value="on_hold">On Hold</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => {
                        setShowEditDialog(false);
                        setSelectedProject(null);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={updateProject.isPending}
                      className="bg-orange-500 hover:bg-orange-600"
                    >
                      {updateProject.isPending ? "Updating..." : "Update Project"}
                    </Button>
                  </DialogFooter>
                </form>
              )}
            </DialogContent>
          </Dialog>
          
          {/* Delete Project Dialog */}
          <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Confirm Deletion</DialogTitle>
                <DialogDescription>
                  Are you sure you want to delete this project? This action cannot be undone.
                </DialogDescription>
              </DialogHeader>
              
              {selectedProject && (
                <div className="py-4">
                  <p className="mb-2">Project: <span className="font-semibold">{selectedProject.name}</span></p>
                  <p className="text-neutral-600 text-sm">{selectedProject.description}</p>
                </div>
              )}
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowDeleteDialog(false);
                    setSelectedProject(null);
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  type="button" 
                  variant="destructive" 
                  onClick={confirmDeleteProject}
                  disabled={deleteProject.isPending}
                >
                  {deleteProject.isPending ? "Deleting..." : "Delete Project"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}

function Columns(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 9h18M3 15h18" />
    </svg>
  );
}
