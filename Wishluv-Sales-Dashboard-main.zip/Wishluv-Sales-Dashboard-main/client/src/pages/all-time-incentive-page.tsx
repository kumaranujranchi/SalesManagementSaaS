import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, DollarSign, TrendingUp, Trophy } from "lucide-react";
import { SalesSidebar } from "@/components/layout/sales-sidebar";

interface PaymentMilestone {
  customerName: string;
  mobileNumber: string;
  bookingDate: string;
  agreementStatus: string;
  agreementDate: string;
  eligibleSlab: string;
  paymentReceived: string;
  totalRevenue: number;
  incentiveAmount: number;
  payoutMonth: string;
  payoutStatus: string;
}

export default function AllTimeIncentivePage() {
  const { user } = useAuth();
  const [allTimeData, setAllTimeData] = useState<PaymentMilestone[]>([]);
  const [targetData, setTargetData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [totalIncentiveEarned, setTotalIncentiveEarned] = useState(0);
  const [totalEligibleSales, setTotalEligibleSales] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);

  useEffect(() => {
    const fetchAllTimeIncentiveData = async () => {
      if (!user) return;
      
      try {
        const [salesRes, targetRes] = await Promise.all([
          fetch(`/api/sales/user`), // Get only the logged-in user's sales
          fetch(`/api/targets/achievement/${user.id}`)
        ]);

        const allSalesData = await salesRes.json();
        const targetData = await targetRes.json();
        
        setTargetData(targetData);
        
        // Calculate total metrics
        const totalAreaSold = allSalesData.reduce((total: number, sale: any) => total + (parseFloat(sale.areaSold) || 0), 0);
        const totalTarget = targetData?.totalTarget || 0;
        const totalAchievement = totalAreaSold;
        
        // Check overall eligibility
        const isOverallPerformancePositive = totalAchievement >= totalTarget;
        
        // Process all sales data with same logic as main dashboard
        const allMilestones = allSalesData.map((sale: any) => {
          const revenue = parseFloat(sale.areaSold) * parseFloat(sale.baseSalePrice);
          
          // For all-time view, check if this sale contributes to achieving any monthly target
          const saleDate = new Date(sale.bookingDate);
          const saleMonth = saleDate.getMonth() + 1;
          const saleYear = saleDate.getFullYear();
          
          // Find the monthly target for this sale's month
          const monthlyTargetForSale = targetData?.monthlyBreakdown?.find((m: any) => 
            m.year === saleYear && m.month === saleMonth
          )?.target || 0;
          
          // Find monthly achievement for this sale's month
          const monthlyAchievementForSale = targetData?.monthlyBreakdown?.find((m: any) => 
            m.year === saleYear && m.month === saleMonth
          )?.achieved || 0;
          
          const isMonthlyTargetAchieved = monthlyAchievementForSale >= monthlyTargetForSale;
          const isEligibleForIncentive = isMonthlyTargetAchieved && isOverallPerformancePositive && sale.agreementStatus === 'Yes';
          
          // Calculate slab and incentive only if eligible
          const currentSlab = isEligibleForIncentive ? (totalAreaSold >= 7100 ? 4 : totalAreaSold >= 5000 ? 3 : totalAreaSold >= 3000 ? 2 : 1) : 0;
          const incentiveRate = [0, 1, 2, 3, 4][currentSlab] / 100;
          const incentiveAmount = isEligibleForIncentive ? revenue * incentiveRate : 0;
          
          // Get actual payment percentage from database
          const paymentPercentage = parseFloat(sale.paymentPercentage) || 0;
          
          // Determine actual payment milestone reached with proper formatting
          let paymentMilestone = '0.00%';
          const roundedPercentage = Math.round(paymentPercentage * 100) / 100; // Round to 2 decimal places
          
          if (roundedPercentage >= 100) paymentMilestone = '100.00%';
          else if (roundedPercentage >= 75) paymentMilestone = '75.00%';
          else if (roundedPercentage >= 50) paymentMilestone = '50.00%';
          else if (roundedPercentage >= 30) paymentMilestone = '30.00%';
          else paymentMilestone = `${roundedPercentage.toFixed(2)}%`;
          
          // Determine payout quarter based on booking date
          const month = saleDate.getMonth() + 1;
          let payoutMonth = '';
          
          if (month >= 1 && month <= 3) payoutMonth = 'April';
          else if (month >= 4 && month <= 6) payoutMonth = 'July';
          else if (month >= 7 && month <= 9) payoutMonth = 'October';
          else payoutMonth = 'January';
          
          // Determine payout status based on all eligibility conditions
          let payoutStatus = 'Not Eligible';
          if (isEligibleForIncentive) {
            if (paymentPercentage >= 30) {
              payoutStatus = paymentPercentage >= 100 ? 'Processing' : 'Pending';
            } else {
              payoutStatus = 'Pending';
            }
          }
          
          // Handle Agreement Date properly using correct database field
          let displayAgreementDate = '';
          if (sale.bookingDone === 'Yes') {
            if (sale.agreementDate && sale.agreementDate !== sale.bookingDate) {
              displayAgreementDate = new Date(sale.agreementDate).toLocaleDateString();
            } else {
              displayAgreementDate = 'Agreement not done';
            }
          } else {
            displayAgreementDate = 'Agreement not done';
          }

          // Calculate progressive incentive amounts (30%, 20%, 25%, 25% distribution)
          const thirtyPercentIncentive = isEligibleForIncentive ? Math.round(incentiveAmount * 0.30) : 0;
          const fiftyPercentIncentive = isEligibleForIncentive ? Math.round(incentiveAmount * 0.20) : 0;
          const seventyFivePercentIncentive = isEligibleForIncentive ? Math.round(incentiveAmount * 0.25) : 0;
          const hundredPercentIncentive = isEligibleForIncentive ? (incentiveAmount - thirtyPercentIncentive - fiftyPercentIncentive - seventyFivePercentIncentive) : 0;

          return {
            customerName: sale.customerName || 'Customer Name',
            mobileNumber: sale.customerMobile || 'N/A',
            bookingDate: sale.bookingDate,
            agreementStatus: sale.bookingDone || 'No',
            agreementDate: displayAgreementDate,
            eligibleSlab: isEligibleForIncentive ? `${[0, 1, 2, 3, 4][currentSlab]}%` : 'Not Eligible',
            paymentReceived: paymentMilestone,
            totalRevenue: revenue,
            incentiveAmount: incentiveAmount,
            thirtyPercentIncentive,
            fiftyPercentIncentive,
            seventyFivePercentIncentive,
            hundredPercentIncentive,
            payoutMonth: payoutMonth,
            payoutStatus: payoutStatus
          };
        });
        
        setAllTimeData(allMilestones);
        
        // Calculate summary metrics
        const totalIncentive = allMilestones.reduce((sum, milestone) => sum + milestone.incentiveAmount, 0);
        const eligibleSales = allMilestones.filter(milestone => milestone.incentiveAmount > 0).length;
        const totalRev = allMilestones.reduce((sum, milestone) => sum + milestone.totalRevenue, 0);
        
        setTotalIncentiveEarned(totalIncentive);
        setTotalEligibleSales(eligibleSales);
        setTotalRevenue(totalRev);
        
      } catch (error) {
        console.error("Error fetching all-time incentive data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAllTimeIncentiveData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex">
        <SalesSidebar />
        <div className="flex-1 min-h-screen bg-gray-50">
          <div className="p-6">
            <div className="flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
                <p className="text-gray-600">Loading all-time incentive data...</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex">
      <SalesSidebar />
      <div className="flex-1 min-h-screen bg-gray-50 md:ml-56 pb-16 md:pb-0">
        <div className="p-4 md:p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => window.history.back()}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">All-Time Incentive History</h1>
                <p className="text-gray-600">Complete lifetime sales and incentive tracking</p>
              </div>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-green-700">Total Incentive Earned</p>
                    <p className="text-2xl font-bold text-green-900">₹ {totalIncentiveEarned.toLocaleString('en-IN')}</p>
                  </div>
                  <Trophy className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-700">Eligible Sales</p>
                    <p className="text-2xl font-bold text-blue-900">{totalEligibleSales}</p>
                    <p className="text-xs text-blue-600">out of {allTimeData.length} total</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-purple-700">Total Revenue</p>
                    <p className="text-2xl font-bold text-purple-900">₹ {totalRevenue.toLocaleString('en-IN')}</p>
                    <p className="text-xs text-purple-600">Lifetime earnings</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-amber-50 to-amber-100 border-amber-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-amber-700">Average Incentive</p>
                    <p className="text-2xl font-bold text-amber-900">
                      ₹ {totalEligibleSales > 0 ? Math.round(totalIncentiveEarned / totalEligibleSales).toLocaleString('en-IN') : '0'}
                    </p>
                    <p className="text-xs text-amber-600">Per eligible sale</p>
                  </div>
                  <Calendar className="h-8 w-8 text-amber-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* All-Time Sales History Table */}
          <Card>
            <CardHeader>
              <CardTitle>Complete Sales & Incentive History</CardTitle>
              <p className="text-sm text-gray-600">
                All-time sales with incentive eligibility tracking and payment milestone status
              </p>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="text-left p-2 font-medium">Customer Name</th>
                      <th className="text-left p-2 font-medium">Mobile Number</th>
                      <th className="text-left p-2 font-medium">Booking Date</th>
                      <th className="text-left p-2 font-medium">Agreement Status</th>
                      <th className="text-left p-2 font-medium">Agreement Date</th>
                      <th className="text-left p-2 font-medium">Eligible Slab</th>
                      <th className="text-left p-2 font-medium">Payment Received</th>
                      <th className="text-left p-2 font-medium">Total Revenue</th>
                      <th className="text-left p-2 font-medium">Total Incentive</th>
                      <th className="text-left p-2 font-medium">30% Slab Incentive</th>
                      <th className="text-left p-2 font-medium">50% Slab Incentive</th>
                      <th className="text-left p-2 font-medium">75% Slab Incentive</th>
                      <th className="text-left p-2 font-medium">100% Slab Incentive</th>
                      <th className="text-left p-2 font-medium">Payout Month</th>
                      <th className="text-left p-2 font-medium">Payout Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allTimeData.map((milestone, index) => (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium">{milestone.customerName}</td>
                        <td className="p-2">{milestone.mobileNumber}</td>
                        <td className="p-2">{new Date(milestone.bookingDate).toLocaleDateString()}</td>
                        <td className="p-2">
                          <Badge 
                            className={`${milestone.agreementStatus === 'Yes' ? 'bg-green-500' : 'bg-red-500'}`}
                          >
                            {milestone.agreementStatus}
                          </Badge>
                        </td>
                        <td className="p-2">{milestone.agreementDate}</td>
                        <td className="p-2">
                          <Badge variant="outline" className="bg-blue-50">
                            {milestone.eligibleSlab}
                          </Badge>
                        </td>
                        <td className="p-2">
                          <Badge 
                            className={`${milestone.paymentReceived.includes('100') ? 'bg-green-500 text-white' : 
                                        milestone.paymentReceived.includes('75') ? 'bg-blue-500 text-white' : 
                                        milestone.paymentReceived.includes('50') ? 'bg-orange-500 text-white' : 
                                        milestone.paymentReceived.includes('30') ? 'bg-yellow-400 text-black' : 'bg-gray-200 text-gray-800'}`}
                          >
                            {milestone.paymentReceived}
                          </Badge>
                        </td>
                        <td className="p-2 font-medium">₹ {milestone.totalRevenue.toLocaleString('en-IN')}</td>
                        <td className="p-2 font-medium text-green-600">
                          {milestone.incentiveAmount > 0 ? `₹ ${milestone.incentiveAmount.toLocaleString('en-IN')}` : '₹ 0'}
                        </td>
                        <td className="p-2 font-medium text-blue-600">
                          {milestone.thirtyPercentIncentive > 0 ? `₹ ${milestone.thirtyPercentIncentive.toLocaleString('en-IN')}` : '₹ 0'}
                        </td>
                        <td className="p-2 font-medium text-orange-600">
                          {milestone.fiftyPercentIncentive > 0 ? `₹ ${milestone.fiftyPercentIncentive.toLocaleString('en-IN')}` : '₹ 0'}
                        </td>
                        <td className="p-2 font-medium text-purple-600">
                          {milestone.seventyFivePercentIncentive > 0 ? `₹ ${milestone.seventyFivePercentIncentive.toLocaleString('en-IN')}` : '₹ 0'}
                        </td>
                        <td className="p-2 font-medium text-green-700">
                          {milestone.hundredPercentIncentive > 0 ? `₹ ${milestone.hundredPercentIncentive.toLocaleString('en-IN')}` : '₹ 0'}
                        </td>
                        <td className="p-2">{milestone.payoutMonth}</td>
                        <td className="p-2">
                          <Badge 
                            className={`${milestone.payoutStatus === 'Paid' ? 'bg-green-500' : 
                                        milestone.payoutStatus === 'Processing' ? 'bg-blue-500' : 
                                        milestone.payoutStatus === 'Not Eligible' ? 'bg-red-500' : 'bg-orange-500'}`}
                          >
                            {milestone.payoutStatus}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {allTimeData.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No sales data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}