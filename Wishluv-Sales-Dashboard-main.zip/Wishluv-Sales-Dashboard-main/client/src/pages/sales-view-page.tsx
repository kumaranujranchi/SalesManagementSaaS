import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BarChart3, Search, Building2, Calendar, PlusCircle, Loader2 } from "lucide-react";
import type { Sales, Project } from "@shared/schema";

export default function SalesViewPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch sales data
  const { data: sales = [], isLoading: isSalesLoading } = useQuery<Sales[]>({
    queryKey: ["/api/sales"],
  });

  // Fetch projects data for reference
  const { data: projects = [], isLoading: isProjectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  // Helper to get project name
  const getProjectName = (projectId: number) => {
    const project = projects.find(p => p.id === projectId);
    return project ? project.name : "Unknown Project";
  };

  // Filter sales data based on search and current user
  const filteredSales = sales
    .filter(sale => sale.salesExecutiveId === user?.id) // Only show user's own sales
    .filter(sale => {
      if (!searchTerm) return true;
      const projectName = getProjectName(sale.projectId);
      const searchLower = searchTerm.toLowerCase();
      return (
        projectName.toLowerCase().includes(searchLower) ||
        sale.bookingAmount.toString().includes(searchLower) ||
        format(new Date(sale.bookingDate), "MMM d, yyyy").toLowerCase().includes(searchLower)
      );
    });

  // Get user's own sales total
  const totalSales = filteredSales.reduce((sum, sale) => sum + Number(sale.bookingAmount), 0);
  const totalArea = filteredSales.reduce((sum, sale) => sum + Number(sale.areaSold), 0);

  return (
    <div className="flex-1 space-y-6 pb-24 md:pb-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-2xl font-bold">Sales History</h1>
          <p className="text-muted-foreground">View your historical sales records</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalSales.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Area</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalArea.toLocaleString()} sq.ft.</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredSales.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by project, amount..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Sales Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Your Sales Records</CardTitle>
          <CardDescription>
            Showing {filteredSales.length} records
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isSalesLoading || isProjectsLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : filteredSales.length === 0 ? (
            <div className="text-center py-8">
              <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No sales records found</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm ? "Try a different search term." : "You haven't made any sales yet."}
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Project</TableHead>
                    <TableHead>Booking Date</TableHead>
                    <TableHead className="text-right">Area (sq.ft.)</TableHead>
                    <TableHead className="text-right">Amount (₹)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSales.map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">{getProjectName(sale.projectId)}</TableCell>
                      <TableCell>{format(new Date(sale.bookingDate), "MMM d, yyyy")}</TableCell>
                      <TableCell className="text-right">{Number(sale.areaSold).toLocaleString()}</TableCell>
                      <TableCell className="text-right">₹{Number(sale.bookingAmount).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}