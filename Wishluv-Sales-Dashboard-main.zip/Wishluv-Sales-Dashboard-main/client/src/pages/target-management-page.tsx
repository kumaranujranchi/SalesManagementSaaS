import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Target, User, Sales } from "@shared/schema";
import { format } from "date-fns";
import { 
  Loader2, 
  Target as TargetIcon, 
  FileBarChart2, 
  Users,
  Calendar,
  Plus,
  Pencil,
  Trash2
} from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { getMonthName } from "@/lib/date-utils";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { TargetAchievementAdminCard } from "@/components/dashboard/target-achievement-admin-card";

// Schema for target form
const targetFormSchema = z.object({
  userId: z.number({
    required_error: "User is required",
  }),
  year: z.number({
    required_error: "Year is required",
  }).min(2023, "Year must be 2023 or later"),
  month: z.number({
    required_error: "Month is required",
  }).min(1, "Month must be between 1 and 12").max(12, "Month must be between 1 and 12"),
  targetValue: z.number({
    required_error: "Target value is required",
  }).min(1, "Target must be greater than 0"),
});

type TargetFormValues = z.infer<typeof targetFormSchema>;

const TargetManagementPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showTargetForm, setShowTargetForm] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showExecutiveDropdown, setShowExecutiveDropdown] = useState(false);
  const [showYearDropdown, setShowYearDropdown] = useState(false);
  const [showMonthDropdown, setShowMonthDropdown] = useState(false);
  const [editingTarget, setEditingTarget] = useState<Target | null>(null);
  const [targetToDelete, setTargetToDelete] = useState<Target | null>(null);
  const [filterUserId, setFilterUserId] = useState<number | null>(null);
  
  // Initialize form
  const form = useForm<TargetFormValues>({
    resolver: zodResolver(targetFormSchema),
    defaultValues: {
      userId: 0,
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      targetValue: 0,
    },
  });
  
  // Fetch all targets
  const { 
    data: targets, 
    isLoading: isLoadingTargets, 
    refetch: refetchTargets 
  } = useQuery<Target[]>({
    queryKey: ["/api/targets"],
    queryFn: async () => {
      const timestamp = Date.now(); // Add timestamp to prevent caching
      const res = await fetch(`/api/targets?_t=${timestamp}`);
      if (!res.ok) throw new Error("Failed to fetch targets");
      return res.json();
    },
    staleTime: 0, // Always fetch fresh data
    cacheTime: 0  // Don't cache the results
  });
  
  // Fetch all sales users
  const {
    data: users,
    isLoading: isLoadingUsers
  } = useQuery<User[]>({
    queryKey: ["/api/users-sales"],
    queryFn: async () => {
      const res = await fetch('/api/users?department=Sales');
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    }
  });
  
  // Create target mutation
  const createTargetMutation = useMutation({
    mutationFn: async (data: TargetFormValues) => {
      const res = await apiRequest('POST', '/api/targets', data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Target created",
        description: "The sales target has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/targets"] });
      queryClient.refetchQueries({ queryKey: ["/api/targets"] });
      refetchTargets(); // Force immediate refetch
      setShowTargetForm(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create target",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Update target mutation
  const updateTargetMutation = useMutation({
    mutationFn: async (data: TargetFormValues & { id: number }) => {
      const { id, ...targetData } = data;
      const res = await apiRequest('PUT', `/api/targets/${id}`, targetData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Target updated",
        description: "The sales target has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/targets"] });
      setShowTargetForm(false);
      setEditingTarget(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update target",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Delete target mutation
  const deleteTargetMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/targets/${id}`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Target deleted",
        description: "The sales target has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/targets"] });
      setTargetToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete target",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Update form when editing a target or when filterUserId changes
  useEffect(() => {
    if (editingTarget) {
      form.reset({
        userId: editingTarget.userId,
        year: editingTarget.year,
        month: editingTarget.month,
        targetValue: editingTarget.targetValue,
      });
    } else {
      form.reset({
        userId: filterUserId || 0,
        year: new Date().getFullYear(),
        month: new Date().getMonth() + 1,
        targetValue: 0,
      });
    }
  }, [editingTarget, filterUserId, form]);
  
  const onSubmit = (data: TargetFormValues) => {
    if (editingTarget) {
      updateTargetMutation.mutate({ ...data, id: editingTarget.id });
    } else {
      createTargetMutation.mutate(data);
    }
  };
  
  const handleEdit = (target: Target) => {
    setEditingTarget(target);
    setShowTargetForm(true);
  };
  
  const handleDelete = (target: Target) => {
    setTargetToDelete(target);
  };
  
  const closeForm = () => {
    setShowTargetForm(false);
    setEditingTarget(null);
    form.reset();
  };
  
  // Filter targets by user if selected
  const filteredTargets = targets && filterUserId 
    ? targets.filter(target => target.userId === filterUserId) 
    : targets;
  
  const getUserName = (userId: number) => {
    const user = users?.find(u => u.id === userId);
    return user ? user.fullName : `User #${userId}`;
  };
  
  return (
    <div className="container mx-auto px-4">
      <PageHeader 
        title="Target Management" 
        subtitle="Set and manage sales targets for your team" 
        icon={<TargetIcon className="h-6 w-6" />} 
      />
      
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <TargetIcon className="h-4 w-4 mr-2" />
              Total Assigned Targets
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{targets?.length || 0}</div>
            <p className="text-xs text-muted-foreground">
              Active target assignments
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Sales Executives
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users?.length || 0}</div>
            <p className="text-xs text-muted-foreground">
              Active sales team members
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Calendar className="h-4 w-4 mr-2" />
              Current Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {targets?.filter(t => t.month === new Date().getMonth() + 1 && t.year === new Date().getFullYear()).length || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Targets for {getMonthName(new Date().getMonth() + 1)} {new Date().getFullYear()}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-2 flex flex-wrap justify-between items-center">
            <div>
              <CardTitle>Target Management</CardTitle>
              <CardDescription>Create and manage monthly sales targets for your team</CardDescription>
            </div>
            <Link href="/admin/target-analytics" className="mt-2 md:mt-0">
              <Button variant="outline" className="flex items-center gap-2">
                <FileBarChart2 className="h-4 w-4" />
                View Detailed Analytics
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-4">
              <Button 
                onClick={() => {
                  setEditingTarget(null);
                  setShowTargetForm(true);
                }}
                className="flex items-center gap-2"
                data-action="add-target"
              >
                <Plus className="h-4 w-4" /> Add New Target
              </Button>
              
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowUserDropdown(prev => !prev)}
                  className="w-52 px-4 py-2 border rounded-md flex justify-between items-center bg-background"
                >
                  <span>
                    {filterUserId === null 
                      ? "All Users" 
                      : users?.find(u => u.id === filterUserId)?.fullName || "Select User"}
                  </span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m6 9 6 6 6-6"/>
                  </svg>
                </button>
                
                {showUserDropdown && (
                  <div className="absolute z-50 mt-1 w-64 max-h-64 overflow-y-auto bg-background border rounded-md shadow-md">
                    <button
                      type="button"
                      className={`w-full px-4 py-2 text-left hover:bg-muted/50 ${filterUserId === null ? 'bg-primary/10 text-primary font-medium' : ''}`}
                      onClick={() => {
                        setFilterUserId(null);
                        setShowUserDropdown(false);
                      }}
                    >
                      All Users
                    </button>
                    {users?.map(user => (
                      <button
                        key={user.id}
                        type="button"
                        className={`w-full px-4 py-2 text-left hover:bg-muted/50 ${filterUserId === user.id ? 'bg-primary/10 text-primary font-medium' : ''}`}
                        onClick={() => {
                          setFilterUserId(user.id);
                          setShowUserDropdown(false);
                        }}
                      >
                        {user.fullName}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
            
            {isLoadingTargets ? (
              <div className="flex justify-center items-center p-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredTargets && filteredTargets.length > 0 ? (
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Period</TableHead>
                      <TableHead className="text-right">Target (sqft)</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTargets.map(target => (
                      <TableRow key={target.id}>
                        <TableCell>{getUserName(target.userId)}</TableCell>
                        <TableCell>{getMonthName(target.month)} {target.year}</TableCell>
                        <TableCell className="text-right">{target.targetValue.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(target)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDelete(target)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8 border rounded-md">
                <TargetIcon className="h-12 w-12 mx-auto text-muted-foreground opacity-30" />
                <p className="mt-2 text-muted-foreground">No targets found</p>
                <p className="text-sm text-muted-foreground">
                  {filterUserId ? "Try selecting a different user or" : "Get started by"} creating a new target
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Target Form Dialog */}
      <Dialog open={showTargetForm} onOpenChange={setShowTargetForm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingTarget ? "Edit Target" : "Create New Target"}
            </DialogTitle>
            <DialogDescription>
              {editingTarget 
                ? "Update the target details below" 
                : "Set a new monthly target for a sales executive"}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sales Executive</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <button
                          type="button"
                          disabled={editingTarget !== null}
                          onClick={() => setShowExecutiveDropdown(prev => !prev)}
                          className="w-full px-4 py-2 text-left border rounded-md flex justify-between items-center bg-background"
                        >
                          <span>
                            {field.value ? 
                              users?.find(u => u.id === field.value)?.fullName || "Select Executive" 
                              : "Select Executive"}
                          </span>
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="m6 9 6 6 6-6"/>
                          </svg>
                        </button>
                        
                        {showExecutiveDropdown && (
                          <div className="absolute z-50 mt-1 w-full max-h-48 overflow-y-auto bg-background border rounded-md shadow-md">
                            {isLoadingUsers ? (
                              <div className="flex items-center justify-center p-3">
                                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                                <span>Loading...</span>
                              </div>
                            ) : users && users.length > 0 ? (
                              users
                                .filter(user => user.department === "Sales")
                                .map(user => (
                                  <button
                                    key={user.id}
                                    type="button"
                                    disabled={editingTarget !== null}
                                    className={`w-full px-4 py-2 text-left hover:bg-muted/50 ${
                                      field.value === user.id ? 'bg-primary/10 text-primary font-medium' : ''
                                    } ${editingTarget !== null ? 'opacity-60 cursor-not-allowed' : ''}`}
                                    onClick={() => {
                                      field.onChange(user.id);
                                      setShowExecutiveDropdown(false);
                                    }}
                                  >
                                    {user.fullName}
                                  </button>
                                ))
                            ) : (
                              <div className="text-center p-3 text-muted-foreground">
                                No users found
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="year"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Year</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <button
                            type="button"
                            disabled={editingTarget !== null}
                            onClick={() => setShowYearDropdown(prev => !prev)}
                            className="w-full px-4 py-2 text-left border rounded-md flex justify-between items-center bg-background"
                          >
                            <span>{field.value || "Select Year"}</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="m6 9 6 6 6-6"/>
                            </svg>
                          </button>
                          
                          {showYearDropdown && (
                            <div className="absolute z-50 mt-1 w-full max-h-48 overflow-y-auto bg-background border rounded-md shadow-md">
                              {[2023, 2024, 2025, 2026, 2027, 2028].map(year => (
                                <button
                                  key={year}
                                  type="button"
                                  disabled={editingTarget !== null}
                                  className={`w-full px-4 py-2 text-left hover:bg-muted/50 ${
                                    field.value === year ? 'bg-primary/10 text-primary font-medium' : ''
                                  } ${editingTarget !== null ? 'opacity-60 cursor-not-allowed' : ''}`}
                                  onClick={() => {
                                    field.onChange(year);
                                    setShowYearDropdown(false);
                                  }}
                                >
                                  {year}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="month"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Month</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <button
                            type="button"
                            disabled={editingTarget !== null}
                            onClick={() => setShowMonthDropdown(prev => !prev)}
                            className="w-full px-4 py-2 text-left border rounded-md flex justify-between items-center bg-background"
                          >
                            <span>{field.value ? getMonthName(field.value) : "Select Month"}</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="m6 9 6 6 6-6"/>
                            </svg>
                          </button>
                          
                          {showMonthDropdown && (
                            <div className="absolute z-50 mt-1 w-full max-h-48 overflow-y-auto bg-background border rounded-md shadow-md">
                              {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                                <button
                                  key={month}
                                  type="button"
                                  disabled={editingTarget !== null}
                                  className={`w-full px-4 py-2 text-left hover:bg-muted/50 ${
                                    field.value === month ? 'bg-primary/10 text-primary font-medium' : ''
                                  } ${editingTarget !== null ? 'opacity-60 cursor-not-allowed' : ''}`}
                                  onClick={() => {
                                    field.onChange(month);
                                    setShowMonthDropdown(false);
                                  }}
                                >
                                  {getMonthName(month)}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="targetValue"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Target Value (sqft)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="Enter target value"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button variant="outline" type="button" onClick={closeForm}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingTarget ? "Update Target" : "Create Target"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!targetToDelete} onOpenChange={(open) => !open && setTargetToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Target</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this target? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => targetToDelete && deleteTargetMutation.mutate(targetToDelete.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <div className="flex justify-between items-center mt-8 mb-4">
        <h2 className="text-2xl font-bold">Target Achievements</h2>
      </div>
      
      <p className="text-muted-foreground mb-8">
        View detailed target achievement analytics by team, month, or individual sales executive.
      </p>
    </div>
  );
};

// Component to show detailed monthly target and achievement data for a selected user
interface UserTargetDetailProps {
  userId: number;
}

function UserTargetDetailView({ userId }: UserTargetDetailProps) {
  const { toast } = useToast();
  const now = new Date();
  const currentYear = now.getFullYear();
  
  // Get user information
  const { data: userData, isLoading: isLoadingUser } = useQuery<User>({
    queryKey: ["/api/users", userId],
    queryFn: async () => {
      const res = await fetch(`/api/users/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch user data");
      return res.json();
    }
  });
  
  // DIRECTLY get user targets from the database - this is the source of truth
  // These are the exact values the admin assigned
  const { data: userTargets, isLoading: isLoadingTargets } = useQuery<Target[]>({
    queryKey: ["/api/targets", userId],
    queryFn: async () => {
      const timestamp = new Date().getTime(); // Prevent caching
      const res = await fetch(`/api/targets?userId=${userId}&ts=${timestamp}`);
      if (!res.ok) throw new Error("Failed to fetch target data");
      return res.json();
    }
  });
  
  // Get sales achievements for comparison
  const { data: salesData, isLoading: isLoadingSales } = useQuery({
    queryKey: ["/api/sales", userId],
    queryFn: async () => {
      const timestamp = new Date().getTime(); // Prevent caching
      const res = await fetch(`/api/sales?salesExecutiveId=${userId}&ts=${timestamp}`);
      if (!res.ok) throw new Error("Failed to fetch sales data");
      return res.json();
    }
  });
  
  // Loading state
  if (isLoadingUser || isLoadingTargets || isLoadingSales) {
    return (
      <div className="flex justify-center items-center p-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  // Error state
  if (!userData || !userTargets) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">No data available</p>
      </div>
    );
  }
  
  // Calculate achievements from sales data
  const achievements: Record<string, number> = {};
  
  if (salesData && salesData.length > 0) {
    salesData.forEach((sale: any) => {
      const bookingDate = new Date(sale.bookingDate);
      const year = bookingDate.getFullYear();
      const month = bookingDate.getMonth() + 1; // Convert to 1-12 format
      const key = `${year}-${month}`;
      
      if (!achievements[key]) {
        achievements[key] = 0;
      }
      
      // Make sure we have a valid area sold value
      let areaValue = 0;
      if (sale.areaSold !== null && sale.areaSold !== undefined) {
        if (typeof sale.areaSold === 'number') {
          areaValue = sale.areaSold;
        } else if (typeof sale.areaSold === 'string') {
          areaValue = parseFloat(sale.areaSold);
        }
      }
      
      if (!isNaN(areaValue)) {
        achievements[key] += areaValue;
      }
    });
  }
  
  // Process the targets and match with achievements
  // We must use a unique ID for each row to prevent React key warnings
  const processedData = userTargets.map((target, index) => {
    const year = target.year;
    const month = target.month;
    const key = `${year}-${month}`;
    const monthName = new Date(year, month - 1, 1).toLocaleString('default', { month: 'long' });
    const achieved = achievements[key] || 0;
    const percentageAchieved = target.targetValue > 0 
      ? Math.round((achieved / target.targetValue) * 100)
      : 0;
    
    return {
      id: target.id || index, // Use the database ID as the unique identifier
      year,
      month,
      monthName,
      target: target.targetValue,
      achieved,
      percentageAchieved
    };
  });
  
  // Sort by newest date first
  processedData.sort((a, b) => {
    if (a.year !== b.year) return b.year - a.year; 
    return b.month - a.month;
  });
  
  // Calculate YTD totals
  const ytdTarget = processedData.reduce((total, item) => total + item.target, 0);
  const ytdAchieved = processedData.reduce((total, item) => total + item.achieved, 0);
  const ytdPercentage = ytdTarget > 0 ? Math.min(Math.round((ytdAchieved / ytdTarget) * 100), 100) : 0;
  
  return (
    <div className="space-y-6">
      {/* Summary card */}
      <div className="bg-primary/10 p-4 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-medium">{userData.fullName}</h3>
          <span className="text-sm text-muted-foreground">{userData.department} / {userData.designation}</span>
        </div>
        <div className="grid grid-cols-3 gap-4 mb-2">
          <div>
            <p className="text-sm text-muted-foreground">YTD Target</p>
            <p className="text-lg font-semibold">{ytdTarget.toLocaleString()} sqft</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">YTD Achievement</p>
            <p className="text-lg font-semibold">{ytdAchieved.toLocaleString()} sqft</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Progress</p>
            <p className="text-lg font-semibold">{ytdPercentage}%</p>
          </div>
        </div>
        <Progress value={ytdPercentage} className="h-2" />
      </div>
      
      {/* Monthly breakdown table */}
      <div className="border rounded-md overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Month</TableHead>
              <TableHead className="text-right">Target (sqft)</TableHead>
              <TableHead className="text-right">Achievement (sqft)</TableHead>
              <TableHead className="text-right">Progress</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {processedData.length > 0 ? (
              processedData.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>
                    {item.monthName} {item.year}
                  </TableCell>
                  <TableCell className="text-right">
                    {item.target.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right">
                    {item.achieved ? item.achieved.toLocaleString() : '0'}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end">
                      <span className="mr-2">{item.percentageAchieved}%</span>
                      <div className="w-16 bg-muted rounded-full h-2 overflow-hidden">
                        <div 
                          className={`h-full ${item.percentageAchieved >= 100 ? 'bg-success' : 'bg-primary'}`}
                          style={{ width: `${item.percentageAchieved}%` }}
                        />
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-4">
                  <p className="text-muted-foreground">No targets assigned yet</p>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Add button to set a new target */}
      <div className="flex justify-end">
        <Button
          variant="outline"
          className="flex items-center gap-2"
          onClick={() => {
            // Find the form component in the parent and trigger it
            const formButton = document.querySelector('[data-action="add-target"]');
            if (formButton && formButton instanceof HTMLButtonElement) {
              formButton.click();
            }
          }}
        >
          <Plus className="h-4 w-4" /> Add Target for {userData.fullName}
        </Button>
      </div>
    </div>
  );
}

export default TargetManagementPage;