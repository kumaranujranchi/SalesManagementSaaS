import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { BillingPeriod } from "@/components/billing/billing-period";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  CreditCard, 
  History, 
  Receipt, 
  FileText, 
  Download, 
  CheckCircle, 
  Clock 
} from "lucide-react";

interface Invoice {
  id: string;
  date: string;
  amount: number;
  status: "paid" | "pending" | "overdue";
  downloadUrl: string;
}

const invoices: Invoice[] = [
  {
    id: "INV-2023-001",
    date: "2023-10-15",
    amount: 1499.00,
    status: "paid",
    downloadUrl: "#"
  },
  {
    id: "INV-2023-002",
    date: "2023-09-15",
    amount: 1499.00,
    status: "paid",
    downloadUrl: "#"
  },
  {
    id: "INV-2023-003",
    date: "2023-08-15",
    amount: 1499.00,
    status: "paid",
    downloadUrl: "#"
  },
  {
    id: "INV-2023-004",
    date: "2023-11-15",
    amount: 1499.00,
    status: "pending",
    downloadUrl: "#"
  }
];

export default function BillingPage() {
  const [activeTab, setActiveTab] = useState("plans");
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" /> Paid
          </span>
        );
      case "pending":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3 mr-1" /> Pending
          </span>
        );
      case "overdue":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <AlertTriangle className="w-3 h-3 mr-1" /> Overdue
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-6">Billing & Subscription</h1>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="plans" className="flex items-center">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Plans & Pricing
                </TabsTrigger>
                <TabsTrigger value="invoices" className="flex items-center">
                  <Receipt className="w-4 h-4 mr-2" />
                  Invoices
                </TabsTrigger>
                <TabsTrigger value="history" className="flex items-center">
                  <History className="w-4 h-4 mr-2" />
                  Payment History
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="plans">
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Current Plan</CardTitle>
                    <CardDescription>Your subscription details</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-primary/10 p-4 rounded-md">
                      <div>
                        <h3 className="font-bold text-lg">Professional Plan</h3>
                        <p className="text-neutral-600">Active until November 15, 2024</p>
                        <div className="mt-2 flex items-center">
                          <span className="font-semibold">₹ 1,499.00 / month</span>
                          <span className="ml-2 text-green-600 text-sm">20% off annual billing</span>
                        </div>
                      </div>
                      <div className="mt-4 md:mt-0 md:ml-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <BillingPeriod />
              </TabsContent>
              
              <TabsContent value="invoices">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Invoices</CardTitle>
                    <CardDescription>View and download your invoices</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Invoice</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Date</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Amount</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Status</th>
                            <th className="px-4 py-3 text-right text-xs font-medium text-neutral-700 uppercase tracking-wider">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {invoices.map((invoice) => (
                            <tr key={invoice.id} className="border-b">
                              <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">
                                <div className="flex items-center">
                                  <FileText className="w-4 h-4 mr-2 text-neutral-500" />
                                  {invoice.id}
                                </div>
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {new Date(invoice.date).toLocaleDateString()}
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm font-semibold">
                                ₹ {invoice.amount.toFixed(2)}
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm">
                                {getStatusBadge(invoice.status)}
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm text-right">
                                <a 
                                  href={invoice.downloadUrl} 
                                  className="inline-flex items-center text-secondary hover:text-secondary/80"
                                >
                                  <Download className="w-4 h-4 mr-1" />
                                  PDF
                                </a>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="history">
                <Card>
                  <CardHeader>
                    <CardTitle>Payment History</CardTitle>
                    <CardDescription>All your past transactions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Transaction ID</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Date</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Amount</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Payment Method</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-neutral-700 uppercase tracking-wider">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b">
                            <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">#TX12345678</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-600">Oct 15, 2023</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm font-semibold">₹ 1,499.00</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm">
                              <div className="flex items-center">
                                <CreditCard className="w-4 h-4 mr-2 text-neutral-500" />
                                Card ending in 4242
                              </div>
                            </td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm">
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <CheckCircle className="w-3 h-3 mr-1" /> Successful
                              </span>
                            </td>
                          </tr>
                          <tr className="border-b">
                            <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">#TX12345623</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-600">Sep 15, 2023</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm font-semibold">₹ 1,499.00</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm">
                              <div className="flex items-center">
                                <CreditCard className="w-4 h-4 mr-2 text-neutral-500" />
                                Card ending in 4242
                              </div>
                            </td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm">
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <CheckCircle className="w-3 h-3 mr-1" /> Successful
                              </span>
                            </td>
                          </tr>
                          <tr className="border-b">
                            <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">#TX12345589</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-600">Aug 15, 2023</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm font-semibold">₹ 1,499.00</td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm">
                              <div className="flex items-center">
                                <CreditCard className="w-4 h-4 mr-2 text-neutral-500" />
                                Card ending in 4242
                              </div>
                            </td>
                            <td className="px-4 py-4 whitespace-nowrap text-sm">
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <CheckCircle className="w-3 h-3 mr-1" /> Successful
                              </span>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}

function AlertTriangle(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
    </svg>
  );
}
