import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  FileText,
  Filter,
  CalendarRange,
  IndianRupee,
  SquareIcon,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Sales, Project } from "@shared/schema";
import { PaymentHistoryDialog } from "@/components/sales/payment-history-dialog";

// Extended Sales type for UI display
interface EnhancedSale extends Sales {
  customerType?: string;
  pricePerSqFt?: number;
}

// Card component for sales stats
function SalesStatsCard({
  icon,
  title,
  value,
  description,
  bgClass = "bg-blue-50",
  valueColor = "text-blue-700"
}: {
  icon: React.ReactNode;
  title: string;
  value: string | number;
  description: string;
  bgClass?: string;
  valueColor?: string;
}) {
  return (
    <Card className="border-0 shadow-sm overflow-hidden h-full">
      <div className="flex flex-col h-full">
        <div className={`${bgClass} px-3 md:px-4 lg:px-5 py-2 md:py-3`}>
          <div className="flex items-center">
            <span className="flex-shrink-0">{icon}</span>
            <h3 className="ml-2 text-xs md:text-sm font-medium truncate">{title}</h3>
          </div>
        </div>
        <CardContent className="flex-1 p-3 md:p-4 lg:p-5">
          <div className={`text-lg md:text-xl lg:text-2xl font-bold ${valueColor} break-words`}>{value}</div>
          <p className="text-xs text-gray-500 mt-1 line-clamp-2">{description}</p>
        </CardContent>
      </div>
    </Card>
  );
}

export default function SalesDashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("all-sales");
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedSale, setSelectedSale] = useState<Sales | null>(null);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);

  // Fetch user's sales data
  const { data: salesData, isLoading } = useQuery<Sales[]>({
    queryKey: ["/api/sales/user"],
    queryFn: async () => {
      const res = await fetch("/api/sales/user");
      if (!res.ok) throw new Error("Failed to fetch sales data");
      return res.json();
    }
  });

  // Fetch project data for lookups
  const { data: projectsData } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const res = await fetch("/api/projects");
      if (!res.ok) throw new Error("Failed to fetch projects");
      return res.json();
    }
  });

  // Calculate summary statistics - exclude cancelled sales
  const activeSales = salesData?.filter(sale => !sale.cancelledAt) || [];
  const totalSalesCount = activeSales.length;
  
  // Current month sales - exclude cancelled sales
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  const thisMonthSales = activeSales.filter(sale => {
    const saleDate = new Date(sale.bookingDate);
    return saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear;
  });
  
  // Total area sold - exclude cancelled sales
  const totalAreaSold = activeSales.reduce((total, sale) => 
    total + parseFloat(sale.areaSold.toString() || "0"), 0);
  
  // Total revenue - exclude cancelled sales
  const totalRevenue = activeSales.reduce((total, sale) => 
    total + parseFloat(sale.finalAmount?.toString() || "0"), 0);

  // Filter sales based on active tab and enhance with UI properties
  const getFilteredSales = (): EnhancedSale[] => {
    if (!salesData) return [];
    
    let filtered: Sales[];
    
    switch (activeTab) {
      case "this-month":
        filtered = salesData.filter(sale => {
          const saleDate = new Date(sale.bookingDate);
          return saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear;
        });
        break;
      case "this-year":
        filtered = salesData.filter(sale => {
          const saleDate = new Date(sale.bookingDate);
          return saleDate.getFullYear() === currentYear;
        });
        break;
      default:
        filtered = [...salesData];
    }
    
    // Add UI properties to each sale
    return filtered.map(sale => ({
      ...sale,
      customerType: sale.customerName?.includes("Premium") ? "Premium" : undefined,
      pricePerSqFt: sale.baseSalePrice ? parseFloat(sale.baseSalePrice) : undefined
    }));
  };

  const filteredSales = getFilteredSales();

  // Handle Payment Button Click
  const handlePaymentClick = (sale: Sales) => {
    setSelectedSale(sale);
    setPaymentDialogOpen(true);
  };

  // Close payment dialog
  const handleClosePaymentDialog = () => {
    setPaymentDialogOpen(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <>
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-start">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-slate-800 flex items-center">
              <FileText className="mr-2 h-5 w-5 text-amber-600" />
              Sales Management
            </h1>
            <p className="text-gray-600 mt-1">Track and manage your sales activities</p>
          </div>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 lg:gap-5 mb-8">
        {/* Total Sales Card */}
        <SalesStatsCard
          icon={<FileText className="h-5 w-5 text-blue-600" />}
          title="Total Sales"
          value={totalSalesCount}
          description="Across filtered period"
          bgClass="bg-blue-50"
          valueColor="text-blue-700"
        />
        
        {/* This Month Card */}
        <SalesStatsCard
          icon={<CalendarRange className="h-5 w-5 text-green-600" />}
          title="This Month"
          value={thisMonthSales.length}
          description={`Sales for ${format(new Date(), "MMM yyyy")}`}
          bgClass="bg-green-50"
          valueColor="text-green-700"
        />
        
        {/* Total Area Sold Card */}
        <SalesStatsCard
          icon={<SquareIcon className="h-5 w-5 text-amber-600" />}
          title="Total Area Sold"
          value={`${totalAreaSold.toLocaleString()}`}
          description="Square feet coverage"
          bgClass="bg-amber-50"
          valueColor="text-amber-700"
        />
        
        {/* Total Revenue Card */}
        <SalesStatsCard
          icon={<IndianRupee className="h-5 w-5 text-purple-600" />}
          title="Total Revenue"
          value={`₹${totalRevenue.toLocaleString()}`}
          description="Final amount from sales"
          bgClass="bg-purple-50"
          valueColor="text-purple-700"
        />
      </div>
      
      {/* Tabs for filtering */}
      <div className="flex border-b mb-6">
        <button
          onClick={() => setActiveTab("all-sales")}
          className={`px-4 py-2 font-medium text-sm ${activeTab === "all-sales" 
            ? "border-b-2 border-amber-500 text-amber-900" 
            : "text-gray-500 hover:text-gray-700"}`}
        >
          All Sales
        </button>
        <button
          onClick={() => setActiveTab("this-month")}
          className={`px-4 py-2 font-medium text-sm ${activeTab === "this-month" 
            ? "border-b-2 border-amber-500 text-amber-900" 
            : "text-gray-500 hover:text-gray-700"}`}
        >
          This Month
        </button>
        <button
          onClick={() => setActiveTab("this-year")}
          className={`px-4 py-2 font-medium text-sm ${activeTab === "this-year" 
            ? "border-b-2 border-amber-500 text-amber-900" 
            : "text-gray-500 hover:text-gray-700"}`}
        >
          This Year
        </button>
        
        <div className="ml-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setFilterOpen(!filterOpen)}
            className="text-amber-700 border-amber-300 hover:bg-amber-50"
          >
            <Filter className="h-4 w-4 mr-1" />
            Filter
          </Button>
        </div>
      </div>
      
      {/* Sales Table */}
      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="font-medium">Booking Date</TableHead>
              <TableHead className="font-medium">Project</TableHead>
              <TableHead className="hidden md:table-cell font-medium">Sales Executive</TableHead>
              <TableHead className="font-medium">Customer</TableHead>
              <TableHead className="hidden md:table-cell font-medium">Area (sq. ft.)</TableHead>
              <TableHead className="hidden sm:table-cell font-medium">BSP (₹ per sq. ft.)</TableHead>
              <TableHead className="font-medium">Final Amount</TableHead>
              <TableHead className="text-right font-medium">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {!filteredSales || filteredSales.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                  No sales found
                </TableCell>
              </TableRow>
            ) : (
              filteredSales.map((sale: EnhancedSale) => (
                <TableRow key={sale.id}>
                  <TableCell>
                    {format(new Date(sale.bookingDate), "MMM dd, yyyy")}
                  </TableCell>
                  <TableCell>
                    {projectsData?.find((p) => p.id === sale.projectId)?.name || "Unknown"}
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    {user?.fullName || "Unknown"}
                  </TableCell>
                  <TableCell>
                    {sale.customerName || "N/A"}
                    {sale.customerType === "Premium" && (
                      <span className="ml-2 inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        ⭐
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    {parseFloat(sale.areaSold.toString()).toLocaleString()}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    ₹{sale.pricePerSqFt?.toLocaleString() || "N/A"}
                  </TableCell>
                  <TableCell className="font-semibold">
                    ₹{parseFloat(sale.finalAmount || "0").toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handlePaymentClick(sale)}
                      className="h-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50 font-medium"
                    >
                      Payment
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Payment History Dialog */}
      <PaymentHistoryDialog
        open={paymentDialogOpen}
        onClose={handleClosePaymentDialog}
        sale={selectedSale}
        projectsData={projectsData}
      />
    </>
  );
}