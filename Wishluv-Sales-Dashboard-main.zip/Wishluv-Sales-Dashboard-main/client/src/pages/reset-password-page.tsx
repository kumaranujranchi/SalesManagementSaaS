import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Eye, EyeOff, ArrowLeft } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";

// Schema for reset password form
const resetPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(8, "New password must be at least 8 characters"),
  confirmPassword: z.string().min(8, "Confirm password must be at least 8 characters"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

export default function ResetPasswordPage() {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const { toast } = useToast();
  const [_, navigate] = useLocation();

  // Reset password form
  const resetForm = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      email: "",
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  const onResetSubmit = async (data: ResetPasswordFormValues) => {
    setIsResetting(true);
    
    try {
      // Send password reset request to API
      const response = await fetch('/api/reset-password', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
        body: JSON.stringify({
          email: data.email,
          currentPassword: data.currentPassword,
          newPassword: data.newPassword
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to reset password");
      }
      
      toast({
        title: "Password Reset Successfully",
        description: "Your password has been updated.",
      });
      
      // Redirect to login page after successful submission
      navigate("/auth");
    } catch (error) {
      toast({
        title: "Password Reset Failed",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-purple-800 to-pink-700 p-4">
      {/* Reset Password Card with Glassmorphism Effect */}
      <div className="w-full max-w-md mx-auto bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl overflow-hidden border border-white/20">
        <div className="relative">
          {/* Background Design Elements */}
          <div className="absolute -top-24 -left-24 w-64 h-64 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-20 blur-xl"></div>
          <div className="absolute -bottom-32 -right-32 w-80 h-80 bg-gradient-to-tl from-blue-400 to-purple-500 rounded-full opacity-20 blur-xl"></div>
          
          {/* Container with inner padding */}
          <div className="relative px-8 py-10 z-10">
            <Link href="/auth" className="inline-flex items-center text-sm text-white/80 hover:text-orange-300 mb-6">
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back to Login
            </Link>
            
            {/* Title Section */}
            <div className="flex flex-col items-center mb-8">
              <h1 className="text-2xl font-bold text-white mb-1 text-center">Reset Password</h1>
              <div className="w-20 h-1 bg-gradient-to-r from-orange-400 to-red-500 rounded-full mb-6"></div>
              <p className="text-white/80 text-sm text-center max-w-xs">Enter your email and current password to reset your password.</p>
            </div>
            
            {/* Form */}
            <Form {...resetForm}>
              <form onSubmit={resetForm.handleSubmit(onResetSubmit)} className="space-y-5">
                <FormField
                  control={resetForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Email Address</FormLabel>
                      <FormControl>
                        <Input 
                          type="email"
                          placeholder="Enter your email address" 
                          className="bg-white/20 text-white border-0 h-12 placeholder:text-white/50 focus:bg-white/30"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage className="text-red-300" />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={resetForm.control}
                  name="currentPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Current Password</FormLabel>
                      <div className="relative">
                        <FormControl>
                          <Input 
                            type={showCurrentPassword ? "text" : "password"} 
                            placeholder="••••••••••••••" 
                            className="bg-white/20 text-white border-0 h-12 pr-10 placeholder:text-white/50 focus:bg-white/30" 
                            {...field} 
                          />
                        </FormControl>
                        <button
                          type="button"
                          className="absolute inset-y-0 right-0 flex items-center pr-3"
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        >
                          {showCurrentPassword ? (
                            <EyeOff className="h-5 w-5 text-white/70" />
                          ) : (
                            <Eye className="h-5 w-5 text-white/70" />
                          )}
                        </button>
                      </div>
                      <FormMessage className="text-red-300" />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={resetForm.control}
                  name="newPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">New Password</FormLabel>
                      <div className="relative">
                        <FormControl>
                          <Input 
                            type={showNewPassword ? "text" : "password"} 
                            placeholder="••••••••••••••" 
                            className="bg-white/20 text-white border-0 h-12 pr-10 placeholder:text-white/50 focus:bg-white/30" 
                            {...field} 
                          />
                        </FormControl>
                        <button
                          type="button"
                          className="absolute inset-y-0 right-0 flex items-center pr-3"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                        >
                          {showNewPassword ? (
                            <EyeOff className="h-5 w-5 text-white/70" />
                          ) : (
                            <Eye className="h-5 w-5 text-white/70" />
                          )}
                        </button>
                      </div>
                      <FormMessage className="text-red-300" />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={resetForm.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Confirm New Password</FormLabel>
                      <div className="relative">
                        <FormControl>
                          <Input 
                            type={showConfirmPassword ? "text" : "password"} 
                            placeholder="••••••••••••••" 
                            className="bg-white/20 text-white border-0 h-12 pr-10 placeholder:text-white/50 focus:bg-white/30" 
                            {...field} 
                          />
                        </FormControl>
                        <button
                          type="button"
                          className="absolute inset-y-0 right-0 flex items-center pr-3"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        >
                          {showConfirmPassword ? (
                            <EyeOff className="h-5 w-5 text-white/70" />
                          ) : (
                            <Eye className="h-5 w-5 text-white/70" />
                          )}
                        </button>
                      </div>
                      <FormMessage className="text-red-300" />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full py-3 h-12 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-medium transition-all rounded-xl mt-6"
                  disabled={isResetting}
                >
                  {isResetting ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    "Reset Password"
                  )}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}