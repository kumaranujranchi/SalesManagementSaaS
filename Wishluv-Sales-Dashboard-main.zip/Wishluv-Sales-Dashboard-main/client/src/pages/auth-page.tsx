import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Eye, EyeOff, RefreshCw } from "lucide-react";
import { z } from "zod";
import { loginSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

// Extended login schema to include captcha
const loginFormSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
  captcha: z.string().min(1, "Please enter the CAPTCHA text")
});

type LoginFormValues = z.infer<typeof loginFormSchema>;

interface AuthPageProps {
  setIsAuthenticated: (value: boolean) => void;
}

// Function to generate a random captcha code
const generateCaptchaCode = (length: number = 6): string => {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

export default function AuthPage({ setIsAuthenticated }: AuthPageProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [captchaCode, setCaptchaCode] = useState<string>(generateCaptchaCode());
  const [captchaError, setCaptchaError] = useState<string | null>(null);
  const captchaCanvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  // Function to draw captcha on canvas
  const drawCaptcha = () => {
    const canvas = captchaCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Background
    ctx.fillStyle = '#f0f9ff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add noise (lines)
    for (let i = 0; i < 10; i++) {
      ctx.beginPath();
      ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
      ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
      ctx.strokeStyle = `rgba(${Math.random() * 100}, ${Math.random() * 100}, ${Math.random() * 100}, 0.3)`;
      ctx.lineWidth = Math.random() * 2;
      ctx.stroke();
    }

    // Add noise (dots)
    for (let i = 0; i < 100; i++) {
      ctx.fillStyle = `rgba(${Math.random() * 100}, ${Math.random() * 100}, ${Math.random() * 100}, 0.3)`;
      ctx.fillRect(Math.random() * canvas.width, Math.random() * canvas.height, 2, 2);
    }

    // Draw captcha text
    ctx.font = 'bold 24px sans-serif';
    ctx.fillStyle = '#333';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    const chars = captchaCode.split('');
    for (let i = 0; i < chars.length; i++) {
      const x = (canvas.width / chars.length) * i + (canvas.width / chars.length / 2);
      const y = canvas.height / 2 + (Math.random() * 6 - 3);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate((Math.random() * 0.4) - 0.2);
      ctx.fillText(chars[i], 0, 0);
      ctx.restore();
    }
  };

  // Initialize captcha on component mount
  useEffect(() => {
    drawCaptcha();
  }, [captchaCode]);

  // Function to refresh the captcha
  const refreshCaptcha = () => {
    setCaptchaCode(generateCaptchaCode());
    setCaptchaError(null);
    loginForm.setValue('captcha', '');
  };

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      email: "",
      password: "",
      captcha: ""
    },
  });

  const onLoginSubmit = async (data: LoginFormValues) => {
    console.log('Login attempt with:', data);
    
    // Validate CAPTCHA first
    if (data.captcha.toLowerCase() !== captchaCode.toLowerCase()) {
      setCaptchaError('Incorrect CAPTCHA, please try again');
      refreshCaptcha();
      return;
    }
    
    setIsLoggingIn(true);
    setCaptchaError(null);
    
    try {
      // Add a small delay to mimic password processing
      await new Promise(resolve => setTimeout(resolve, 500));
      
      console.log('Sending login request with credentials:', {
        email: data.email,
        passwordLength: data.password.length
      });
      
      // Remove captcha from the request payload sent to server
      const { captcha, ...loginCredentials } = data;
      
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
        body: JSON.stringify(loginCredentials),
        credentials: 'include'
      });
      
      console.log('Login response status:', response.status);
      
      if (response.ok) {
        const userData = await response.json();
        console.log('Login successful, user data:', userData);
        
        toast({
          title: "Login successful",
          description: `Welcome back, ${userData.fullName || userData.email}!`,
        });
        
        // Force reload to ensure proper state refresh
        window.location.href = '/';
      } else {
        let errorMessage = "Invalid email or password. Please try again.";
        
        try {
          const errorResponse = await response.json();
          if (errorResponse && errorResponse.message) {
            errorMessage = errorResponse.message;
          }
        } catch (e) {
          // If we can't parse the JSON, use the default error message
          console.error('Error parsing error response:', e);
        }
        
        console.error('Login failed:', errorMessage);
        
        toast({
          title: "Login failed",
          description: errorMessage,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Login error:', error);
      
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-purple-800 to-pink-700 p-4">
      {/* Login Card with Glassmorphism Effect */}
      <div className="w-full max-w-md mx-auto bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl overflow-hidden border border-white/20">
        <div className="relative">
          {/* Background Design Elements */}
          <div className="absolute -top-24 -left-24 w-64 h-64 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-20 blur-xl"></div>
          <div className="absolute -bottom-32 -right-32 w-80 h-80 bg-gradient-to-tl from-blue-400 to-purple-500 rounded-full opacity-20 blur-xl"></div>
          
          {/* Container with inner padding */}
          <div className="relative px-8 py-10 z-10">
            {/* Logo and Title Section */}
            <div className="flex flex-col items-center mb-8">
              <div className="bg-white/90 p-4 rounded-2xl shadow-lg mb-6">
                <img src="https://imagizer.imageshack.com/img924/9256/E2qQnT.png" alt="Wishluv Logo" className="h-16" />
              </div>
              <h1 className="text-2xl font-bold text-white mb-1 text-center">Wishluv Buildcon SalesPro</h1>
              <div className="w-20 h-1 bg-gradient-to-r from-orange-400 to-red-500 rounded-full mb-6"></div>
              <p className="text-white/80 text-sm text-center max-w-xs">Welcome back to SalesTrack, please log in to continue.</p>
            </div>
            
            {/* Login Form */}
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-5">
                <FormField
                  control={loginForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Email Address</FormLabel>
                      <FormControl>
                        <Input 
                          type="email"
                          placeholder="Enter your email address" 
                          className="bg-white/20 text-white border-0 h-12 placeholder:text-white/50 focus:bg-white/30"
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Password</FormLabel>
                      <div className="relative">
                        <FormControl>
                          <Input 
                            type={showPassword ? "text" : "password"} 
                            placeholder="••••••••••••••" 
                            className="bg-white/20 text-white border-0 h-12 pr-10 placeholder:text-white/50 focus:bg-white/30" 
                            {...field} 
                          />
                        </FormControl>
                        <button
                          type="button"
                          className="absolute inset-y-0 right-0 flex items-center pr-3"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <EyeOff className="h-5 w-5 text-white/70" />
                          ) : (
                            <Eye className="h-5 w-5 text-white/70" />
                          )}
                        </button>
                      </div>
                    </FormItem>
                  )}
                />
                
                {/* CAPTCHA Section */}
                <div className="space-y-2">
                  <FormLabel className="text-white">CAPTCHA Verification</FormLabel>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <div className="flex justify-between items-center mb-3">
                      <div className="flex-1">
                        <canvas 
                          ref={captchaCanvasRef} 
                          width="200" 
                          height="60" 
                          className="bg-white/90 rounded-lg shadow-sm"
                        />
                        <p className="text-xs text-white/80 mt-1">Type the text shown above</p>
                      </div>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm" 
                        onClick={refreshCaptcha}
                        className="flex items-center gap-1 ml-3 bg-white/30 text-white border-0 hover:bg-white/40"
                      >
                        <RefreshCw className="h-3 w-3" />
                        Refresh
                      </Button>
                    </div>
                    <FormField
                      control={loginForm.control}
                      name="captcha"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input 
                              placeholder="Enter CAPTCHA text" 
                              className="h-10 bg-white/30 border-0 text-white placeholder:text-white/50"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage className="text-red-300" />
                        </FormItem>
                      )}
                    />
                    {captchaError && (
                      <p className="text-sm font-medium text-red-300 mt-1">{captchaError}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="remember-me" className="border-white/50 text-orange-500" />
                    <label htmlFor="remember-me" className="text-sm text-white/80">
                      Remember Me
                    </label>
                  </div>
                  <Link href="/reset-password" className="text-sm text-white/80 hover:text-orange-300">
                    Reset Password
                  </Link>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full py-3 h-12 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-medium transition-all rounded-xl"
                  disabled={isLoggingIn}
                >
                  {isLoggingIn ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    "Log In"
                  )}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}
