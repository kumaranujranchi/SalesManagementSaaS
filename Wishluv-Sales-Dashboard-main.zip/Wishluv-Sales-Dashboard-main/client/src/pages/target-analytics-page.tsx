import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear } from "date-fns";
import { Target, User, Sales } from "@shared/schema";

// Helper for safely converting areaSold to number
const safeAreaToNumber = (area: string | number | null | undefined): number => {
  if (area === null || area === undefined) return 0;
  if (typeof area === 'number') return area;
  return parseFloat(area) || 0;
};
import { 
  Loader2, 
  Target as TargetIcon, 
  Calendar,
  Users,
  Filter,
  ArrowLeft,
  TrendingUp,
  ChevronDown,
  BarChart,
  PieChart,
  LineChart,
  Trophy,
  CheckCircle,
  BarChart3
} from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  AreaChart,
  BarChart as TremorBarChart,
  DonutChart
} from "@tremor/react";

type DataPeriod = "monthly" | "yearly" | "lifetime";
type FilterType = {
  salesExecutiveId: number | null;
  managerId: number | null;
  projectId: number | null;
  period: DataPeriod;
  dateRange: {
    startDate: Date;
    endDate: Date;
  };
};

const TargetAnalyticsPage = () => {
  // Get current user and role from auth context
  const { user } = useAuth();
  const userRole = user?.role || ""; // Access role as a dynamic variable
  const userDesignation = user?.designation || ""; // Access designation as a dynamic variable
  
  // User ID for filtering based on the logged-in user
  const currentUserId = user?.id || null;
  
  // Set initial state based on user role
  const [tab, setTab] = useState<string>(
    userRole === "admin" || userDesignation === "Team Leader" ? "team" : "individual"
  );
  const [period, setPeriod] = useState<DataPeriod>("monthly");
  const [filterOpen, setFilterOpen] = useState(true); // Start with filters open
  
  // Initialize filters potentially based on user role/designation
  const [filters, setFilters] = useState<FilterType>({
    // If user is a sales executive, pre-filter to show only their data
    salesExecutiveId: userDesignation === "Sales Executive" && currentUserId ? currentUserId : null,
    // If user is a team leader, pre-filter to show only their team
    managerId: userDesignation === "Team Leader" && currentUserId ? currentUserId : null,
    projectId: null,
    period: "monthly",
    dateRange: {
      startDate: startOfMonth(new Date()),
      endDate: endOfMonth(new Date())
    }
  });

  // Fetch all targets
  const { 
    data: targets, 
    isLoading: isLoadingTargets 
  } = useQuery<Target[]>({
    queryKey: ["/api/targets"],
    queryFn: async () => {
      const res = await fetch('/api/targets');
      if (!res.ok) throw new Error("Failed to fetch targets");
      return res.json();
    }
  });

  // Hard-code the specific team members data to ensure exactly these three users
  const {
    data: users,
    isLoading: isLoadingUsers
  } = useQuery<User[]>({
    queryKey: ["/api/users-sales"],
    queryFn: async () => {
      // Fetch all users just to ensure we have valid IDs and other properties
      const res = await fetch('/api/users');
      if (!res.ok) throw new Error("Failed to fetch users");
      const allUsers = await res.json();
      
      // STRICTLY include ONLY these specific team leaders by name - absolutely no exceptions
      const specificTeamMemberNames = ["Awinash Mishra", "Manish Verma", "Kaustuv Singh"];
      
      // Filter to only get the exact three team members specified
      const strictlyFilteredUsers = allUsers.filter((user: User) => 
        specificTeamMemberNames.includes(user.fullName)
      );
      
      // If we didn't find all three users, log an error but return what we found
      if (strictlyFilteredUsers.length !== 3) {
        console.error("Warning: Not all specified team members were found in the database");
      }
      
      return strictlyFilteredUsers;
    }
  });

  // Fetch managers - specifically we only need the manager of the three team members
  const {
    data: managers,
    isLoading: isLoadingManagers
  } = useQuery<User[]>({
    queryKey: ["/api/users-managers"],
    queryFn: async () => {
      // First find out who is the reporting manager of our team members
      const managerIds = users?.map(user => user.reportingManagerId).filter(Boolean) || [];
      
      if (managerIds.length === 0) {
        // If we can't determine manager yet, fetch all Team Leaders as fallback
        const res = await fetch('/api/users?designation=Team Leader&department=Sales');
        if (!res.ok) throw new Error("Failed to fetch managers");
        return res.json();
      } else {
        // Otherwise, just get the specific managers for our team members
        const uniqueManagerIds = Array.from(new Set(managerIds));
        const res = await fetch('/api/users');
        if (!res.ok) throw new Error("Failed to fetch managers");
        const allUsers = await res.json();
        
        return allUsers.filter((user: User) => uniqueManagerIds.includes(user.id));
      }
    },
    enabled: !!users // Only run this query when users data is available
  });

  // Fetch all projects
  const {
    data: projects,
    isLoading: isLoadingProjects
  } = useQuery<any[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const res = await fetch('/api/projects');
      if (!res.ok) throw new Error("Failed to fetch projects");
      return res.json();
    }
  });

  // Fetch all sales data
  const {
    data: salesData,
    isLoading: isLoadingSales
  } = useQuery<Sales[]>({
    queryKey: ["/api/sales"],
    queryFn: async () => {
      const res = await fetch('/api/sales');
      if (!res.ok) throw new Error("Failed to fetch sales data");
      return res.json();
    }
  });

  useEffect(() => {
    // Update date range when period changes
    switch (period) {
      case "monthly":
        setFilters(prev => ({
          ...prev,
          period,
          dateRange: {
            startDate: startOfMonth(new Date()),
            endDate: endOfMonth(new Date())
          }
        }));
        break;
      case "yearly":
        setFilters(prev => ({
          ...prev,
          period,
          dateRange: {
            startDate: startOfYear(new Date()),
            endDate: endOfYear(new Date())
          }
        }));
        break;
      case "lifetime":
        setFilters(prev => ({
          ...prev,
          period,
          dateRange: {
            startDate: new Date(2020, 0, 1), // Far back enough to cover all data
            endDate: new Date(2030, 11, 31) // Far forward enough to cover all data
          }
        }));
        break;
    }
  }, [period]);

  // Filter and aggregate data for team performance with proper team structure
  const getTeamPerformanceData = () => {
    if (!targets || !salesData || !users) return [];

    // Function to calculate achievement for a specific user ID
    const calculateUserAchievement = (userId: number): number => {
      // Get user's sales within date range and project filter
      const userSales = salesData.filter(s => {
        const saleDate = new Date(s.bookingDate);
        return s.salesExecutiveId === userId &&
          saleDate >= filters.dateRange.startDate &&
          saleDate <= filters.dateRange.endDate &&
          (!filters.projectId || s.projectId === filters.projectId);
      });
      
      // Sum up the area sold
      let achieved = 0;
      userSales.forEach(sale => {
        achieved += safeAreaToNumber(sale.areaSold);
      });
      
      return achieved;
    };
    
    // Function to calculate target for a specific user ID
    const calculateUserTarget = (userId: number): number => {
      // Get user's targets within date range
      const userTargets = targets.filter(t => {
        const targetDate = new Date(t.year, t.month - 1, 1);
        return t.userId === userId &&
          targetDate >= filters.dateRange.startDate &&
          targetDate <= filters.dateRange.endDate;
      });
      
      // Sum up targets
      let targetSum = 0;
      userTargets.forEach(t => {
        targetSum += t.targetValue;
      });
      
      return targetSum;
    };
    
    // Hard-coded team structure based on requirements
    const teamStructure: Record<number, number[]> = {
      // Manish Verma leads Shalu Singh, Gaurav Singa, Aditya Raj
      9: [10, 11, 12],
      // Awinash Mishra leads Shubham Kumar, Russell Knight, Om Renuka
      13: [14, 15, 16],
      // Kaustuv Singh leads Vikash Kumar, Rahul Ranjan, Taniya Kumari, Sahil Kumar
      17: [18, 19, 20, 21]
    };
    
    // Get team leaders (hard-coded IDs as specified)
    const teamLeaderIds = Object.keys(teamStructure).map(Number);
    
    // Get team leaders from user data
    const teamLeaders = users.filter(u => teamLeaderIds.includes(u.id));
    
    // Result structure to hold all team data
    const teamData: Record<number, {
      managerId: number;
      managerName: string;
      totalTarget: number;
      totalAchieved: number;
      percentageAchieved: number;
      teamMembers: Array<{
        userId: number;
        userName: string;
        target: number;
        achieved: number;
        percentageAchieved: number;
      }>;
    }> = {};
    
    // Filter team leaders based on selection
    const relevantTeamLeaders = filters.managerId 
      ? teamLeaders.filter(leader => leader.id === filters.managerId)
      : teamLeaders;
    
    // Process each team leader
    relevantTeamLeaders.forEach(leader => {
      // Initialize team data structure
      teamData[leader.id] = {
        managerId: leader.id,
        managerName: leader.fullName,
        totalTarget: 0,
        totalAchieved: 0,
        percentageAchieved: 0,
        teamMembers: []
      };
      
      // Get leader's personal target and achievement
      const leaderTarget = calculateUserTarget(leader.id);
      const leaderAchievement = calculateUserAchievement(leader.id);
      
      // Calculate percentage
      const leaderPercentage = leaderTarget > 0 
        ? Math.round((leaderAchievement / leaderTarget) * 100) 
        : 0;
      
      // Add leader as first team member (their personal contribution)
      teamData[leader.id].teamMembers.push({
        userId: leader.id,
        userName: `${leader.fullName} (Personal)`,
        target: leaderTarget,
        achieved: leaderAchievement,
        percentageAchieved: leaderPercentage
      });
      
      // Initialize team totals with leader's values
      let totalTeamTarget = leaderTarget;
      let totalTeamAchievement = leaderAchievement;
      
      // Get team member IDs for this leader
      const memberIds = teamStructure[leader.id] || [];
      
      // For each team member
      memberIds.forEach(memberId => {
        // Find the user data
        const memberUser = users.find(u => u.id === memberId);
        if (!memberUser) return; // Skip if user not found
        
        // Calculate target and achievement
        const memberTarget = calculateUserTarget(memberId);
        const memberAchievement = calculateUserAchievement(memberId);
        
        // Calculate percentage
        const memberPercentage = memberTarget > 0 
          ? Math.round((memberAchievement / memberTarget) * 100) 
          : 0;
        
        // Add to team totals
        totalTeamTarget += memberTarget;
        totalTeamAchievement += memberAchievement;
        
        // Add to team members list
        teamData[leader.id].teamMembers.push({
          userId: memberId,
          userName: memberUser.fullName,
          target: memberTarget,
          achieved: memberAchievement,
          percentageAchieved: memberPercentage
        });
      });
      
      // Update team totals
      teamData[leader.id].totalTarget = totalTeamTarget;
      teamData[leader.id].totalAchieved = totalTeamAchievement;
      
      // Calculate overall percentage
      teamData[leader.id].percentageAchieved = totalTeamTarget > 0
        ? Math.round((totalTeamAchievement / totalTeamTarget) * 100)
        : 0;
      
      // Log for debugging
      console.log(`Team data for ${leader.fullName}:`, {
        managerId: leader.id,
        managerName: leader.fullName,
        totalTarget: totalTeamTarget,
        totalAchieved: totalTeamAchievement,
        percentageAchieved: teamData[leader.id].percentageAchieved,
        memberCount: teamData[leader.id].teamMembers.length - 1 // Excluding leader
      });
    });
    
    return Object.values(teamData);
  };

  // Filter and process data for individual performance
  const getIndividualPerformanceData = () => {
    if (!targets || !salesData || !users) return [];

    // Get relevant sales executives based on filters, excluding System Admins
    const executivesToShow = users.filter(u => {
      // Basic filter: only include Sales department members who aren't System Admins
      if (u.department !== "Sales" || 
          u.designation === "Super Admin" || 
          u.designation === "System Admin") {
        return false;
      }
      
      // Apply specific filters
      if (filters.salesExecutiveId) {
        return u.id === filters.salesExecutiveId;
      }
      
      if (filters.managerId) {
        // Include both the manager and their team members
        return u.id === filters.managerId || u.reportingManagerId === filters.managerId;
      }
      
      return true;
    });

    return executivesToShow.map(exec => {
      // Get targets for this executive within date range
      const execTargets = targets.filter(t => {
        const targetDate = new Date(t.year, t.month - 1, 1);
        return t.userId === exec.id &&
          targetDate >= filters.dateRange.startDate &&
          targetDate <= filters.dateRange.endDate;
      });

      // Sum up targets
      let execTargetSum = 0;
      execTargets.forEach(t => {
        execTargetSum += t.targetValue;
      });

      // Get sales achievements
      let execAchievedSum = 0;
      const execSales = salesData.filter(s => {
        const saleDate = new Date(s.bookingDate);
        return s.salesExecutiveId === exec.id &&
          saleDate >= filters.dateRange.startDate &&
          saleDate <= filters.dateRange.endDate &&
          (!filters.projectId || s.projectId === filters.projectId);
      });

      execSales.forEach(sale => {
        execAchievedSum += safeAreaToNumber(sale.areaSold);
      });

      // Calculate percentage achieved
      const percentageAchieved = execTargetSum > 0 
        ? Math.round((execAchievedSum / execTargetSum) * 100) 
        : 0;

      // Calculate gap
      const gap = execTargetSum > execAchievedSum 
        ? execTargetSum - execAchievedSum 
        : 0;
        
      // Determine performance status
      let performanceStatus = "On Track";
      if (percentageAchieved >= 100) {
        performanceStatus = "Achieved";
      } else if (percentageAchieved < 50) {
        performanceStatus = "Behind";
      }

      return {
        userId: exec.id,
        userName: exec.fullName,
        designation: exec.designation,
        target: execTargetSum,
        achieved: execAchievedSum,
        percentageAchieved,
        gap,
        hasTarget: execTargetSum > 0,
        isManager: exec.designation === "Team Leader" || exec.designation === "Sales Head",
        performanceStatus,
        salesCount: execSales.length,
        manager: users.find(u => u.id === exec.reportingManagerId)?.fullName || "No Manager"
      };
    }).sort((a, b) => {
      // Sort by percentage achievement (descending)
      return b.percentageAchieved - a.percentageAchieved;
    });
  };

  // Format currency for display
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-IN').format(num);
  };

  // Get team performance data for charts
  const teamPerformanceData = getTeamPerformanceData();
  
  // Get individual performance data for tables
  const individualPerformanceData = getIndividualPerformanceData();

  // Prepare data for charts
  const teamBarChartData = teamPerformanceData.map(team => ({
    name: team.managerName,
    target: team.totalTarget,
    achieved: team.totalAchieved
  }));

  // Monthly performance chart data
  const getMonthlyPerformanceData = () => {
    if (!targets || !salesData) return [];
    
    const monthlyData: Record<string, { month: string, target: number, achieved: number }> = {};
    
    // Process all monthly targets within the year
    const year = new Date().getFullYear();
    for (let month = 0; month < 12; month++) {
      const monthStr = format(new Date(year, month, 1), 'MMM');
      monthlyData[monthStr] = { month: monthStr, target: 0, achieved: 0 };
      
      // Sum targets for this month
      const monthlyTargets = targets.filter(t => t.year === year && t.month === month + 1);
      monthlyTargets.forEach(t => {
        monthlyData[monthStr].target += t.targetValue;
      });
      
      // Sum achievements for this month
      const monthlyAchievements = salesData.filter(s => {
        const saleDate = new Date(s.bookingDate);
        return saleDate.getFullYear() === year && saleDate.getMonth() === month;
      });
      monthlyAchievements.forEach(s => {
        monthlyData[monthStr].achieved += safeAreaToNumber(s.areaSold);
      });
    }
    
    return Object.values(monthlyData);
  };

  const monthlyPerformanceData = getMonthlyPerformanceData();

  // Render loading state
  if (isLoadingTargets || isLoadingUsers || isLoadingManagers || isLoadingProjects || isLoadingSales) {
    return (
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center h-screen">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div className="flex items-center gap-2 mb-4 md:mb-0">
          <BarChart className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Detailed Target Analytics</h1>
            <p className="text-muted-foreground">Comprehensive analysis of targets and achievements</p>
          </div>
        </div>
        <Link href="/targets">
          <Button variant="outline" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Target Management
          </Button>
        </Link>
      </div>

      {/* Filter controls with button-based interface */}
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle>Analytics Filters</CardTitle>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setFilterOpen(!filterOpen)}
              className="flex items-center gap-2"
            >
              <Filter className="h-4 w-4" />
              {filterOpen ? "Hide Filters" : "Show Filters"}
            </Button>
          </div>
          <CardDescription>Customize the data view based on your requirements</CardDescription>
        </CardHeader>
        
        {filterOpen && (
          <CardContent>
            <div className="space-y-4">
              {/* Time Period Buttons */}
              <div>
                <h3 className="text-sm font-medium mb-2">Time Period</h3>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={period === "monthly" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setPeriod("monthly")}
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Monthly
                  </Button>
                  <Button
                    variant={period === "yearly" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setPeriod("yearly")}
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Yearly
                  </Button>
                  <Button
                    variant={period === "lifetime" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setPeriod("lifetime")}
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Lifetime
                  </Button>
                </div>
              </div>
              
              {/* Team Leader Buttons - only shown for admin users */}
              {(userRole === "admin" || userDesignation === "Super Admin" || userDesignation === "System Admin") && (
                <div>
                  <h3 className="text-sm font-medium mb-2">Team Leader</h3>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={filters.managerId === null ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilters({
                        ...filters,
                        managerId: null
                      })}
                    >
                      <Users className="h-4 w-4 mr-2" />
                      All Teams
                    </Button>
                    
                    {/* Only include the three specific team leaders */}
                    {managers?.filter(manager => 
                      ["Manish Verma", "Kaustuv Singh", "Awinash Mishra"].includes(manager.fullName)
                    ).map(manager => (
                      <Button
                        key={manager.id}
                        variant={filters.managerId === manager.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setFilters({
                          ...filters,
                          managerId: manager.id,
                          salesExecutiveId: null // Reset sales executive filter when team changes
                        })}
                      >
                        {manager.fullName}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Project Buttons */}
              <div>
                <h3 className="text-sm font-medium mb-2">Project</h3>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={filters.projectId === null ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilters({
                      ...filters,
                      projectId: null
                    })}
                  >
                    All Projects
                  </Button>
                  
                  {projects?.slice(0, 4).map(project => (
                    <Button
                      key={project.id}
                      variant={filters.projectId === project.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilters({
                        ...filters,
                        projectId: project.id
                      })}
                    >
                      {project.name}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Active Filters Summary */}
            <div className="mt-4 text-sm text-muted-foreground bg-muted/30 p-3 rounded-md">
              <div className="font-medium mb-1">
                {period === "monthly" ? (
                  <span>Showing data for: Current Month ({format(new Date(), 'MMMM yyyy')})</span>
                ) : period === "yearly" ? (
                  <span>Showing data for: Year {new Date().getFullYear()}</span>
                ) : (
                  <span>Showing data for: All Time</span>
                )}
              </div>
              
              {/* Active filters as badges */}
              <div className="flex flex-wrap gap-2 mt-2">
                {filters.managerId && managers?.find(m => m.id === filters.managerId) && (
                  <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-xs flex items-center">
                    Team Leader: {managers.find(m => m.id === filters.managerId)?.fullName}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 ml-1 p-0"
                      onClick={() => setFilters({...filters, managerId: null})}
                    >
                      <span className="sr-only">Remove filter</span>
                      ×
                    </Button>
                  </div>
                )}
                
                {filters.projectId && projects?.find(p => p.id === filters.projectId) && (
                  <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-xs flex items-center">
                    Project: {projects.find(p => p.id === filters.projectId)?.name}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 ml-1 p-0"
                      onClick={() => setFilters({...filters, projectId: null})}
                    >
                      <span className="sr-only">Remove filter</span>
                      ×
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        )}
      </Card>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Target</CardTitle>
            <CardDescription>
              {period === "monthly" ? `${format(new Date(), 'MMMM yyyy')}` : period === "yearly" ? `Year ${new Date().getFullYear()}` : "Lifetime"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {formatNumber(individualPerformanceData.reduce((sum, item) => sum + item.target, 0))} sqft
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {individualPerformanceData.filter(item => item.target > 0).length} executives with targets
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Achievement</CardTitle>
            <CardDescription>
              {period === "monthly" ? `${format(new Date(), 'MMMM yyyy')}` : period === "yearly" ? `Year ${new Date().getFullYear()}` : "Lifetime"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {formatNumber(individualPerformanceData.reduce((sum, item) => sum + item.achieved, 0))} sqft
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {individualPerformanceData.filter(item => item.achieved > 0).length} executives with sales
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Overall Progress</CardTitle>
            <CardDescription>
              Achievement percentage against targets
            </CardDescription>
          </CardHeader>
          <CardContent>
            {(() => {
              const totalTarget = individualPerformanceData.reduce((sum, item) => sum + item.target, 0);
              const totalAchieved = individualPerformanceData.reduce((sum, item) => sum + item.achieved, 0);
              const percentage = totalTarget === 0 ? 0 : Math.round((totalAchieved / totalTarget) * 100);
              
              return (
                <>
                  <div className="text-3xl font-bold">
                    {percentage}%
                  </div>
                  <Progress 
                    value={percentage > 100 ? 100 : percentage} 
                    className="h-2 mt-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {percentage >= 100 ? 
                      'Target achieved!' : 
                      `${formatNumber(totalTarget - totalAchieved)} sqft remaining`
                    }
                  </p>
                </>
              );
            })()}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Top Performer</CardTitle>
            <CardDescription>
              Highest achievement rate
            </CardDescription>
          </CardHeader>
          <CardContent>
            {(() => {
              const topPerformer = [...individualPerformanceData]
                .filter(exec => exec.target > 0)
                .sort((a, b) => b.percentageAchieved - a.percentageAchieved)[0];
              
              return topPerformer ? (
                <>
                  <div className="text-3xl font-bold">
                    {topPerformer.percentageAchieved}%
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 truncate max-w-40">
                    {topPerformer.userName}
                  </p>
                  <div className="flex items-center gap-1 mt-2 text-blue-500">
                    <div className="h-4 w-4 bg-blue-500 rounded-full flex items-center justify-center text-[10px] text-white font-bold">1</div>
                    <span className="text-xs font-medium">{formatNumber(topPerformer.achieved)} sqft sold</span>
                  </div>
                </>
              ) : (
                <div className="text-3xl font-bold">N/A</div>
              );
            })()}
          </CardContent>
        </Card>
      </div>
      
      {/* Main content tabs - conditionally rendered based on user role */}
      <Tabs defaultValue={tab} value={tab} onValueChange={setTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          {/* Show Team tab only for admin or team leaders */}
          <TabsTrigger 
            value="team" 
            disabled={userRole !== "admin" && 
                     userDesignation !== "Team Leader" && 
                     userDesignation !== "Sales Head"}
          >
            Team Performance
          </TabsTrigger>
          <TabsTrigger value="individual">Individual Performance</TabsTrigger>
        </TabsList>
        
        <TabsContent value="team" className="space-y-6">
          {/* Monthly team performance chart */}
          <Card>
            <CardHeader>
              <CardTitle>Monthly Team Performance</CardTitle>
              <CardDescription>Target vs. Achievement breakdown by month</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <AreaChart
                className="h-72"
                data={monthlyPerformanceData}
                index="month"
                categories={["target", "achieved"]}
                colors={["indigo", "cyan"]}
                valueFormatter={(number) => `${formatNumber(number)} sqft`}
              />
            </CardContent>
          </Card>
          
          {/* Team performance by manager */}
          <Card>
            <CardHeader>
              <CardTitle>Team Performance by Manager</CardTitle>
              <CardDescription>Comparative analysis of team achievements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {teamPerformanceData.length > 0 ? (
                  teamPerformanceData.map(team => (
                    <div key={team.managerId} className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">{team.managerName}'s Team</h3>
                        <span className="text-sm text-muted-foreground">
                          Team Size: {team.teamMembers.length} executives
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div className="bg-muted/30 p-4 rounded-lg">
                          <div className="text-sm text-muted-foreground">Total Target</div>
                          <div className="text-xl font-semibold">{formatNumber(team.totalTarget)} sqft</div>
                        </div>
                        <div className="bg-muted/30 p-4 rounded-lg">
                          <div className="text-sm text-muted-foreground">Total Achievement</div>
                          <div className="text-xl font-semibold">{formatNumber(team.totalAchieved)} sqft</div>
                        </div>
                        <div className="bg-muted/30 p-4 rounded-lg">
                          <div className="text-sm text-muted-foreground">Progress</div>
                          <div className="text-xl font-semibold">{team.percentageAchieved}%</div>
                          <Progress className="h-2 mt-2" value={team.percentageAchieved} />
                        </div>
                      </div>
                      
                      <div className="border rounded-md">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Executive</TableHead>
                              <TableHead className="text-right">Target (sqft)</TableHead>
                              <TableHead className="text-right">Achievement (sqft)</TableHead>
                              <TableHead className="text-right">Progress</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {team.teamMembers.map(member => (
                              <TableRow key={member.userId}>
                                <TableCell>{member.userName}</TableCell>
                                <TableCell className="text-right">
                                  {member.target ? formatNumber(member.target) : "No target assigned"}
                                </TableCell>
                                <TableCell className="text-right">{formatNumber(member.achieved)}</TableCell>
                                <TableCell className="text-right">
                                  <div className="flex items-center justify-end">
                                    <span className="mr-2">
                                      {member.target ? `${member.percentageAchieved}%` : "N/A"}
                                    </span>
                                    {member.target > 0 && (
                                      <div className="w-16 bg-muted rounded-full h-2 overflow-hidden">
                                        <div 
                                          className={`h-full ${member.percentageAchieved >= 100 ? 'bg-success' : 'bg-primary'}`}
                                          style={{ width: `${Math.min(member.percentageAchieved, 100)}%` }}
                                        />
                                      </div>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 mx-auto text-muted-foreground opacity-30" />
                    <p className="mt-2 text-muted-foreground">No team data available for the selected filters</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="individual" className="space-y-6">
          {/* Individual performance charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Target vs Achievement</CardTitle>
                <CardDescription>Distribution of targets and achievements</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <DonutChart
                  className="h-72"
                  data={[
                    { name: "Target Met", value: individualPerformanceData.filter(i => i.percentageAchieved >= 100).length },
                    { name: "In Progress", value: individualPerformanceData.filter(i => i.percentageAchieved > 0 && i.percentageAchieved < 100).length },
                    { name: "Not Started", value: individualPerformanceData.filter(i => i.percentageAchieved === 0 && i.hasTarget).length },
                    { name: "No Target", value: individualPerformanceData.filter(i => !i.hasTarget).length }
                  ]}
                  index="name"
                  category="value"
                  valueFormatter={(number) => `${number} executives`}
                  colors={["emerald", "blue", "amber", "slate"]}
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Top Performers</CardTitle>
                <CardDescription>Executives with highest achievement percentage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {individualPerformanceData
                    .filter(i => i.hasTarget)
                    .sort((a, b) => b.percentageAchieved - a.percentageAchieved)
                    .slice(0, 5)
                    .map((performer, index) => (
                      <div key={performer.userId} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground mr-2">
                              {index + 1}
                            </div>
                            <div>
                              <p className="font-medium">{performer.userName}</p>
                              <p className="text-sm text-muted-foreground">
                                {performer.achieved} / {performer.target} sqft
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-xl">
                              {performer.percentageAchieved}%
                            </p>
                          </div>
                        </div>
                        <Progress 
                          value={Math.min(performer.percentageAchieved, 100)} 
                          className="h-2"
                          color={performer.percentageAchieved >= 100 ? "bg-success" : ""}
                        />
                      </div>
                    ))
                  }
                  
                  {individualPerformanceData.filter(i => i.hasTarget).length === 0 && (
                    <div className="text-center py-8">
                      <Users className="h-12 w-12 mx-auto text-muted-foreground opacity-30" />
                      <p className="mt-2 text-muted-foreground">No data available for the selected filters</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Detailed individual performance table */}
          <Card>
            <CardHeader>
              <CardTitle>Detailed Performance Analysis</CardTitle>
              <CardDescription>Complete breakdown of individual performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Executive</TableHead>
                      <TableHead>Manager</TableHead>
                      <TableHead className="text-right">Target (sqft)</TableHead>
                      <TableHead className="text-right">Achievement (sqft)</TableHead>
                      <TableHead className="text-right">Percentage</TableHead>
                      <TableHead className="text-right">Gap/Surplus</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {individualPerformanceData.map(performer => (
                      <TableRow key={performer.userId}>
                        <TableCell className="font-medium">{performer.userName}</TableCell>
                        <TableCell>{performer.manager}</TableCell>
                        <TableCell className="text-right">
                          {performer.hasTarget ? formatNumber(performer.target) : "No target assigned"}
                        </TableCell>
                        <TableCell className="text-right">{formatNumber(performer.achieved)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end">
                            <span className={`font-medium ${performer.percentageAchieved >= 100 ? 'text-success' : performer.percentageAchieved > 0 ? 'text-primary' : 'text-muted-foreground'}`}>
                              {performer.hasTarget ? `${performer.percentageAchieved}%` : "N/A"}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          {performer.hasTarget ? (
                            performer.gap > 0 ? (
                              <span className="text-destructive">-{formatNumber(performer.gap)}</span>
                            ) : (
                              <span className="text-success">+{formatNumber(performer.achieved - performer.target)}</span>
                            )
                          ) : (
                            "N/A"
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TargetAnalyticsPage;