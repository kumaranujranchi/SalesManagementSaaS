import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableFooter, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { ArrowUpIcon, ArrowDownIcon, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getMonthName } from "@/lib/date-utils";

export default function TargetAchievementPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("monthly");
  
  // Only fetch data if user is in Sales department
  const { data: achievement, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ["/api/targets/achievement", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      // Add a timestamp parameter to avoid browser caching
      const timestamp = new Date().getTime();
      const res = await fetch(`/api/targets/achievement/${user.id}?fresh=true&ts=${timestamp}`);
      
      if (!res.ok) {
        throw new Error("Failed to fetch achievement data");
      }
      return res.json();
    },
    enabled: !!user?.id && user?.department === "Sales",
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 5000 // Consider data fresh for 5 seconds
  });
  
  // Periodically refetch data to ensure we have the latest achievements
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 30000); // Refresh every 30 seconds
    
    return () => clearInterval(interval);
  }, [refetch]);
  
  // Handle errors from the query
  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch achievement data",
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  if (!user || user.department !== "Sales") {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Target vs Achievement</CardTitle>
            <CardDescription>
              This feature is only available for Sales department members.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }
  
  // Loading state
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Target vs Achievement</CardTitle>
            <CardDescription>Loading your performance data...</CardDescription>
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[400px] w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // No data state
  if (!achievement || !achievement.monthlyBreakdown || achievement.monthlyBreakdown.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Target vs Achievement</CardTitle>
            <CardDescription>No target or achievement data available.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Please contact your manager to set your monthly targets.</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Sort monthly breakdown by date (January to December)
  const sortedMonthlyData = [...achievement.monthlyBreakdown].sort((a, b) => {
    if (a.year !== b.year) return a.year - b.year;
    return a.month - b.month;
  });
  
  // Calculate current year data only
  const currentYear = new Date().getFullYear();
  const currentYearData = sortedMonthlyData.filter(
    (month) => month.year === currentYear
  );
  
  // Calculate if we are ahead or behind target
  const gap = achievement.totalAchievement - achievement.totalTarget;
  const isAhead = gap >= 0;
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Target vs Achievement</h1>
          <p className="text-muted-foreground">
            Track your sales performance against monthly targets
          </p>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => refetch()}
          disabled={isFetching}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Year-to-Date Summary</CardTitle>
          <CardDescription>
            {currentYear} Summary - from January to present
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-primary/10 p-4 rounded-lg">
              <p className="text-sm font-medium mb-1">Total Target</p>
              <p className="text-2xl font-bold">{achievement.totalTarget.toLocaleString()} sq.ft.</p>
            </div>
            <div className="bg-primary/10 p-4 rounded-lg">
              <p className="text-sm font-medium mb-1">Total Achievement</p>
              <p className="text-2xl font-bold">{achievement.totalAchievement.toLocaleString()} sq.ft.</p>
            </div>
            <div className={`${isAhead ? 'bg-green-100' : 'bg-red-100'} p-4 rounded-lg flex items-center`}>
              <div>
                <p className="text-sm font-medium mb-1">Gap</p>
                <p className="text-2xl font-bold flex items-center">
                  {isAhead ? (
                    <ArrowUpIcon className="h-5 w-5 text-green-600 mr-1" />
                  ) : (
                    <ArrowDownIcon className="h-5 w-5 text-red-600 mr-1" />
                  )}
                  {Math.abs(gap).toLocaleString()} sq.ft.
                </p>
              </div>
              <Badge className={`ml-auto ${isAhead ? 'bg-green-500' : 'bg-red-500'}`}>
                {isAhead ? 'Ahead' : 'Behind'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Monthly Breakdown</CardTitle>
          <CardDescription>
            Track your performance month by month
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="monthly">Current Year</TabsTrigger>
              <TabsTrigger value="all">All Time</TabsTrigger>
            </TabsList>
            
            <TabsContent value="monthly">
              <MonthlyTable data={currentYearData} totalTarget={achievement.totalTarget} totalAchievement={achievement.totalAchievement} gap={gap} />
            </TabsContent>
            
            <TabsContent value="all">
              <MonthlyTable data={sortedMonthlyData} totalTarget={achievement.totalTarget} totalAchievement={achievement.totalAchievement} gap={gap} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

function MonthlyTable({ data, totalTarget, totalAchievement, gap }: { 
  data: any[]; 
  totalTarget: number;
  totalAchievement: number;
  gap: number;
}) {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Month</TableHead>
            <TableHead className="text-right">Target (sq.ft.)</TableHead>
            <TableHead className="text-right">Achievement (sq.ft.)</TableHead>
            <TableHead className="text-right">Gap</TableHead>
            <TableHead className="text-right">Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((month) => {
            const monthDiff = month.achieved - month.target;
            const isPositive = monthDiff >= 0;
            
            return (
              <TableRow key={`${month.year}-${month.month}`}>
                <TableCell className="font-medium">
                  {month.monthName} {month.year}
                </TableCell>
                <TableCell className="text-right">{month.target.toLocaleString()}</TableCell>
                <TableCell className="text-right">{month.achieved.toLocaleString()}</TableCell>
                <TableCell className="text-right">
                  <span className={isPositive ? 'text-green-600' : 'text-red-600'}>
                    {isPositive ? '+' : ''}{monthDiff.toLocaleString()}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Badge className={isPositive ? 'bg-green-500' : 'bg-red-500'}>
                    {isPositive ? 'Achieved' : 'Behind'}
                  </Badge>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
        <TableFooter>
          <TableRow>
            <TableCell className="font-bold">Year to Date Total</TableCell>
            <TableCell className="text-right font-bold">{totalTarget.toLocaleString()}</TableCell>
            <TableCell className="text-right font-bold">{totalAchievement.toLocaleString()}</TableCell>
            <TableCell className="text-right font-bold">
              <span className={gap >= 0 ? 'text-green-600' : 'text-red-600'}>
                {gap >= 0 ? '+' : ''}{gap.toLocaleString()}
              </span>
            </TableCell>
            <TableCell className="text-right">
              <Badge className={gap >= 0 ? 'bg-green-500' : 'bg-red-500'}>
                {gap >= 0 ? 'On Track' : 'Behind Target'}
              </Badge>
            </TableCell>
          </TableRow>
        </TableFooter>
      </Table>
    </div>
  );
}