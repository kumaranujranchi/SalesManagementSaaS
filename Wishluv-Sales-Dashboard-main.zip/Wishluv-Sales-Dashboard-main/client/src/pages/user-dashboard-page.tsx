import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { WeatherInfo } from "@/components/dashboard/weather-info";
import { 
  Thermometer, 
  CloudSun,
  CalendarDays, 
  Users, 
  Megaphone, 
  Award, 
  TrendingUp, 
  BarChart3, 
  LogOut,
  Bell,
  Target
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Link } from "wouter";
import { TeamPerformance } from "@/components/dashboard/team-performance";
import { ManagerPerformance } from "@/components/dashboard/manager-performance";
import { SalesDesignation, isTeamLeader, isSalesHead } from "@/lib/sales-designation";
import { Sales, User, Project } from "@shared/schema";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Line,
  ComposedChart
} from "recharts";
import { useToast } from "@/hooks/use-toast";

export default function UserDashboardPage() {
  const { user } = useAuth();
  // Tabs removed as requested, using monthly data only
  const activeTab = "monthly";
  
  // Current date information for filtering
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  
  // Weather data is now handled by the WeatherInfo component
  
  // Monthly performance data
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [yearlyData, setYearlyData] = useState<any[]>([]);

  // Query monthly sales - filtered by logged-in user
  const { data: monthlySales = [], isLoading: isLoadingMonthlySales } = useQuery({
    queryKey: ["/api/sales-monthly", user?.id],
    queryFn: async () => {
      // Only fetch data for the current user by including the userId parameter
      const res = await fetch(`/api/sales-monthly?userId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch monthly sales");
      return res.json();
    },
    enabled: !!user?.id // Only run query when user ID is available
  });

  // Query yearly sales - filtered by logged-in user
  const { data: yearlySales = [], isLoading: isLoadingYearlySales } = useQuery({
    queryKey: ["/api/sales-yearly", user?.id],
    queryFn: async () => {
      // Only fetch data for the current user by including the userId parameter
      const res = await fetch(`/api/sales-yearly?userId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch yearly sales");
      return res.json();
    },
    enabled: !!user?.id // Only run query when user ID is available
  });

  // Query Crystal City contest sales - filtered by logged-in user
  const { data: contestSales = [], isLoading: isLoadingContestSales } = useQuery({
    queryKey: ["/api/sales-contest", user?.id],
    queryFn: async () => {
      // Only fetch data for the current user by including the userId parameter
      const res = await fetch(`/api/sales-contest?userId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch contest sales");
      return res.json();
    },
    enabled: !!user?.id // Only run query when user ID is available
  });
  
  // Fetch ALL sales data (not filtered by user) to show team performance
  const { data: allMonthlySales = [], isLoading: isLoadingAllMonthlySales } = useQuery({
    queryKey: ["/api/sales-monthly"],
    queryFn: async () => {
      // Fetch data for all users by NOT including a userId parameter
      const res = await fetch(`/api/sales-monthly`);
      if (!res.ok) throw new Error("Failed to fetch all monthly sales");
      return res.json();
    },
    enabled: !!user?.id // Only run query when user ID is available
  });
  
  // Fetch ALL yearly sales data (not filtered by user) to show team YTD performance
  const { data: allYearlySales = [], isLoading: isLoadingAllYearlySales } = useQuery({
    queryKey: ["/api/sales-yearly"],
    queryFn: async () => {
      // Fetch data for all users by NOT including a userId parameter
      const res = await fetch(`/api/sales-yearly`);
      if (!res.ok) throw new Error("Failed to fetch all yearly sales");
      return res.json();
    },
    enabled: !!user?.id // Only run query when user ID is available
  });
  
  // Fetch ALL contest sales data (not filtered by user) to show team contest performance
  const { data: allContestSales = [], isLoading: isLoadingAllContestSales } = useQuery({
    queryKey: ["/api/sales-contest"],
    queryFn: async () => {
      // Fetch data for all users by NOT including a userId parameter
      const res = await fetch(`/api/sales-contest`);
      if (!res.ok) throw new Error("Failed to fetch all contest sales");
      return res.json();
    },
    enabled: !!user?.id // Only run query when user ID is available
  });
  
  // Process monthly and yearly data for visualization
  useEffect(() => {
    if (!isLoadingMonthlySales && !isLoadingYearlySales) {
      // Process monthly data
      if (monthlySales && monthlySales.length > 0) {
        // Check if data has changed to avoid unnecessary updates
        const newMonthlyData = monthlySales.map((sale: any) => ({
          date: format(new Date(sale.bookingDate), 'dd MMM'),
          sqft: parseFloat(sale.areaSold || '0'),
          revenue: parseFloat(sale.finalAmount || '0'),
          // Use actual user target data from API instead of hardcoded value
          // If no target is set, don't show the target line
          target: user?.monthlyTarget || null
        }));
        
        // Only update if data has changed
        if (JSON.stringify(newMonthlyData) !== JSON.stringify(monthlyData)) {
          setMonthlyData(newMonthlyData);
        }
      } else if (monthlyData.length !== 0) {
        setMonthlyData([]);
      }
      
      // Process yearly data - only if there are actual sales data
      if (yearlySales && yearlySales.length > 0) {
        // Get all months from January to current month
        const currentMonth = new Date().getMonth();
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        
        // Create a structure with all months up to current month
        const newYearlySummary: any[] = [];
        
        for (let i = 0; i <= currentMonth; i++) {
          // Get sales for this month
          const monthSales = yearlySales.filter((sale: any) => {
            const saleDate = new Date(sale.bookingDate);
            return saleDate.getMonth() === i;
          });
          
          // Calculate total square feet sold in this month
          const achievement = monthSales.reduce((total: number, sale: any) => {
            return total + parseFloat(sale.areaSold || '0');
          }, 0);
          
          // Get target from user's monthly target data
          // Don't show target if none is set
          const target = user?.monthlyTarget || null;
          
          // Only add to summary if there is either achievement data (sales) or a target set
          if (achievement > 0 || target) {
            newYearlySummary.push({
              month: months[i],
              target,
              achievement
            });
          }
        }
        
        // Only update if data has changed
        if (JSON.stringify(newYearlySummary) !== JSON.stringify(yearlyData)) {
          setYearlyData(newYearlySummary);
        }
      } else if (yearlyData.length !== 0) {
        setYearlyData([]);
      }
    }
  }, [monthlySales, yearlySales, isLoadingMonthlySales, isLoadingYearlySales]);

  // Query users (sales executives)
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await fetch("/api/users");
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    }
  });

  // Query projects
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const res = await fetch("/api/projects");
      if (!res.ok) throw new Error("Failed to fetch projects");
      return res.json();
    }
  });

  // Query announcements
  const { data: announcements = [], isLoading: isLoadingAnnouncements } = useQuery({
    queryKey: ["/api/announcements"],
    queryFn: async () => {
      const res = await fetch("/api/announcements");
      if (!res.ok) throw new Error("Failed to fetch announcements");
      return res.json();
    }
  });

  // Get active sales data based on the selected tab
  // Get current user's sales data (using monthly data only since tabs were removed)
  const getActiveSalesData = () => {
    return monthlySales;
  };
  
  // Get ALL sales data (across all users) - using monthly data only since tabs were removed
  const getAllSalesData = () => {
    return allMonthlySales;
  };

  // Get project name by ID
  const getProjectName = (projectId: number) => {
    const project = projects.find((p: Project) => p.id === projectId);
    return project ? project.name : "Unknown Project";
  };

  // Get sales executive name by ID
  const getSalesExecutiveName = (userId: number) => {
    const foundUser = users.find((u: User) => u.id === userId);
    return foundUser ? foundUser.fullName : "Unknown User";
  };

  // Generate leaderboard data
  const generateLeaderboardData = () => {
    // Use ALL sales data for leaderboard generation, not just the current user's sales
    const allSales = getAllSalesData();
    
    // Group sales by executive
    const salesByExecutive: Record<number, { totalSales: number, totalArea: number, count: number }> = {};
    
    allSales.forEach((sale: Sales) => {
      if (!salesByExecutive[sale.salesExecutiveId]) {
        salesByExecutive[sale.salesExecutiveId] = {
          totalSales: 0,
          totalArea: 0,
          count: 0
        };
      }
      
      salesByExecutive[sale.salesExecutiveId].totalSales += Number(sale.finalAmount);
      salesByExecutive[sale.salesExecutiveId].totalArea += Number(sale.areaSold);
      salesByExecutive[sale.salesExecutiveId].count += 1;
    });
    
    // Convert to array and sort by total revenue (totalSales) for proper leaderboard display
    return Object.entries(salesByExecutive)
      .map(([executiveId, stats]) => ({
        executiveId: parseInt(executiveId),
        executiveName: getSalesExecutiveName(parseInt(executiveId)),
        totalSales: stats.totalSales,
        totalArea: stats.totalArea,
        count: stats.count
      }))
      .sort((a, b) => b.totalSales - a.totalSales);
  };

  // Generate current user's stats
  const generateUserStats = () => {
    if (!user) return null;
    
    const activeSales = getActiveSalesData();
    const userSales = activeSales.filter((sale: Sales) => sale.salesExecutiveId === user.id);
    
    const totalSales = userSales.reduce((acc: number, sale: Sales) => acc + Number(sale.finalAmount), 0);
    const totalArea = userSales.reduce((acc: number, sale: Sales) => acc + Number(sale.areaSold), 0);
    const salesCount = userSales.length;
    
    // Calculate user's rank in leaderboard
    const leaderboard = generateLeaderboardData();
    const userRank = leaderboard.findIndex(item => item.executiveId === user.id) + 1;
    
    return {
      totalSales,
      totalArea,
      salesCount,
      rank: userRank > 0 ? userRank : "N/A"
    };
  };

  const userStats = generateUserStats();
  const leaderboard = generateLeaderboardData();
  const isLoading = isLoadingMonthlySales || isLoadingYearlySales || isLoadingContestSales || 
                   isLoadingAllMonthlySales || isLoadingAllYearlySales || isLoadingAllContestSales ||
                   isLoadingUsers || isLoadingProjects || isLoadingAnnouncements;

  const { toast } = useToast();
  const { logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of your account.",
    });
  };
  
  // Prepare chart data
  const prepareSalesChart = () => {
    if (!user) return [];
    
    const activeSales = getActiveSalesData();
    const userSales = activeSales.filter((sale: Sales) => sale.salesExecutiveId === user.id);
    
    // Group by project
    const salesByProject: Record<number, { total: number, name: string }> = {};
    userSales.forEach((sale: Sales) => {
      if (!salesByProject[sale.projectId]) {
        salesByProject[sale.projectId] = {
          total: 0,
          name: getProjectName(sale.projectId)
        };
      }
      salesByProject[sale.projectId].total += Number(sale.finalAmount);
    });
    
    // Convert to array for chart
    return Object.entries(salesByProject).map(([id, data]) => ({
      name: data.name,
      value: data.total
    }));
  };
  
  const chartData = prepareSalesChart();
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-orange-50">
      <header className="bg-white shadow-sm z-10 px-4 py-3 flex justify-between items-center sticky top-0">
        <motion.div 
          className="flex items-center gap-2"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex flex-col">
            <h1 className="text-lg sm:text-xl font-bold bg-gradient-to-r from-amber-700 to-orange-700 bg-clip-text text-transparent leading-tight">
              Sales Dashboard
            </h1>
            <span className="text-xs text-gray-500 font-normal">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </span>
          </div>
          <Button variant="ghost" size="sm" className="w-8 h-8 p-0 rounded-full text-neutral-600">
            <Bell className="h-4 w-4" />
          </Button>
        </motion.div>
        <div className="flex items-center gap-3 text-black">
          {/* Weather Info Component */}
          <div className="hidden md:block border-l pl-2 border-amber-100">
            <WeatherInfo />
          </div>
          
          {/* Mobile weather - icon only */}
          <div className="md:hidden flex items-center gap-1 bg-amber-50 w-8 h-8 rounded-full justify-center border border-amber-100">
            <Thermometer className="h-4 w-4 text-amber-700" />
            <span className="sr-only">Current weather</span>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            className="hidden md:flex items-center gap-2 hover:bg-red-50 hover:text-red-600 transition-colors"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </Button>
        </div>
      </header>
      
      <main className="px-3 py-4 md:p-6 space-y-3 md:space-y-4 pb-24 md:pb-20">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          {/* Welcome Banner */}
          <Card className="mb-3 md:mb-4 bg-gradient-to-r from-blue-500 to-teal-500 text-white border-none shadow-lg overflow-hidden">
            <CardContent className="p-3 sm:p-4">
              <div className="flex flex-col gap-2 sm:gap-3">
                <div>
                  <h2 className="text-base sm:text-xl font-bold truncate">
                    Welcome, {user?.fullName || (user?.role === 'Sales Representative' ? 'Sales Executive' : user?.role || 'User')}!
                  </h2>
                  <p className="text-white mt-0.5 text-xs sm:text-sm font-medium">
                    Current Month Dashboard
                  </p>
                </div>
                {/* Tabs removed as requested */}
              </div>
            </CardContent>
          </Card>
      
          {/* Manager Performance Component - based on reporting manager relationship */}
          {user?.department === "Sales" && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="mb-4"
            >
              <ManagerPerformance />
            </motion.div>
          )}
          
          {/* Sales Leaderboard and Charts are handled by the ManagerPerformance component */}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {/* Sales Leaderboard Card */}
            <motion.div
              className="bg-white rounded-lg border shadow-sm p-3 sm:p-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <h3 className="text-sm font-medium mb-2 sm:mb-4">Sales Leaderboard</h3>
              
              {isLoadingMonthlySales || isLoadingAllMonthlySales || isLoadingUsers ? (
                <div className="h-[300px] flex items-center justify-center">
                  <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
                </div>
              ) : (
                <div className="overflow-y-auto h-[300px]">
                  <div className="flex justify-between text-[10px] sm:text-xs text-gray-500 mb-1 sm:mb-2 px-2">
                    <span>Executive</span>
                    <span>Sales This Month</span>
                  </div>
                  {
                    // Sort by area sold and show top 3 executives
                    // Then we'll generate current month stats for these top performers
                    [...leaderboard]
                      .sort((a, b) => b.totalArea - a.totalArea) // Sort by area sold
                      .slice(0, 3) // Take the top 3 executives based on area sold
                      .map((executive, index) => {
                        // Calculate monthly sales for this executive for the current month using ALL sales data
                        const monthlySales = getAllSalesData().filter((sale: Sales) => {
                          const saleDate = new Date(sale.bookingDate);
                          return sale.salesExecutiveId === executive.executiveId && 
                                 saleDate.getMonth() === currentMonth &&
                                 saleDate.getFullYear() === currentYear;
                        });
                        
                        const totalMonthlySales = monthlySales.reduce(
                          (sum: number, sale: Sales) => sum + parseFloat(sale.finalAmount || "0"), 0
                        );
                        
                        const totalMonthlyArea = monthlySales.reduce(
                          (sum: number, sale: Sales) => sum + parseFloat(sale.areaSold || "0"), 0
                        );
                        
                        const userImg = users.find((u: any) => u.id === executive.executiveId)?.imageUrl || 
                          "https://ui-avatars.com/api/?name=" + encodeURIComponent(executive.executiveName);
                        
                        return (
                          <div key={executive.executiveId} 
                              className={`flex items-center p-2 sm:p-3 rounded-md mb-2 ${
                                user?.id === executive.executiveId ? 'bg-amber-50 border border-amber-200' : 'bg-gray-50 border'
                              }`}>
                            <div className="relative">
                              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full overflow-hidden flex-shrink-0">
                                <img src={userImg} alt={executive.executiveName} className="w-full h-full object-cover" />
                              </div>
                              <div className="absolute -right-1 -bottom-1 text-[10px] sm:text-xs rounded-full w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center font-bold text-white" style={{
                                backgroundColor: index === 0 ? '#f59e0b' : index === 1 ? '#6366f1' : '#a855f7'
                              }}>
                                {index === 0 ? '1' : index === 1 ? '2' : '3'}
                              </div>
                            </div>
                            <div className="ml-2 sm:ml-3 flex-1">
                              <div className="flex justify-between">
                                <h4 className="text-[10px] sm:text-xs font-semibold text-black">{executive.executiveName}</h4>
                                <span className="text-[10px] sm:text-xs font-medium text-amber-700">₹{totalMonthlySales.toLocaleString()}</span>
                              </div>
                              <div className="mt-1">
                                <div className="w-full bg-gray-200 rounded-full h-1 sm:h-1.5">
                                  <div 
                                    className={`h-1 sm:h-1.5 rounded-full ${index === 0 ? 'bg-amber-500' : 'bg-blue-500'}`}
                                    style={{ width: `${Math.min(100, (totalMonthlyArea / (user?.monthlyTarget || 5000)) * 100)}%` }}
                                  ></div>
                                </div>
                                <div className="flex justify-between mt-0.5 sm:mt-1">
                                  <span className="text-[9px] sm:text-[10px] text-gray-800">Area: {totalMonthlyArea.toLocaleString()} sq.ft</span>
                                  <span className="text-[9px] sm:text-[10px] text-gray-800">Sales: {monthlySales.length}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })
                  }
                </div>
              )}
            </motion.div>

            {/* Revenue Leaderboard Card */}
            <motion.div
              className="bg-white rounded-lg border shadow-sm p-3 sm:p-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <h3 className="text-sm font-medium mb-2 sm:mb-4">Revenue Leaderboard</h3>
              
              {isLoading || isLoadingUsers ? (
                <div className="h-[300px] flex items-center justify-center">
                  <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
                </div>
              ) : leaderboard.length === 0 ? (
                <div className="h-[300px] flex flex-col items-center justify-center text-muted-foreground">
                  <Award className="h-8 w-8 mb-2 text-muted-foreground/50" />
                  <p className="text-sm">No leaderboard data available</p>
                </div>
              ) : (
                <div className="overflow-y-auto h-[300px]">
                  <div className="space-y-3">
                    {/* Sort by total revenue - only top 3 */}
                    {leaderboard
                      .sort((a, b) => b.totalSales - a.totalSales)
                      .slice(0, 3)
                      .map((executive, index) => {
                        const userImg = users.find((u: any) => u.id === executive.executiveId)?.imageUrl || 
                          "https://ui-avatars.com/api/?name=" + encodeURIComponent(executive.executiveName);
                          
                        // Calculate percentage compared to top performer based on revenue
                        // Find the executive with highest revenue without modifying the original array
                        const executiveWithHighestRevenue = [...leaderboard].sort((a, b) => b.totalSales - a.totalSales)[0];
                        const topRevenue = executiveWithHighestRevenue.totalSales;
                        const percentage = (executive.totalSales / topRevenue) * 100;
                        
                        return (
                          <div key={executive.executiveId} 
                            className={`relative p-2 sm:p-4 rounded-lg ${user?.id === executive.executiveId ? 'bg-amber-50 border-amber-200' : 'bg-gray-50'} border`}>
                            <div className="flex items-center">
                              <div className="relative">
                                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full overflow-hidden">
                                  <img src={userImg} alt={executive.executiveName} className="w-full h-full object-cover" />
                                </div>
                                <div className="absolute -right-1 -bottom-1 text-[10px] sm:text-xs rounded-full w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center font-bold text-white" style={{
                                  backgroundColor: index === 0 ? '#f59e0b' : index === 1 ? '#6366f1' : '#a855f7'
                                }}>
                                  {index === 0 ? '1' : index === 1 ? '2' : '3'}
                                </div>
                              </div>
                              <div className="ml-2 sm:ml-3">
                                <h4 className="text-xs sm:text-sm font-semibold text-black">{executive.executiveName}</h4>
                                <p className="text-[10px] sm:text-xs text-gray-800">Sales: {executive.count} bookings</p>
                              </div>
                              <div className="ml-auto text-right">
                                <div className="text-xs sm:text-sm font-bold text-amber-700">₹{executive.totalSales.toLocaleString()}</div>
                                <p className="text-[10px] sm:text-xs text-gray-800">{executive.totalArea.toLocaleString()} sq.ft</p>
                              </div>
                            </div>
                            <div className="mt-2 sm:mt-3">
                              <div className="w-full bg-gray-200 rounded-full h-1.5 sm:h-2">
                                <div 
                                  className={`h-1.5 sm:h-2 rounded-full ${
                                    index === 0 ? 'bg-amber-500' : 
                                    index === 1 ? 'bg-blue-500' : 
                                    index === 2 ? 'bg-purple-500' : 'bg-green-500'
                                  }`}
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    }
                  </div>
                </div>
              )}
            </motion.div>
          </div>
          
          {/* Announcements Section */}
          <motion.div 
            className="bg-white rounded-lg border shadow-sm p-4 mb-20"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.8 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium">Latest Announcements</h3>
              <Link to="/announcements" className="text-xs text-primary hover:underline">
                View All
              </Link>
            </div>
            
            {isLoading ? (
              <div className="h-[100px] flex items-center justify-center">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
              </div>
            ) : announcements.length === 0 ? (
              <div className="h-[100px] flex flex-col items-center justify-center text-muted-foreground">
                <Megaphone className="h-8 w-8 mb-2 text-muted-foreground/50" />
                <p className="text-sm">No announcements available</p>
              </div>
            ) : (
              <div className="space-y-3">
                {announcements.slice(0, 3).map((announcement: any) => (
                  <div key={announcement.id} className="border-b pb-3 last:border-b-0">
                    <h4 className="text-sm font-medium">{announcement.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{announcement.content}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">
                      {format(new Date(announcement.createdAt), 'MMM d, yyyy')}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      </main>
      
      {/* Mobile Footer Navigation */}
      <div className="block md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-10">
        <div className="flex items-center justify-around py-2">
          <Link to="/" className="flex flex-col items-center justify-center py-1">
            <BarChart3 className="h-5 w-5 text-primary" />
            <span className="text-[10px] mt-0.5">Dashboard</span>
          </Link>
          <Link to="/directory" className="flex flex-col items-center justify-center py-1">
            <Users className="h-5 w-5 text-muted-foreground" />
            <span className="text-[10px] mt-0.5">Directory</span>
          </Link>
          <Link to="/sales" className="flex flex-col items-center justify-center py-1">
            <TrendingUp className="h-5 w-5 text-muted-foreground" />
            <span className="text-[10px] mt-0.5">Sales</span>
          </Link>
          <Link to="/announcements" className="flex flex-col items-center justify-center py-1">
            <Megaphone className="h-5 w-5 text-muted-foreground" />
            <span className="text-[10px] mt-0.5">Updates</span>
          </Link>
          <button 
            onClick={handleLogout}
            className="flex flex-col items-center justify-center py-1"
          >
            <LogOut className="h-5 w-5 text-red-500" />
            <span className="text-[10px] mt-0.5 text-red-500">Logout</span>
          </button>
        </div>
      </div>
    </div>
  );
}