import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar, Clock, MapPin, Building2, User, Car, CheckCircle, Gauge } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const completeSiteVisitSchema = z.object({
  startOdometer: z.number().min(0, "Start odometer must be a positive number"),
  endOdometer: z.number().min(0, "End odometer must be a positive number"),
  remarks: z.string().optional(),
}).refine((data) => data.endOdometer > data.startOdometer, {
  message: "End odometer must be greater than start odometer",
  path: ["endOdometer"],
});

type CompleteSiteVisitFormData = z.infer<typeof completeSiteVisitSchema>;

export default function DriverDashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedVisit, setSelectedVisit] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const form = useForm<CompleteSiteVisitFormData>({
    resolver: zodResolver(completeSiteVisitSchema),
    defaultValues: {
      startOdometer: 0,
      endOdometer: 0,
      remarks: "",
    },
  });

  // Fetch assigned site visits for driver
  const { data: siteVisits = [], isLoading } = useQuery({
    queryKey: ['/api/site-visits/driver', user?.id],
    queryFn: () => fetch(`/api/site-visits/driver/${user?.id}`).then(res => res.json()),
    enabled: !!user?.id,
  });

  const completeSiteVisitMutation = useMutation({
    mutationFn: async ({ visitId, data }: { visitId: number; data: CompleteSiteVisitFormData }) => {
      const res = await apiRequest("PUT", `/api/site-visits/${visitId}/complete`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Site visit completed",
        description: "The site visit has been marked as completed successfully.",
      });
      setIsDialogOpen(false);
      setSelectedVisit(null);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/site-visits/driver', user?.id] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to complete site visit",
        variant: "destructive",
      });
    },
  });

  const handleCompleteVisit = (visit: any) => {
    setSelectedVisit(visit);
    setIsDialogOpen(true);
    form.reset({
      startOdometer: 0,
      endOdometer: 0,
      remarks: "",
    });
  };

  const onSubmit = (data: CompleteSiteVisitFormData) => {
    if (selectedVisit) {
      completeSiteVisitMutation.mutate({
        visitId: selectedVisit.id,
        data,
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge variant="default" className="bg-green-500">Ready for Visit</Badge>;
      case 'completed':
        return <Badge variant="outline" className="border-blue-500 text-blue-600">Completed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const pendingVisits = siteVisits.filter((visit: any) => visit.status === 'approved');
  const completedVisits = siteVisits.filter((visit: any) => visit.status === 'completed');

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Driver Dashboard</h1>
            <p className="text-gray-600">Manage your assigned site visits</p>
          </div>
          <div className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            <span className="text-sm text-gray-600">{user?.fullName}</span>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pending Visits</p>
                  <p className="text-2xl font-bold text-orange-600">{pendingVisits.length}</p>
                </div>
                <Clock className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Completed Today</p>
                  <p className="text-2xl font-bold text-green-600">
                    {completedVisits.filter((visit: any) => 
                      new Date(visit.completedAt).toDateString() === new Date().toDateString()
                    ).length}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Completed</p>
                  <p className="text-2xl font-bold text-blue-600">{completedVisits.length}</p>
                </div>
                <Car className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Site Visits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Pending Site Visits
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
              </div>
            ) : pendingVisits.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No pending site visits
              </div>
            ) : (
              <div className="space-y-4">
                {pendingVisits.map((visit: any) => (
                  <div key={visit.id} className="border rounded-lg p-4 bg-white">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <h3 className="font-medium text-lg">{visit.customerName}</h3>
                          {getStatusBadge(visit.status)}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600 mb-4">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>{new Date(visit.visitDate).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            <span>{visit.visitTime}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4" />
                            <span>{visit.pickupLocation}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4" />
                            <span>{JSON.parse(visit.projectIds).length} Project(s)</span>
                          </div>
                        </div>
                        <Button 
                          onClick={() => handleCompleteVisit(visit)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Complete Visit
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Completed Site Visits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              Completed Site Visits
            </CardTitle>
          </CardHeader>
          <CardContent>
            {completedVisits.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No completed site visits
              </div>
            ) : (
              <div className="space-y-4">
                {completedVisits.map((visit: any) => (
                  <div key={visit.id} className="border rounded-lg p-4 bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <h3 className="font-medium">{visit.customerName}</h3>
                          {getStatusBadge(visit.status)}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600 mb-3">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>{new Date(visit.visitDate).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            <span>{visit.visitTime}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Gauge className="h-4 w-4" />
                            <span>ODO: {visit.startOdometer} - {visit.endOdometer}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            <span>{new Date(visit.completedAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        {visit.remarks && (
                          <div className="text-sm text-gray-600">
                            <strong>Remarks:</strong> {visit.remarks}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Complete Visit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Complete Site Visit</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="startOdometer">Start Odometer Reading</Label>
                <Input
                  id="startOdometer"
                  type="number"
                  {...form.register("startOdometer", { valueAsNumber: true })}
                  placeholder="Enter start odometer reading"
                />
                {form.formState.errors.startOdometer && (
                  <p className="text-sm text-red-600">{form.formState.errors.startOdometer.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="endOdometer">End Odometer Reading</Label>
                <Input
                  id="endOdometer"
                  type="number"
                  {...form.register("endOdometer", { valueAsNumber: true })}
                  placeholder="Enter end odometer reading"
                />
                {form.formState.errors.endOdometer && (
                  <p className="text-sm text-red-600">{form.formState.errors.endOdometer.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="remarks">Remarks (Optional)</Label>
                <Textarea
                  id="remarks"
                  {...form.register("remarks")}
                  placeholder="Any additional notes about the visit"
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={completeSiteVisitMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {completeSiteVisitMutation.isPending ? "Completing..." : "Complete Visit"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}