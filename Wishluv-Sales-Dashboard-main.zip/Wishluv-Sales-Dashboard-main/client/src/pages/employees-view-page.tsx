import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Search, 
  Phone, 
  Mail, 
  Briefcase,
  UsersRound,
  Building,
  UserPlus,
  Loader2,
  User as UserIcon
} from "lucide-react";
import { User, Department } from "@shared/schema";

export default function EmployeesViewPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  // Fetch users
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  // Fetch departments for filtering
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: ["/api/departments"],
  });

  // Filter users based on search
  const filteredUsers = users.filter((user: User) => {
    if (!searchTerm) return true;
    
    const searchLower = searchTerm.toLowerCase();
    return (
      user.fullName?.toLowerCase().includes(searchLower) ||
      user.email?.toLowerCase().includes(searchLower) ||
      user.phone?.toLowerCase().includes(searchLower) ||
      user.department?.toLowerCase().includes(searchLower) ||
      user.designation?.toLowerCase().includes(searchLower) ||
      user.team?.toLowerCase().includes(searchLower) ||
      user.employeeId?.toLowerCase().includes(searchLower)
    );
  });

  // Determine active users based on tab
  const getActiveUsers = () => {
    if (activeTab === "all") return filteredUsers;
    return filteredUsers.filter((user: User) => user.department === activeTab);
  };

  // Get user initials for avatar fallback
  const getUserInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map(n => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
  };

  // Function to get active users by department
  function getUsersByDepartment() {
    const departmentUsers: Record<string, User[]> = {};
    
    departments.forEach((department: Department) => {
      departmentUsers[department.name] = [];
    });
    
    filteredUsers.forEach(user => {
      if (user.department && departmentUsers[user.department]) {
        departmentUsers[user.department].push(user);
      }
    });
    
    return departmentUsers;
  }

  return (
    <div className="flex-1 space-y-6 pb-24 md:pb-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-2xl font-bold">Employee Directory</h1>
          <p className="text-muted-foreground">Browse and view employee information</p>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search employee by name, email, department..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Tabs for Department Filters */}
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4 overflow-auto">
          <TabsTrigger value="all">All</TabsTrigger>
          {departments.map((department: Department) => (
            <TabsTrigger key={department.id} value={department.name}>
              {department.name}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center py-12">
              <UserIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No employees found</h3>
              <p className="text-muted-foreground mb-6">
                {searchTerm ? "Try a different search term" : "No employees have been added yet"}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredUsers.map((user: User) => (
                <EmployeeCard key={user.id} user={user} />
              ))}
            </div>
          )}
        </TabsContent>

        {departments.map((department: Department) => (
          <TabsContent key={department.id} value={department.name}>
            {isLoading ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : getUsersByDepartment()[department.name].length === 0 ? (
              <div className="text-center py-12">
                <UserIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No employees found</h3>
                <p className="text-muted-foreground mb-6">
                  {searchTerm 
                    ? "Try a different search term" 
                    : `No employees in ${department.name} department`}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {getUsersByDepartment()[department.name].map((user: User) => (
                  <EmployeeCard key={user.id} user={user} />
                ))}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function EmployeeCard({ user }: { user: User }) {
  const getUserInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map(n => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-4">
          <Avatar className="h-12 w-12 border">
            <AvatarImage src={user.imageUrl || ""} alt={user.fullName || "User"} />
            <AvatarFallback>{getUserInitials(user.fullName || "")}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-base">{user.fullName}</CardTitle>
            <CardDescription>{user.designation}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-3">
        <div className="space-y-3 text-sm">
          <div className="flex items-center gap-2">
            <Mail className="h-4 w-4 text-muted-foreground" />
            <span>{user.email}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-muted-foreground" />
            <span>{user.phone || "Not available"}</span>
          </div>
          <div className="flex items-center gap-2">
            <Building className="h-4 w-4 text-muted-foreground" />
            <span>{user.department}</span>
          </div>
          {user.team && (
            <div className="flex items-center gap-2">
              <UsersRound className="h-4 w-4 text-muted-foreground" />
              <span>{user.team}</span>
            </div>
          )}
          <div className="pt-2">
            <Badge variant="outline" className="mr-1">
              {user.employeeId || "ID: N/A"}
            </Badge>
            <Badge variant={user.status ? "default" : "destructive"} className="bg-green-100 text-green-800 hover:bg-green-100">
              {user.status ? "Active" : "Inactive"}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}