import { useState, useEffect } from "react";
import {
  useQuery,
  useMutation,
  useQueryClient
} from "@tanstack/react-query";
import { 
  Calendar as CalendarIcon, 
  Filter, 
  Pencil as Edit, 
  Plus, 
  Trash2, 
  CreditCard, 
  DollarSign, 
  FileText, 
  AlertCircle,
  Search,
  RefreshCw,
  Users,
  Check,
  ChevronDown,
  X,
  Building2,
  Ban
} from "lucide-react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, FormProvider } from "react-hook-form";
import { format } from "date-fns";

// UI Components
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Calendar as DateCalendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Sales, User, Project } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

// Custom Date Picker Component
function DatePickerFormField({ 
  form, 
  name, 
  label 
}: { 
  form: any; 
  name: string; 
  label: string;
}) {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  
  return (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem className="space-y-3">
          <FormLabel>{label}</FormLabel>
          <div className="relative">
            <FormControl>
              <Button
                type="button"
                variant={"outline"}
                className="w-full pl-3 text-left font-normal flex justify-between items-center"
                onClick={() => setIsCalendarOpen(!isCalendarOpen)}
              >
                {field.value ? format(new Date(field.value), "PPP") : <span>Pick a date</span>}
                <CalendarIcon className="h-4 w-4 opacity-70" />
              </Button>
            </FormControl>
            
            {isCalendarOpen && (
              <div className="fixed inset-0 z-50 flex items-start justify-center pt-4 sm:pt-0" onClick={() => setIsCalendarOpen(false)}>
                <div className="absolute inset-0 bg-black/20" aria-hidden="true" />
                <div 
                  className="relative bg-white rounded-md shadow-xl p-4 max-w-sm w-full mx-auto mt-20 max-h-[90vh] overflow-auto"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium">Select Date</h3>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={() => setIsCalendarOpen(false)}
                    >
                      <X className="h-4 w-4" />
                      <span className="sr-only">Close</span>
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-3">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => {
                        field.onChange(format(new Date(), "yyyy-MM-dd"));
                        setIsCalendarOpen(false);
                      }}
                    >
                      Today
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => {
                        const yesterday = new Date();
                        yesterday.setDate(yesterday.getDate() - 1);
                        field.onChange(format(yesterday, "yyyy-MM-dd"));
                        setIsCalendarOpen(false);
                      }}
                    >
                      Yesterday
                    </Button>
                  </div>
                  <div className="p-2 flex justify-center">
                    <DateCalendar
                      mode="single"
                      selected={field.value ? new Date(field.value) : undefined}
                      onSelect={(date: Date | undefined) => {
                        field.onChange(date ? format(date, "yyyy-MM-dd") : "");
                        setIsCalendarOpen(false);
                      }}
                      initialFocus
                      className="rounded-md"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
          <FormMessage />
        </FormItem>
      )}
    />
  );
}

// Form Schemas
// Create sales form schema with validation
const salesFormSchema = z.object({
  bookingDate: z.string().min(1, "Booking date is required"),
  bookingDone: z.string().optional().default("No"),
  bookingData: z.string().optional(),
  agreementDate: z.string().optional(),
  salesExecutiveId: z.number().int().min(1, "Sales executive is required"),
  projectId: z.number().int().min(1, "Project is required"),
  customerName: z.string().min(2, "Customer name must be at least 2 characters"),
  customerMobile: z.string().min(10, "Mobile number must be at least 10 digits"),
  areaSold: z.coerce.number().min(1, "Area sold must be greater than 0"),
  baseSalePrice: z.coerce.number().min(1, "Base sale price must be greater than 0"),
  developmentCharges: z.coerce.number().min(0, "Development Charges must be 0 or greater").optional(),
  preferredLocationCharge: z.coerce.number().min(0, "PLC must be 0 or greater").optional(),
  plotNo: z.string().optional(),
});

const paymentFormSchema = z.object({
  paymentDate: z.string().min(1, "Payment date is required"),
  amount: z.coerce.number().min(1, "Amount must be greater than 0"),
  paymentType: z.string().min(1, "Payment type is required"),
  paymentMode: z.string().min(1, "Payment mode is required"),
  remarks: z.string().optional(),
});

// Types
type SalesFormValues = z.infer<typeof salesFormSchema>;
type PaymentFormValues = z.infer<typeof paymentFormSchema>;

export default function SalesManagementPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [isEditPaymentDialogOpen, setIsEditPaymentDialogOpen] = useState(false);
  const [paymentTab, setPaymentTab] = useState("view-payments");
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false);
  const [filters, setFilters] = useState({
    startDate: "",
    endDate: "",
    salesExecutiveId: 0,
    projectId: 0,
  });
  const [currentSale, setCurrentSale] = useState<Sales | null>(null);
  const [isCancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [saleToCancel, setSaleToCancel] = useState<any>(null);
  const [cancellationReason, setCancellationReason] = useState("");
  const [payments, setPayments] = useState<any[]>([]);
  const [currentPayment, setCurrentPayment] = useState<any | null>(null);

  // Queries
  const { data: sales = [] } = useQuery<Sales[]>({
    queryKey: ["/api/sales"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
    staleTime: 1000 * 60 * 15, // 15 minutes
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    staleTime: 1000 * 60 * 30, // 30 minutes
  });

  // Create form
  const createForm = useForm<SalesFormValues>({
    resolver: zodResolver(salesFormSchema),
    defaultValues: {
      bookingDate: format(new Date(), "yyyy-MM-dd"),
      bookingDone: "No", // Default to "No" as requested
      bookingData: "",
      salesExecutiveId: undefined,
      projectId: undefined,
      customerName: "",
      customerMobile: "",
      areaSold: 0,
      baseSalePrice: 0,
      developmentCharges: 0,
      preferredLocationCharge: 0,
      plotNo: "",
    },
  });

  // Edit form
  const editForm = useForm<SalesFormValues>({
    resolver: zodResolver(salesFormSchema),
    defaultValues: {
      bookingDate: "",
      bookingDone: "No",
      bookingData: "",
      salesExecutiveId: undefined,
      projectId: undefined,
      customerName: "",
      customerMobile: "",
      areaSold: undefined,
      baseSalePrice: undefined,
      developmentCharges: undefined,
      preferredLocationCharge: undefined,
      plotNo: "",
    },
  });

  // Payment form
  const paymentForm = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      paymentDate: format(new Date(), "yyyy-MM-dd"),
      amount: undefined,
      paymentType: "",
      paymentMode: "",
      remarks: "",
    },
  });

  // Edit payment form
  const editPaymentForm = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      paymentDate: "",
      amount: undefined,
      paymentType: "",
      paymentMode: "",
      remarks: "",
    },
  });

  // Mutations
  const createSaleMutation = useMutation({
    mutationFn: async (data: SalesFormValues) => {
      console.log("Sending sale data:", data);
      const response = await apiRequest("POST", "/api/sales", data);
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Sale creation error response:", errorData);
        if (errorData.missingFields) {
          throw new Error(`Missing fields: ${errorData.missingFields.join(', ')}`);
        }
        throw new Error(errorData.error || errorData.message || "Failed to create sale");
      }
      return await response.json();
    },
    onSuccess: (data) => {
      console.log("Sale created successfully:", data);
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      setIsCreateDialogOpen(false);
      createForm.reset();
      toast({
        title: "Sale created",
        description: "The sale has been created successfully.",
      });
    },
    onError: (error: Error) => {
      console.error("Sale creation error:", error);
      toast({
        title: "Failed to create sale",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateSaleMutation = useMutation({
    mutationFn: async (data: SalesFormValues & { id: number }) => {
      const { id, ...saleData } = data;
      const response = await apiRequest("PUT", `/api/sales/${id}`, saleData);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update sale");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      setIsEditDialogOpen(false);
      editForm.reset();
      toast({
        title: "Sale updated",
        description: "The sale has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update sale",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const cancelSaleMutation = useMutation({
    mutationFn: async ({ id, cancellationReason }: { id: number; cancellationReason: string }) => {
      const response = await apiRequest("PATCH", `/api/sales/${id}/cancel`, { cancellationReason });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to cancel sale");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      setCancelDialogOpen(false);
      setCancellationReason("");
      setSaleToCancel(null);
      toast({
        title: "Sale cancelled",
        description: "The sale has been cancelled successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to cancel sale",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteSaleMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/sales/${id}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete sale");
      }
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      toast({
        title: "Sale deleted",
        description: "The sale has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete sale",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addPaymentMutation = useMutation({
    mutationFn: async (data: PaymentFormValues & { saleId: number }) => {
      const response = await apiRequest("POST", "/api/payments", data);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to add payment");
      }
      return await response.json();
    },
    onSuccess: () => {
      if (currentSale) {
        fetchPayments(currentSale.id);
      }
      setPaymentTab("view-payments");
      paymentForm.reset();
      toast({
        title: "Payment added",
        description: "The payment has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add payment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updatePaymentMutation = useMutation({
    mutationFn: async (data: PaymentFormValues & { id: number }) => {
      const { id, ...paymentData } = data;
      const response = await apiRequest("PUT", `/api/payments/${id}`, paymentData);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update payment");
      }
      return await response.json();
    },
    onSuccess: () => {
      if (currentSale) {
        fetchPayments(currentSale.id);
      }
      setIsEditPaymentDialogOpen(false);
      editPaymentForm.reset();
      toast({
        title: "Payment updated",
        description: "The payment has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update payment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handlers
  const onCreateSubmit = (data: SalesFormValues) => {
    createSaleMutation.mutate(data);
  };

  const onEditSubmit = (data: SalesFormValues) => {
    if (!currentSale) return;
    updateSaleMutation.mutate({ id: currentSale.id, ...data });
  };

  const handleEdit = (sale: Sales) => {
    setCurrentSale(sale);
    
    // Create form values based on booking status
    const formValues = {
      bookingDate: sale.bookingDate || "",
      bookingDone: sale.bookingDone || "No", // Default to "No" if not present in data
      bookingData: sale.bookingData || "",
      salesExecutiveId: sale.salesExecutiveId ? Number(sale.salesExecutiveId) : undefined,
      projectId: sale.projectId ? Number(sale.projectId) : undefined,
      customerName: sale.customerName || "",
      customerMobile: sale.customerMobile || "",
      areaSold: sale.areaSold ? Number(sale.areaSold) : undefined,
      baseSalePrice: sale.baseSalePrice ? Number(sale.baseSalePrice) : undefined,
      developmentCharges: (sale as any).developmentCharges ? Number((sale as any).developmentCharges) : undefined,
      preferredLocationCharge: (sale as any).preferredLocationCharge ? Number((sale as any).preferredLocationCharge) : undefined,
      plotNo: (sale as any).plotNo || "",
    };
    
    // Only include the agreement date if booking is done
    if (sale.bookingDone === "Yes") {
      editForm.reset({
        ...formValues,
        agreementDate: sale.agreementDate || ""
      });
    } else {
      editForm.reset(formValues);
    }
    setIsEditDialogOpen(true);
  };

  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [saleToDelete, setSaleToDelete] = useState<Sales | null>(null);

  const handleCancel = (sale: Sales) => {
    setSaleToCancel(sale);
    setCancelDialogOpen(true);
  };

  const handleDelete = (sale: Sales) => {
    setSaleToDelete(sale);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (saleToDelete) {
      deleteSaleMutation.mutate(saleToDelete.id);
      setIsDeleteDialogOpen(false);
      setSaleToDelete(null);
    }
  };

  const handleViewPayments = (sale: Sales) => {
    setCurrentSale(sale);
    fetchPayments(sale.id);
    setIsPaymentDialogOpen(true);
  };

  const onAddPaymentSubmit = (data: PaymentFormValues) => {
    if (!currentSale) return;
    addPaymentMutation.mutate({
      saleId: currentSale.id,
      ...data,
    });
  };

  const handleEditPayment = (payment: any) => {
    setCurrentPayment(payment);
    editPaymentForm.reset({
      paymentDate: payment.paymentDate,
      amount: payment.amount,
      paymentType: payment.paymentType,
      paymentMode: payment.paymentMode,
      remarks: payment.remarks || "",
    });
    setIsEditPaymentDialogOpen(true);
  };

  const onEditPaymentSubmit = (data: PaymentFormValues) => {
    if (!currentPayment) return;
    updatePaymentMutation.mutate({
      id: currentPayment.id,
      ...data,
    });
  };

  // Fetch payments for a sale
  const fetchPayments = async (saleId: number) => {
    try {
      const response = await apiRequest("GET", `/api/payments/${saleId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch payments");
      }
      const data = await response.json();
      console.log("Fetched payments:", data);
      setPayments(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching payments:", error);
      toast({
        title: "Error",
        description: "Failed to fetch payments",
        variant: "destructive",
      });
      setPayments([]);
    }
  };

  // Helper functions
  const getProjectName = (projectId: number) => {
    const project = projects.find((p) => p.id === projectId);
    return project?.name || "Unknown Project";
  };

  const getUserName = (userId: number) => {
    const user = users.find((u) => u.id === userId);
    return user?.fullName || `User ${userId}`;
  };

  const calculateTotalPayments = () => {
    return payments.reduce((total, payment) => total + Number(payment.amount), 0);
  };

  // Filter sales based on active tab and applied filters
  const filteredSales = () => {
    const currentDate = new Date();
    const thisMonth = currentDate.getMonth();
    const thisYear = currentDate.getFullYear();

    // First apply the tab filter
    let filteredByTab = sales;
    switch (activeTab) {
      case "cancelled":
        // Show only cancelled sales
        filteredByTab = sales.filter((sale) => sale.cancelledAt !== null);
        break;
      case "this-month":
        // Show only active (non-cancelled) sales from this month
        filteredByTab = sales.filter((sale) => {
          const saleDate = new Date(sale.bookingDate);
          return saleDate.getMonth() === thisMonth && 
                 saleDate.getFullYear() === thisYear &&
                 sale.cancelledAt === null;
        });
        break;
      case "this-year":
        // Show only active (non-cancelled) sales from this year
        filteredByTab = sales.filter((sale) => {
          const saleDate = new Date(sale.bookingDate);
          return saleDate.getFullYear() === thisYear && sale.cancelledAt === null;
        });
        break;
      default: // "all" tab
        // Show only active (non-cancelled) sales
        filteredByTab = sales.filter((sale) => sale.cancelledAt === null);
        break;
    }

    // Then apply the additional filters
    return filteredByTab.filter(sale => {
      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesCustomerName = sale.customerName?.toLowerCase().includes(query);
        const matchesCustomerMobile = sale.customerMobile?.toLowerCase().includes(query);
        const matchesPlotNo = sale.plotNo?.toLowerCase().includes(query);
        
        if (!matchesCustomerName && !matchesCustomerMobile && !matchesPlotNo) {
          return false;
        }
      }

      // Date range filter
      if (filters.startDate && filters.endDate) {
        const saleDate = new Date(sale.bookingDate);
        const startDate = new Date(filters.startDate);
        const endDate = new Date(filters.endDate);
        // Set end date to end of day for inclusive filtering
        endDate.setHours(23, 59, 59, 999);
        
        if (saleDate < startDate || saleDate > endDate) {
          return false;
        }
      } else if (filters.startDate) {
        const saleDate = new Date(sale.bookingDate);
        const startDate = new Date(filters.startDate);
        if (saleDate < startDate) {
          return false;
        }
      } else if (filters.endDate) {
        const saleDate = new Date(sale.bookingDate);
        const endDate = new Date(filters.endDate);
        endDate.setHours(23, 59, 59, 999);
        if (saleDate > endDate) {
          return false;
        }
      }

      // Sales executive filter
      if (filters.salesExecutiveId && sale.salesExecutiveId !== filters.salesExecutiveId) {
        return false;
      }

      // Project filter
      if (filters.projectId && sale.projectId !== filters.projectId) {
        return false;
      }

      return true;
    });
  };

  // Clear forms when dialogs close
  useEffect(() => {
    if (!isCreateDialogOpen) {
      createForm.reset({
        bookingDate: format(new Date(), "yyyy-MM-dd"),
        salesExecutiveId: undefined,
        projectId: undefined,
        customerName: "",
        customerMobile: "",
        areaSold: undefined,
        baseSalePrice: undefined,
      });
    }
  }, [isCreateDialogOpen, createForm]);

  useEffect(() => {
    if (!isPaymentDialogOpen) {
      setPaymentTab("view-payments");
      paymentForm.reset({
        paymentDate: format(new Date(), "yyyy-MM-dd"),
        amount: undefined,
        paymentType: "",
        paymentMode: "",
        remarks: "",
      });
    }
  }, [isPaymentDialogOpen, paymentForm]);

  // Sales data table component
  const SalesTable = ({ sales }: { sales: Sales[] }) => (
    <div className="rounded-md border overflow-hidden">
      <Table className="border-collapse">
        <TableCaption className="text-gray-500 mt-4">
          {sales.length === 0 
            ? "No sales records found" 
            : `Showing ${sales.length} sales record${sales.length !== 1 ? 's' : ''}`}
        </TableCaption>
        <TableHeader>
          <TableRow className="bg-gray-50 hover:bg-gray-50">
            <TableHead className="font-medium text-gray-900 w-[100px]">Booking Date</TableHead>
            <TableHead className="font-medium text-gray-900 w-[120px] ml-[0px] mr-[0px] mt-[0px] mb-[0px] pl-[30px] pr-[30px]">Project</TableHead>
            <TableHead className="font-medium text-gray-900 w-[140px]">Sales Executive</TableHead>
            <TableHead className="font-medium text-gray-900 w-[160px]">Customer Name</TableHead>
            <TableHead className="font-medium text-gray-900 w-[80px]">Agreement Status</TableHead>
            <TableHead className="font-medium text-gray-900 text-right w-[90px]">Area (sq. ft.)</TableHead>
            <TableHead className="font-medium text-gray-900 text-right w-[100px]">BSP (per sq. ft.)</TableHead>
            <TableHead className="font-medium text-gray-900 text-right w-[120px]">Final Amount</TableHead>
            <TableHead className="text-right font-medium text-gray-900 w-[140px]">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sales.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center h-24 text-gray-500">
                <div className="flex flex-col items-center justify-center">
                  <FileText className="h-8 w-8 text-gray-300 mb-2" />
                  <p>No sales records found</p>
                  <p className="text-sm text-gray-400 mt-1">Try adjusting your filters</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            sales.map((sale, index) => (
              <TableRow 
                key={sale.id} 
                className={`relative ${
                  sale.cancelledAt 
                    ? "bg-red-50 border-red-200 hover:bg-red-100" 
                    : index % 2 === 0 ? "bg-white" : "bg-gray-50/50"
                }`}
              >
                <TableCell className="font-medium w-[100px]">
                  <div className="truncate" title={sale.bookingDate ? format(new Date(sale.bookingDate), "MMM d, yyyy") : "-"}>
                    {sale.bookingDate ? format(new Date(sale.bookingDate), "MMM d, yyyy") : "-"}
                  </div>
                </TableCell>
                <TableCell className="w-[120px]">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="px-2 py-1 h-auto font-normal flex items-center gap-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 w-full justify-start"
                    onClick={() => {
                      setFilters({...filters, projectId: sale.projectId});
                    }}
                    title={sale.projectId ? getProjectName(sale.projectId) : "-"}
                  >
                    <span className="truncate">{sale.projectId ? getProjectName(sale.projectId) : "-"}</span>
                    <Filter className="h-3 w-3 ml-1 opacity-60 flex-shrink-0" />
                  </Button>
                </TableCell>
                <TableCell className="w-[140px]">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="px-2 py-1 h-auto font-normal flex items-center gap-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 w-full justify-start"
                    onClick={() => {
                      setFilters({...filters, salesExecutiveId: sale.salesExecutiveId});
                    }}
                    title={sale.salesExecutiveId ? getUserName(sale.salesExecutiveId) : "-"}
                  >
                    <span className="truncate">{sale.salesExecutiveId ? getUserName(sale.salesExecutiveId) : "-"}</span>
                    <Filter className="h-3 w-3 ml-1 opacity-60 flex-shrink-0" />
                  </Button>
                </TableCell>
                <TableCell className="w-[160px]" title={sale.customerName || "-"}>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></span>
                    <span className="truncate">{sale.customerName || "-"}</span>
                  </div>
                </TableCell>
                <TableCell className="w-[80px]">
                  <div className="relative">
                    {sale.cancelledAt ? (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800">
                        No
                      </span>
                    ) : (
                      <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium ${
                        sale.bookingDone === "Yes" 
                          ? "bg-green-100 text-green-800" 
                          : sale.bookingDone === "No" 
                            ? "bg-amber-100 text-amber-800" 
                            : "bg-gray-100 text-gray-800"
                      }`}>
                        {sale.bookingDone || "No"}
                        {sale.bookingDone === "No" && sale.bookingData && (
                          <span className="ml-1 text-xs">*</span>
                        )}
                      </span>
                    )}
                    {sale.bookingDone === "No" && sale.bookingData && !sale.cancelledAt && (
                      <div className="text-xs text-amber-600 truncate mt-1" title={sale.bookingData}>
                        {sale.bookingData.length > 10 ? `${sale.bookingData.substring(0, 10)}...` : sale.bookingData}
                      </div>
                    )}
                  </div>
                  {sale.cancelledAt && (
                    <div className="absolute top-1 right-1 z-10">
                      <span className="inline-flex items-center px-1 py-1 rounded text-xs font-semibold bg-red-600 text-white shadow-lg">
                        <Ban className="h-3 w-3 mr-1" />
                        CANCELLED
                      </span>
                    </div>
                  )}
                </TableCell>
                <TableCell className="text-right font-medium w-[90px]">
                  {sale.areaSold ? Number(sale.areaSold).toLocaleString() : "0"}
                </TableCell>
                <TableCell className="text-right w-[100px]">
                  ₹{sale.baseSalePrice ? Number(sale.baseSalePrice).toLocaleString() : "0"}
                </TableCell>
                <TableCell className="text-right font-medium text-purple-800 w-[120px]">
                  ₹{(sale.finalAmount 
                    ? Number(sale.finalAmount) 
                    : (sale.areaSold && sale.baseSalePrice 
                      ? Number(sale.areaSold) * Number(sale.baseSalePrice) 
                      : 0)
                  ).toLocaleString()}
                </TableCell>
                <TableCell className="text-right w-[140px]">
                  <div className="flex justify-end gap-1">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center gap-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors" 
                      onClick={() => handleViewPayments(sale)}
                    >
                      <CreditCard className="h-4 w-4" />
                      <span className="hidden sm:inline">Payment</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center gap-1 text-amber-600 hover:text-amber-800 hover:bg-amber-50 transition-colors" 
                      onClick={() => handleEdit(sale)}
                    >
                      <Edit className="h-4 w-4" />
                      <span className="hidden sm:inline">Edit</span>
                    </Button>
                    {!(sale as any).isCancelled && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex items-center gap-1 text-orange-600 hover:text-orange-800 hover:bg-orange-50 transition-colors" 
                        onClick={() => handleCancel(sale)}
                      >
                        <Ban className="h-4 w-4" />
                        <span className="hidden sm:inline">Cancel</span>
                      </Button>
                    )}
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center gap-1 text-red-600 hover:text-red-800 hover:bg-red-50 transition-colors" 
                      onClick={() => handleDelete(sale)}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="hidden sm:inline">Delete</span>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 flex items-center">
            <FileText className="h-8 w-8 mr-3 text-primary" />
            Sales Management
          </h1>
          <p className="text-gray-500 mt-1">Track and manage your sales activities</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input 
              type="text" 
              placeholder="Search by customer name..." 
              className="pl-9 pr-4 py-2 w-full sm:w-auto rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button 
            onClick={() => setIsCreateDialogOpen(true)}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            Add New Sale
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 lg:gap-6">
        <Card className="border-l-4 border-l-blue-500 shadow-md hover:shadow-lg transition-shadow h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm md:text-base font-medium flex items-center">
              <FileText className="h-4 w-4 md:h-5 md:w-5 mr-2 text-blue-500 flex-shrink-0" />
              <span className="truncate">Total Sales</span>
            </CardTitle>
            <CardDescription className="text-xs md:text-sm truncate">Across filtered period</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-xl md:text-2xl lg:text-3xl font-bold text-blue-600 break-words">
              {filteredSales().length}
            </div>
            <p className="text-xs md:text-sm text-muted-foreground mt-1 line-clamp-1">
              Total sales records
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500 shadow-md hover:shadow-lg transition-shadow h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm md:text-base font-medium flex items-center">
              <CalendarIcon className="h-4 w-4 md:h-5 md:w-5 mr-2 text-green-500 flex-shrink-0" />
              <span className="truncate">This Month</span>
            </CardTitle>
            <CardDescription className="text-xs md:text-sm truncate">Sales for current month</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-xl md:text-2xl lg:text-3xl font-bold text-green-600 break-words">
              {filteredSales().filter(sale => {
                const saleDate = new Date(sale.bookingDate);
                const currentDate = new Date();
                return saleDate.getMonth() === currentDate.getMonth() &&
                       saleDate.getFullYear() === currentDate.getFullYear();
              }).length}
            </div>
            <p className="text-xs md:text-sm text-muted-foreground mt-1 line-clamp-1">
              {format(new Date(), "MMM yyyy")}
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500 shadow-md hover:shadow-lg transition-shadow h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm md:text-base font-medium flex items-center">
              <RefreshCw className="h-4 w-4 md:h-5 md:w-5 mr-2 text-amber-500 flex-shrink-0" />
              <span className="truncate">Total Area Sold</span>
            </CardTitle>
            <CardDescription className="text-xs md:text-sm truncate">Square feet coverage</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-lg md:text-xl lg:text-2xl xl:text-3xl font-bold text-amber-600 break-words">
              {filteredSales().reduce((total, sale) => 
                total + (sale.areaSold ? Number(sale.areaSold) : 0), 0
              ).toLocaleString()}
            </div>
            <p className="text-xs md:text-sm text-muted-foreground mt-1 line-clamp-1">
              sq. ft. of property
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500 shadow-md hover:shadow-lg transition-shadow h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm md:text-base font-medium flex items-center">
              <DollarSign className="h-4 w-4 md:h-5 md:w-5 mr-2 text-purple-500 flex-shrink-0" />
              <span className="truncate">Total Revenue</span>
            </CardTitle>
            <CardDescription className="text-xs md:text-sm truncate">Final amount from sales</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-sm md:text-lg lg:text-xl xl:text-2xl font-bold text-purple-600 break-words">
              ₹{filteredSales().reduce((total, sale) => {
                const amount = sale.finalAmount 
                  ? Number(sale.finalAmount) 
                  : (sale.areaSold && sale.baseSalePrice ? Number(sale.areaSold) * Number(sale.baseSalePrice) : 0);
                return total + amount;
              }, 0).toLocaleString()}
            </div>
            <p className="text-xs md:text-sm text-muted-foreground mt-1 line-clamp-1">
              Based on final amounts
            </p>
          </CardContent>
        </Card>
      </div>
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 bg-white p-4 rounded-lg shadow-sm border border-gray-100">
          <TabsList className="bg-gray-100">
            <TabsTrigger value="all" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              All Sales
            </TabsTrigger>
            <TabsTrigger value="this-month" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              This Month
            </TabsTrigger>
            <TabsTrigger value="this-year" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              This Year
            </TabsTrigger>
            <TabsTrigger value="cancelled" className="data-[state=active]:bg-white data-[state=active]:shadow-sm text-red-600">
              Cancelled Bookings
            </TabsTrigger>
          </TabsList>
          <div className="flex items-center space-x-2">
            <div className="relative text-sm text-gray-500 mr-2">
              {filters.startDate || filters.endDate || filters.salesExecutiveId > 0 || filters.projectId > 0 ? (
                <span className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs font-medium">
                  Filters Applied
                </span>
              ) : null}
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsFilterDialogOpen(true)}
              className="bg-white hover:bg-gray-50 border-gray-200"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            
            {/* Clear Filter Button */}
            {(filters.startDate || filters.endDate || filters.salesExecutiveId > 0 || filters.projectId > 0) && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => {
                  setFilters({
                    startDate: "",
                    endDate: "",
                    salesExecutiveId: 0,
                    projectId: 0,
                  });
                }}
                className="hover:bg-gray-50 text-gray-500"
              >
                <X className="h-4 w-4 mr-2" />
                Clear
              </Button>
            )}
          </div>
        </div>

        <TabsContent value="all">
          <Card className="border-0 shadow-none p-0">
            <CardContent className="p-0">
              <SalesTable sales={filteredSales()} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="this-month">
          <Card className="border-0 shadow-none p-0">
            <CardContent className="p-0">
              <SalesTable sales={filteredSales()} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="this-year">
          <Card className="border-0 shadow-none p-0">
            <CardContent className="p-0">
              <SalesTable sales={filteredSales()} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cancelled">
          <Card className="border-0 shadow-none p-0">
            <CardContent className="p-0">
              <SalesTable sales={filteredSales()} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      {/* Create Sale Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center text-xl">
              <Plus className="h-5 w-5 mr-2 text-primary" />
              Create New Sale
            </DialogTitle>
            <DialogDescription>Fill in the details to create a new sale entry.</DialogDescription>
          </DialogHeader>
          
          <Form {...createForm}>
            <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-6">
                  <div className="bg-gray-50 p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-800 mb-3 flex items-center">
                      <CreditCard className="h-4 w-4 mr-2 text-primary" />
                      Customer & Executive Information
                    </h3>
                    <div className="space-y-4">
                      <FormField
                        control={createForm.control}
                        name="customerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Customer Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter customer name" className="bg-white" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createForm.control}
                        name="customerMobile"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Customer Mobile</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter mobile number" className="bg-white" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createForm.control}
                        name="salesExecutiveId"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Sales Executive</FormLabel>
                            <FormControl>
                              <div className="bg-white border rounded-md p-2 max-h-[180px] overflow-y-auto">
                                <RadioGroup
                                  onValueChange={(value) => field.onChange(parseInt(value))}
                                  value={field.value?.toString() || ""}
                                  className="flex flex-col space-y-1"
                                >
                                  {users.map((user) => (
                                    <div key={user.id} className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                      <RadioGroupItem value={user.id.toString()} id={`user-${user.id}`} />
                                      <Label htmlFor={`user-${user.id}`} className="cursor-pointer w-full">
                                        {user.fullName || `User ${user.id}`}
                                      </Label>
                                    </div>
                                  ))}
                                </RadioGroup>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-800 mb-3 flex items-center">
                      <CalendarIcon className="h-4 w-4 mr-2 text-primary" />
                      Project & Booking Information
                    </h3>
                    <div className="space-y-4">
                      <DatePickerFormField form={createForm} name="bookingDate" label="Booking Date" />
                      
                      <FormField
                        control={createForm.control}
                        name="bookingDone"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Agreement Done or Not</FormLabel>
                            <FormControl>
                              <div className="bg-white border rounded-md p-2">
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  value={field.value || "No"}
                                  className="flex space-x-4"
                                  defaultValue="No"
                                >
                                  <div className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                    <RadioGroupItem value="Yes" id="create-booking-done-yes" />
                                    <Label htmlFor="create-booking-done-yes" className="cursor-pointer">
                                      Yes
                                    </Label>
                                  </div>
                                  <div className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                    <RadioGroupItem value="No" id="create-booking-done-no" />
                                    <Label htmlFor="create-booking-done-no" className="cursor-pointer">
                                      No
                                    </Label>
                                  </div>
                                </RadioGroup>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {createForm.watch("bookingDone") === "Yes" && (
                        <DatePickerFormField form={createForm} name="agreementDate" label="Agreement Date" />
                      )}
                      

                      
                      <FormField
                        control={createForm.control}
                        name="projectId"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Project</FormLabel>
                            <FormControl>
                              <div className="bg-white border rounded-md p-2 max-h-[180px] overflow-y-auto">
                                <RadioGroup
                                  onValueChange={(value) => field.onChange(parseInt(value))}
                                  value={field.value?.toString() || ""}
                                  className="flex flex-col space-y-1"
                                >
                                  {projects.map((project) => (
                                    <div key={project.id} className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                      <RadioGroupItem value={project.id.toString()} id={`project-${project.id}`} />
                                      <Label htmlFor={`project-${project.id}`} className="cursor-pointer w-full">
                                        {project.name}
                                      </Label>
                                    </div>
                                  ))}
                                </RadioGroup>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="bg-gray-50 p-4 rounded-lg border h-full">
                    <h3 className="text-sm font-medium text-gray-800 mb-3 flex items-center">
                      <DollarSign className="h-4 w-4 mr-2 text-primary" />
                      Financial Details
                    </h3>
                    <div className="space-y-4">
                      <FormField
                        control={createForm.control}
                        name="areaSold"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Area Sold (sq. ft.)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="0" 
                                className="bg-white" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createForm.control}
                        name="baseSalePrice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Base Sale Price (per sq. ft.)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  className="bg-white pl-7" 
                                  {...field} 
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createForm.control}
                        name="developmentCharges"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>DC (Development Charges)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  className="bg-white pl-7" 
                                  {...field} 
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createForm.control}
                        name="preferredLocationCharge"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PLC (Preferred Location Charge)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  className="bg-white pl-7" 
                                  {...field} 
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createForm.control}
                        name="plotNo"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Plot No</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter plot number" 
                                className="bg-white" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="pt-4 border-t mt-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-gray-700">Total Revenue:</span>
                          <span className="text-lg font-bold text-primary">
                            ₹{((createForm.watch("areaSold") || 0) * (createForm.watch("baseSalePrice") || 0)).toLocaleString()}
                          </span>
                        </div>
                        <div className="bg-white p-3 rounded-md border border-dashed border-primary/30">
                          <div className="text-xs text-gray-500 mb-1">Revenue Calculation</div>
                          <div className="flex items-center justify-center gap-2 text-sm">
                            <span className="font-medium">{createForm.watch("areaSold") || 0} sq. ft.</span>
                            <span>×</span>
                            <span className="font-medium">₹{createForm.watch("baseSalePrice") || 0}/sq. ft.</span>
                            <span>=</span>
                            <span className="font-bold text-primary">₹{((createForm.watch("areaSold") || 0) * (createForm.watch("baseSalePrice") || 0)).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <DialogFooter className="pt-2 border-t">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)} 
                  className="border-gray-200"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createSaleMutation.isPending}
                  className="gap-2"
                >
                  {createSaleMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      Save Sale
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      {/* Edit Sale Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center text-xl">
              <Edit className="h-5 w-5 mr-2 text-amber-500" />
              Edit Sale
            </DialogTitle>
            <DialogDescription>Update sale details to keep records accurate.</DialogDescription>
          </DialogHeader>
          
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-6">
                  <div className="bg-amber-50/50 p-4 rounded-lg border border-amber-100">
                    <h3 className="text-sm font-medium text-amber-800 mb-3 flex items-center">
                      <CreditCard className="h-4 w-4 mr-2 text-amber-500" />
                      Customer & Executive Information
                    </h3>
                    <div className="space-y-4">
                      <FormField
                        control={editForm.control}
                        name="customerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Customer Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter customer name" className="bg-white" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={editForm.control}
                        name="customerMobile"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Customer Mobile</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter mobile number" className="bg-white" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={editForm.control}
                        name="salesExecutiveId"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Sales Executive</FormLabel>
                            <FormControl>
                              <div className="bg-white border rounded-md p-2 max-h-[180px] overflow-y-auto">
                                <RadioGroup
                                  onValueChange={(value) => field.onChange(parseInt(value))}
                                  value={field.value?.toString() || ""}
                                  className="flex flex-col space-y-1"
                                >
                                  {users.map((user) => (
                                    <div key={user.id} className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                      <RadioGroupItem value={user.id.toString()} id={`edit-user-${user.id}`} />
                                      <Label htmlFor={`edit-user-${user.id}`} className="cursor-pointer w-full">
                                        {user.fullName || `User ${user.id}`}
                                      </Label>
                                    </div>
                                  ))}
                                </RadioGroup>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="bg-amber-50/50 p-4 rounded-lg border border-amber-100">
                    <h3 className="text-sm font-medium text-amber-800 mb-3 flex items-center">
                      <CalendarIcon className="h-4 w-4 mr-2 text-amber-500" />
                      Project & Booking Information
                    </h3>
                    <div className="space-y-4">
                      <DatePickerFormField form={editForm} name="bookingDate" label="Booking Date" />
                      
                      <FormField
                        control={editForm.control}
                        name="bookingDone"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Agreement Done or Not</FormLabel>
                            <FormControl>
                              <div className="bg-white border rounded-md p-2">
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  value={field.value || "No"}
                                  className="flex space-x-4"
                                  defaultValue="No"
                                >
                                  <div className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                    <RadioGroupItem value="Yes" id="edit-booking-done-yes" />
                                    <Label htmlFor="edit-booking-done-yes" className="cursor-pointer">
                                      Yes
                                    </Label>
                                  </div>
                                  <div className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                    <RadioGroupItem value="No" id="edit-booking-done-no" />
                                    <Label htmlFor="edit-booking-done-no" className="cursor-pointer">
                                      No
                                    </Label>
                                  </div>
                                </RadioGroup>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {editForm.watch("bookingDone") === "Yes" && (
                        <DatePickerFormField form={editForm} name="agreementDate" label="Agreement Date" />
                      )}
                      

                      
                      <FormField
                        control={editForm.control}
                        name="projectId"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Project</FormLabel>
                            <FormControl>
                              <div className="bg-white border rounded-md p-2 max-h-[180px] overflow-y-auto">
                                <RadioGroup
                                  onValueChange={(value) => field.onChange(parseInt(value))}
                                  value={field.value?.toString() || ""}
                                  className="flex flex-col space-y-1"
                                >
                                  {projects.map((project) => (
                                    <div key={project.id} className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                      <RadioGroupItem value={project.id.toString()} id={`edit-project-${project.id}`} />
                                      <Label htmlFor={`edit-project-${project.id}`} className="cursor-pointer w-full">
                                        {project.name}
                                      </Label>
                                    </div>
                                  ))}
                                </RadioGroup>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="bg-amber-50/50 p-4 rounded-lg border border-amber-100 h-full">
                    <h3 className="text-sm font-medium text-amber-800 mb-3 flex items-center">
                      <DollarSign className="h-4 w-4 mr-2 text-amber-500" />
                      Financial Details
                    </h3>
                    <div className="space-y-4">
                      <FormField
                        control={editForm.control}
                        name="areaSold"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Area Sold (sq. ft.)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="0" 
                                className="bg-white" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={editForm.control}
                        name="baseSalePrice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Base Sale Price (per sq. ft.)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  className="bg-white pl-7" 
                                  {...field} 
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={editForm.control}
                        name="developmentCharges"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>DC (Development Charges)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  className="bg-white pl-7" 
                                  {...field} 
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={editForm.control}
                        name="preferredLocationCharge"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PLC (Preferred Location Charge)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  className="bg-white pl-7" 
                                  {...field} 
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={editForm.control}
                        name="plotNo"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Plot No</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter plot number" 
                                className="bg-white" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="pt-4 border-t mt-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-gray-700">Total Revenue:</span>
                          <span className="text-lg font-bold text-amber-600">
                            ₹{((editForm.watch("areaSold") || 0) * (editForm.watch("baseSalePrice") || 0)).toLocaleString()}
                          </span>
                        </div>
                        <div className="bg-white p-3 rounded-md border border-dashed border-amber-200">
                          <div className="text-xs text-gray-500 mb-1">Revenue Calculation</div>
                          <div className="flex items-center justify-center gap-2 text-sm">
                            <span className="font-medium">{editForm.watch("areaSold") || 0} sq. ft.</span>
                            <span>×</span>
                            <span className="font-medium">₹{editForm.watch("baseSalePrice") || 0}/sq. ft.</span>
                            <span>=</span>
                            <span className="font-bold text-amber-600">₹{((editForm.watch("areaSold") || 0) * (editForm.watch("baseSalePrice") || 0)).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <DialogFooter className="pt-2 border-t">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                  className="border-gray-200"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateSaleMutation.isPending}
                  className="gap-2 bg-amber-600 hover:bg-amber-700"
                >
                  {updateSaleMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Edit className="h-4 w-4" />
                      Update Sale
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="max-w-4xl h-[85vh] max-h-[750px] flex flex-col p-0 gap-0 overflow-hidden">
          {/* Customer Header Banner */}
          {currentSale && (
            <div className="bg-gradient-to-r from-primary/90 to-primary/70 p-6 flex flex-col sm:flex-row justify-between">
              <div className="flex-1">
                <h2 className="text-2xl font-bold flex items-center text-black">
                  <div className="bg-white rounded-full p-2 mr-3 text-primary">
                    <CreditCard className="h-6 w-6" />
                  </div>
                  {currentSale.customerName}
                </h2>
                <p className="text-black text-sm mt-1 font-medium">Customer Ledger & Payment Management</p>
              </div>
              <div className="flex items-center mt-4 sm:mt-0">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="bg-white/80 text-primary border-white/80 hover:bg-white hover:text-primary hover:border-white"
                  onClick={() => setIsPaymentDialogOpen(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
          
          <div className="flex flex-1 overflow-hidden">
            {/* Left Sidebar - Customer Details */}
            {currentSale && (
              <div className="hidden md:block w-[260px] p-6 border-r bg-gray-50/50 overflow-y-auto space-y-6">
                <div>
                  <h3 className="text-sm font-semibold text-gray-500 mb-2 flex items-center">
                    <FileText className="h-4 w-4 mr-2 text-primary" />
                    SALE DETAILS
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-gray-500">Project</p>
                      <p className="font-medium">{currentSale.projectId ? getProjectName(currentSale.projectId) : "-"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Sales Executive</p>
                      <p className="font-medium">{currentSale.salesExecutiveId ? getUserName(currentSale.salesExecutiveId) : "-"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Booking Date</p>
                      <p className="font-medium">{currentSale.bookingDate ? format(new Date(currentSale.bookingDate), "PPP") : "-"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Agreement Status</p>
                      <div className="mt-1">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          currentSale.bookingDone === "Yes" 
                            ? "bg-green-100 text-green-800" 
                            : currentSale.bookingDone === "No" 
                              ? "bg-amber-100 text-amber-800" 
                              : "bg-gray-100 text-gray-800"
                        }`}>
                          {currentSale.bookingDone || "Not Specified"}
                        </span>
                        {currentSale.bookingDone === "Yes" && currentSale.agreementDate && (
                          <p className="text-xs text-green-600 mt-1">
                            Agreement Date: {format(new Date(currentSale.agreementDate), "PP")}
                          </p>
                        )}
                        {currentSale.bookingDone === "No" && currentSale.bookingData && (
                          <p className="text-xs text-amber-600 mt-1">
                            {currentSale.bookingData}
                          </p>
                        )}
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <p className="text-xs text-gray-500">Area Sold</p>
                      <p className="font-medium">{currentSale.areaSold ? Number(currentSale.areaSold).toLocaleString() : "0"} sq. ft.</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Base Sale Price</p>
                      <p className="font-medium">₹{currentSale.baseSalePrice ? Number(currentSale.baseSalePrice).toLocaleString() : "0"} / sq. ft.</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">DC (Development Charges)</p>
                      <p className="font-medium">₹{(currentSale as any).developmentCharges ? Number((currentSale as any).developmentCharges).toLocaleString() : "0"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">PLC (Preferred Location Charge)</p>
                      <p className="font-medium">₹{(currentSale as any).preferredLocationCharge ? Number((currentSale as any).preferredLocationCharge).toLocaleString() : "0"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Plot No</p>
                      <p className="font-medium">{(currentSale as any).plotNo || "-"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Final Amount</p>
                      <p className="font-medium text-primary">₹{(currentSale.finalAmount ? Number(currentSale.finalAmount) : (currentSale.areaSold && currentSale.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 0)).toLocaleString()}</p>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-sm font-semibold text-gray-500 mb-2 flex items-center">
                    <CreditCard className="h-4 w-4 mr-2 text-primary" />
                    PAYMENT SUMMARY
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-gray-500">Total Payments</p>
                      <p className="font-medium text-green-600">₹{calculateTotalPayments().toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Remaining Balance</p>
                      <p className="font-medium text-amber-600">₹{Math.max(0, (currentSale.finalAmount ? Number(currentSale.finalAmount) : (currentSale.areaSold && currentSale.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 0)) - calculateTotalPayments()).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Payment Progress</p>
                      <div className="mt-1 w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-primary h-2.5 rounded-full" 
                          style={{ width: `${Math.min(100, Math.round((calculateTotalPayments() / (currentSale.finalAmount ? Number(currentSale.finalAmount) : (currentSale.areaSold && currentSale.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 1))) * 100))}%` }}
                        ></div>
                      </div>
                      <p className="text-right text-xs mt-1 font-medium">
                        {Math.min(100, Math.round((calculateTotalPayments() / (currentSale.finalAmount ? Number(currentSale.finalAmount) : (currentSale.areaSold && currentSale.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 1))) * 100))}%
                      </p>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-sm font-semibold text-gray-500 mb-2 flex items-center">
                    <RefreshCw className="h-4 w-4 mr-2 text-primary" />
                    PAYMENT ACTIONS
                  </h3>
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => setPaymentTab("view-payments")}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      View Payment History
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => setPaymentTab("add-payment")}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Record New Payment
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start text-primary border-primary/30 hover:bg-primary/5"
                      disabled
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Generate Statement
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {/* Main Content */}
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Mobile Summary (collapsed version of left sidebar for small screens) */}
              {currentSale && (
                <div className="md:hidden bg-gray-50/50 p-4 border-b">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-500">Project</p>
                      <p className="font-medium truncate">{currentSale.projectId ? getProjectName(currentSale.projectId) : "-"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Final Amount</p>
                      <p className="font-medium text-primary">₹{(currentSale.finalAmount ? Number(currentSale.finalAmount) : (currentSale.areaSold && currentSale.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 0)).toLocaleString()}</p>
                    </div>
                  </div>
                  
                  <div className="mt-3">
                    <div className="flex justify-between text-xs mb-1">
                      <span>Payment Progress</span>
                      <span className="font-medium">
                        {Math.min(100, Math.round((calculateTotalPayments() / (currentSale.finalAmount ? Number(currentSale.finalAmount) : (currentSale.areaSold && currentSale.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 1))) * 100))}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div 
                        className="bg-primary h-1.5 rounded-full" 
                        style={{ width: `${Math.min(100, Math.round((calculateTotalPayments() / (currentSale.finalAmount ? Number(currentSale.finalAmount) : (currentSale.areaSold && currentSale.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 1))) * 100))}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Tabs */}
              <div className="border-b flex">
                <button 
                  className={`flex-1 py-3 px-4 text-center font-medium text-sm flex justify-center items-center ${paymentTab === "view-payments" ? "border-b-2 border-primary text-primary" : "text-gray-500"}`}
                  onClick={() => setPaymentTab("view-payments")}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Payment History
                </button>
                <button 
                  className={`flex-1 py-3 px-4 text-center font-medium text-sm flex justify-center items-center ${paymentTab === "add-payment" ? "border-b-2 border-primary text-primary" : "text-gray-500"}`}
                  onClick={() => setPaymentTab("add-payment")}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Payment
                </button>
              </div>
              
              {/* Tab Content */}
              <div className="flex-1 overflow-y-auto p-6">
                {paymentTab === "view-payments" ? (
                  payments.length === 0 ? (
                    <div className="py-12 text-center">
                      <div className="bg-gray-50 rounded-full h-20 w-20 flex items-center justify-center mx-auto mb-4">
                        <CreditCard className="h-8 w-8 text-gray-300" />
                      </div>
                      <h3 className="text-lg font-medium mb-2">No payments recorded yet</h3>
                      <p className="text-muted-foreground mb-6 max-w-md mx-auto">This customer hasn't made any payments against this sale yet. Record their first payment to get started.</p>
                      <Button 
                        onClick={() => setPaymentTab("add-payment")}
                        className="gap-2"
                      >
                        <Plus className="h-4 w-4" />
                        Add First Payment
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="mb-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <Card className="border-l-4 border-l-green-500">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base font-medium flex items-center">
                              <DollarSign className="h-5 w-5 mr-2 text-green-500" />
                              Total Paid
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold text-green-600">
                              ₹{calculateTotalPayments().toLocaleString()}
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              Across {payments.length} payment{payments.length !== 1 ? 's' : ''}
                            </p>
                          </CardContent>
                        </Card>
                        
                        <Card className="border-l-4 border-l-blue-500">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base font-medium flex items-center">
                              <AlertCircle className="h-5 w-5 mr-2 text-blue-500" />
                              Balance Due
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold text-blue-600">
                              ₹{Math.max(0, (currentSale?.finalAmount ? Number(currentSale.finalAmount) : (currentSale?.areaSold && currentSale?.baseSalePrice ? Number(currentSale.areaSold) * Number(currentSale.baseSalePrice) : 0)) - calculateTotalPayments()).toLocaleString()}
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              Remaining to be collected
                            </p>
                          </CardContent>
                        </Card>
                        
                        <Card className="border-l-4 border-l-blue-500">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base font-medium flex items-center">
                              <RefreshCw className="h-5 w-5 mr-2 text-blue-500" />
                              Last Payment
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold text-blue-600">
                              {payments.length > 0 ? format(new Date(payments[0].paymentDate), "MMM d, yyyy") : "-"}
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              {payments.length > 0 ? `${payments[0].paymentType} (₹${Number(payments[0].amount).toLocaleString()})` : "No payments yet"}
                            </p>
                          </CardContent>
                        </Card>
                      </div>
                      
                      <div className="rounded-md border overflow-hidden">
                        <Table className="border-collapse">
                          <TableHeader>
                            <TableRow className="bg-gray-50 hover:bg-gray-50">
                              <TableHead className="font-medium text-gray-900">Date</TableHead>
                              <TableHead className="font-medium text-gray-900">Amount</TableHead>
                              <TableHead className="font-medium text-gray-900">Type</TableHead>
                              <TableHead className="font-medium text-gray-900">Mode</TableHead>
                              <TableHead className="font-medium text-gray-900">Remarks</TableHead>
                              <TableHead className="text-right font-medium text-gray-900">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {payments.map((payment, index) => (
                              <TableRow 
                                key={payment.id}
                                className={index % 2 === 0 ? "bg-white" : "bg-gray-50/50"}
                              >
                                <TableCell className="font-medium">
                                  {payment.paymentDate ? format(new Date(payment.paymentDate), "MMM d, yyyy") : "-"}
                                </TableCell>
                                <TableCell className="font-medium text-green-600">
                                  ₹{payment.amount ? Number(payment.amount).toLocaleString() : "0"}
                                </TableCell>
                                <TableCell>
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    {payment.paymentType || "-"}
                                  </span>
                                </TableCell>
                                <TableCell>{payment.paymentMode || "-"}</TableCell>
                                <TableCell className="max-w-[150px] truncate">
                                  {payment.remarks || "-"}
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="text-amber-600 hover:bg-amber-50 hover:text-amber-800 transition-colors border-amber-200"
                                    onClick={() => handleEditPayment(payment)}
                                  >
                                    <Edit className="h-3.5 w-3.5 mr-1" />
                                    Edit
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </>
                  )
                ) : (
                  <div className="max-w-2xl mx-auto">
                    <div className="bg-gray-50 border rounded-lg p-6 mb-6">
                      <h3 className="font-medium text-lg mb-2 flex items-center">
                        <Plus className="h-5 w-5 mr-2 text-primary" />
                        Record New Payment
                      </h3>
                      <p className="text-sm text-gray-500 mb-0">
                        Add a new payment from the customer for this sale. Make sure to include the payment type and mode.
                      </p>
                    </div>
                  
                    <Form {...paymentForm}>
                      <form onSubmit={paymentForm.handleSubmit(onAddPaymentSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-6">
                            <DatePickerFormField form={paymentForm} name="paymentDate" label="Payment Date" />
                            
                            <FormField
                              control={paymentForm.control}
                              name="amount"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Amount</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                                      <Input type="number" placeholder="0" className="pl-7" {...field} />
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={paymentForm.control}
                              name="remarks"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Remarks</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Optional remarks" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            

                          </div>
                          
                          <div className="space-y-6">
                            <FormField
                              control={paymentForm.control}
                              name="paymentType"
                              render={({ field }) => (
                                <FormItem className="space-y-3">
                                  <FormLabel>Payment Type</FormLabel>
                                  <FormControl>
                                    <div className="bg-white border rounded-md p-2 max-h-[180px] overflow-y-auto">
                                      <RadioGroup
                                        onValueChange={field.onChange}
                                        value={field.value || ""}
                                        className="flex flex-col space-y-1"
                                      >
                                        {["EMI", "Advance", "Booking", "Token", "Loan Disbursement", "DC", "PLC"].map((type) => (
                                          <div key={type} className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                            <RadioGroupItem value={type} id={`payment-type-${type}`} />
                                            <Label htmlFor={`payment-type-${type}`} className="cursor-pointer w-full">
                                              {type === "DC" ? "Development Charge" : type}
                                            </Label>
                                          </div>
                                        ))}
                                      </RadioGroup>
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          
                            <FormField
                              control={paymentForm.control}
                              name="paymentMode"
                              render={({ field }) => (
                                <FormItem className="space-y-3">
                                  <FormLabel>Payment Mode</FormLabel>
                                  <FormControl>
                                    <div className="bg-white border rounded-md p-2 max-h-[180px] overflow-y-auto">
                                      <RadioGroup
                                        onValueChange={field.onChange}
                                        value={field.value || ""}
                                        className="flex flex-col space-y-1"
                                      >
                                        {["Cash", "Cheque", "Account Transfer", "UPI", "DD"].map((mode) => (
                                          <div key={mode} className="flex items-center space-x-2 py-1 px-2 hover:bg-gray-50 rounded">
                                            <RadioGroupItem value={mode} id={`payment-mode-${mode.replace(/\s+/g, '-').toLowerCase()}`} />
                                            <Label htmlFor={`payment-mode-${mode.replace(/\s+/g, '-').toLowerCase()}`} className="cursor-pointer w-full">
                                              {mode}
                                            </Label>
                                          </div>
                                        ))}
                                      </RadioGroup>
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <div className="pt-4 flex items-center justify-between border-t">
                          <Button type="button" variant="outline" onClick={() => setPaymentTab("view-payments")}>
                            <FileText className="h-4 w-4 mr-2" />
                            View Payments
                          </Button>
                          <Button type="submit" disabled={addPaymentMutation.isPending} className="gap-2">
                            {addPaymentMutation.isPending ? (
                              <>
                                <RefreshCw className="h-4 w-4 animate-spin" />
                                Adding...
                              </>
                            ) : (
                              <>
                                <Plus className="h-4 w-4" />
                                Add Payment
                              </>
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      {/* Edit Payment Dialog */}
      <Dialog open={isEditPaymentDialogOpen} onOpenChange={setIsEditPaymentDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Edit className="h-5 w-5 mr-2 text-amber-500" />
              Edit Payment
            </DialogTitle>
            <DialogDescription>Update payment information for better record keeping</DialogDescription>
          </DialogHeader>
          
          <div className="bg-amber-50/50 border border-amber-100 rounded-lg p-4 mb-6">
            <h3 className="font-medium text-amber-700 flex items-center text-sm mb-2">
              <AlertCircle className="h-4 w-4 mr-2" />
              Editing Payment Record
            </h3>
            <p className="text-amber-600 text-xs">
              You're modifying an existing payment record. This will be logged in the system audit trail.
            </p>
          </div>
          
          <Form {...editPaymentForm}>
            <form onSubmit={editPaymentForm.handleSubmit(onEditPaymentSubmit)} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-5">
                  <DatePickerFormField form={editPaymentForm} name="paymentDate" label="Payment Date" />
                  
                  <FormField
                    control={editPaymentForm.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                            <Input type="number" placeholder="0" className="pl-7" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="space-y-5">
                  <FormField
                    control={editPaymentForm.control}
                    name="paymentType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Payment Type</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select payment type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="EMI">
                              <div className="flex items-center">
                                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                                EMI
                              </div>
                            </SelectItem>
                            <SelectItem value="Advance">
                              <div className="flex items-center">
                                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                                Advance
                              </div>
                            </SelectItem>
                            <SelectItem value="Booking">
                              <div className="flex items-center">
                                <span className="w-2 h-2 bg-amber-500 rounded-full mr-2"></span>
                                Booking
                              </div>
                            </SelectItem>
                            <SelectItem value="Token">
                              <div className="flex items-center">
                                <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                                Token
                              </div>
                            </SelectItem>
                            <SelectItem value="Loan Disbursement">
                              <div className="flex items-center">
                                <span className="w-2 h-2 bg-indigo-500 rounded-full mr-2"></span>
                                Loan Disbursement
                              </div>
                            </SelectItem>
                            <SelectItem value="DC">
                              <div className="flex items-center">
                                <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                                Development Charge
                              </div>
                            </SelectItem>
                            <SelectItem value="PLC">
                              <div className="flex items-center">
                                <span className="w-2 h-2 bg-pink-500 rounded-full mr-2"></span>
                                PLC
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editPaymentForm.control}
                    name="paymentMode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Payment Mode</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select payment mode" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Cash">
                              <div className="flex items-center">
                                <DollarSign className="h-3.5 w-3.5 mr-2 text-green-500" />
                                Cash
                              </div>
                            </SelectItem>
                            <SelectItem value="Cheque">
                              <div className="flex items-center">
                                <FileText className="h-3.5 w-3.5 mr-2 text-blue-500" />
                                Cheque
                              </div>
                            </SelectItem>
                            <SelectItem value="Account Transfer">
                              <div className="flex items-center">
                                <RefreshCw className="h-3.5 w-3.5 mr-2 text-indigo-500" />
                                Account Transfer
                              </div>
                            </SelectItem>
                            <SelectItem value="UPI">
                              <div className="flex items-center">
                                <CreditCard className="h-3.5 w-3.5 mr-2 text-purple-500" />
                                UPI
                              </div>
                            </SelectItem>
                            <SelectItem value="DD">
                              <div className="flex items-center">
                                <FileText className="h-3.5 w-3.5 mr-2 text-amber-500" />
                                DD
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <FormField
                control={editPaymentForm.control}
                name="remarks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Remarks</FormLabel>
                    <FormControl>
                      <Input placeholder="Optional remarks about this payment" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              

              
              <DialogFooter className="pt-2 gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditPaymentDialogOpen(false)}
                  className="border-gray-200"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={updatePaymentMutation.isPending}
                  className="gap-2 bg-amber-600 hover:bg-amber-700"
                >
                  {updatePaymentMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Edit className="h-4 w-4" />
                      Update Payment
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      {/* Filter Sheet (Full Screen Approach) */}
      <Dialog open={isFilterDialogOpen} onOpenChange={setIsFilterDialogOpen}>
        <DialogContent className="sm:max-w-md p-0 max-h-[90vh] overflow-hidden">
          <div className="p-4 border-b">
            <div className="flex items-center justify-between">
              <DialogTitle className="text-lg font-semibold flex items-center">
                <Filter className="h-5 w-5 mr-2 text-primary" />
                Filter Sales
              </DialogTitle>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsFilterDialogOpen(false)}
                className="h-8 w-8 rounded-full"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <DialogDescription className="mt-1">
              Apply filters to narrow down your sales records
            </DialogDescription>
          </div>
          
          <div className="p-4 overflow-y-auto max-h-[calc(90vh-180px)]">
            {/* Date Range Section */}
            <div className="mb-5">
              <h3 className="text-sm font-semibold text-gray-700 flex items-center mb-3">
                <CalendarIcon className="h-4 w-4 mr-2 text-primary" />
                Date Range
              </h3>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="startDate" className="text-xs font-medium text-gray-600">
                    Start Date
                  </Label>
                  <Input 
                    id="startDate" 
                    type="date" 
                    value={filters.startDate}
                    onChange={(e) => setFilters({...filters, startDate: e.target.value})}
                    className="border-gray-200 h-9"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="endDate" className="text-xs font-medium text-gray-600">
                    End Date
                  </Label>
                  <Input 
                    id="endDate" 
                    type="date" 
                    value={filters.endDate}
                    onChange={(e) => setFilters({...filters, endDate: e.target.value})}
                    className="border-gray-200 h-9"
                  />
                </div>
              </div>
            </div>
            
            <Separator className="my-4" />
            
            {/* Sales Executive Section */}
            <div className="mb-5">
              <h3 className="text-sm font-semibold text-gray-700 flex items-center mb-3">
                <Users className="h-4 w-4 mr-2 text-primary" />
                Sales Executive
              </h3>
              
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                <div className="flex items-center mb-3">
                  <input 
                    type="radio" 
                    id="allExecs" 
                    name="executive"
                    className="h-4 w-4 text-primary border-gray-300"
                    checked={filters.salesExecutiveId === 0}
                    onChange={() => setFilters({...filters, salesExecutiveId: 0})}
                  />
                  <label htmlFor="allExecs" className="ml-2 text-sm text-gray-700">
                    All Executives
                  </label>
                </div>
                
                {users.map((user) => (
                  <div key={user.id} className="flex items-center mb-2">
                    <input 
                      type="radio" 
                      id={`exec-${user.id}`} 
                      name="executive"
                      className="h-4 w-4 text-primary border-gray-300"
                      checked={filters.salesExecutiveId === user.id}
                      onChange={() => setFilters({...filters, salesExecutiveId: user.id})}
                    />
                    <label htmlFor={`exec-${user.id}`} className="ml-2 text-sm text-gray-700 truncate">
                      {user.fullName || `User ${user.id}`}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            <Separator className="my-4" />
            
            {/* Project Section */}
            <div className="mb-2">
              <h3 className="text-sm font-semibold text-gray-700 flex items-center mb-3">
                <DollarSign className="h-4 w-4 mr-2 text-primary" />
                Project
              </h3>
              
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                <div className="flex items-center mb-3">
                  <input 
                    type="radio" 
                    id="allProjects" 
                    name="project"
                    className="h-4 w-4 text-primary border-gray-300"
                    checked={filters.projectId === 0}
                    onChange={() => setFilters({...filters, projectId: 0})}
                  />
                  <label htmlFor="allProjects" className="ml-2 text-sm text-gray-700">
                    All Projects
                  </label>
                </div>
                
                {projects.map((project) => (
                  <div key={project.id} className="flex items-center mb-2">
                    <input 
                      type="radio" 
                      id={`proj-${project.id}`} 
                      name="project"
                      className="h-4 w-4 text-primary border-gray-300"
                      checked={filters.projectId === project.id}
                      onChange={() => setFilters({...filters, projectId: project.id})}
                    />
                    <label htmlFor={`proj-${project.id}`} className="ml-2 text-sm text-gray-700 truncate">
                      {project.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="p-4 border-t bg-gray-50 flex flex-col sm:flex-row gap-2 justify-end">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setFilters({
                  startDate: "",
                  endDate: "",
                  salesExecutiveId: 0,
                  projectId: 0,
                });
              }}
              className="border-gray-300 hover:bg-white"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset All
            </Button>
            
            <Button 
              size="sm"
              onClick={() => setIsFilterDialogOpen(false)}
              className="gap-2"
            >
              <Check className="h-4 w-4" />
              Apply Filters
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertCircle className="h-5 w-5 mr-2" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this sale? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {saleToDelete && (
              <div className="border rounded-lg p-4 bg-gray-50">
                <p><span className="font-medium">Customer:</span> {saleToDelete.customerName}</p>
                <p><span className="font-medium">Project:</span> {saleToDelete.projectId ? getProjectName(saleToDelete.projectId) : "-"}</p>
                <p><span className="font-medium">Area:</span> {saleToDelete.areaSold ? Number(saleToDelete.areaSold).toLocaleString() : "0"} sq. ft.</p>
                <p><span className="font-medium">Amount:</span> ₹{(saleToDelete.finalAmount ? Number(saleToDelete.finalAmount) : (saleToDelete.areaSold && saleToDelete.baseSalePrice ? Number(saleToDelete.areaSold) * Number(saleToDelete.baseSalePrice) : 0)).toLocaleString()}</p>
              </div>
            )}
          </div>
          
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              className="flex items-center gap-2"
            >
              <Trash2 className="h-4 w-4" />
              Delete Sale
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Sale Cancellation Dialog */}
      <Dialog open={isCancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center text-orange-600">
              <Ban className="h-5 w-5 mr-2" />
              Cancel Sale
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this sale? This action will mark the sale as cancelled but preserve the record for analysis.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {saleToCancel && (
              <div className="border rounded-lg p-4 bg-gray-50">
                <p><span className="font-medium">Customer:</span> {saleToCancel.customerName}</p>
                <p><span className="font-medium">Project:</span> {saleToCancel.projectId ? getProjectName(saleToCancel.projectId) : "-"}</p>
                <p><span className="font-medium">Area:</span> {saleToCancel.areaSold ? Number(saleToCancel.areaSold).toLocaleString() : "0"} sq. ft.</p>
                <p><span className="font-medium">Amount:</span> ₹{(saleToCancel.finalAmount ? Number(saleToCancel.finalAmount) : (saleToCancel.areaSold && saleToCancel.baseSalePrice ? Number(saleToCancel.areaSold) * Number(saleToCancel.baseSalePrice) : 0)).toLocaleString()}</p>
              </div>
            )}
            
            <div className="space-y-2">
              <label htmlFor="cancellationReason" className="text-sm font-medium">
                Cancellation Reason <span className="text-red-500">*</span>
              </label>
              <textarea
                id="cancellationReason"
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                className="w-full p-3 border rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-orange-500"
                rows={3}
                placeholder="Please provide the reason for cancelling this sale..."
                required
              />
            </div>
          </div>
          
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => {
                setCancelDialogOpen(false);
                setCancellationReason("");
                setSaleToCancel(null);
              }}
            >
              Keep Sale
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (saleToCancel && cancellationReason.trim()) {
                  cancelSaleMutation.mutate({
                    id: saleToCancel.id,
                    cancellationReason: cancellationReason.trim()
                  });
                }
              }}
              disabled={!cancellationReason.trim() || cancelSaleMutation.isPending}
              className="flex items-center gap-2"
            >
              <Ban className="h-4 w-4" />
              {cancelSaleMutation.isPending ? "Cancelling..." : "Cancel Sale"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}