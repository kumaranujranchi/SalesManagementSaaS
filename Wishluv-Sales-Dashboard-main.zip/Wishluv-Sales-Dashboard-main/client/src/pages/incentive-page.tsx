import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarDays, TrendingUp, Trophy, DollarSign, Users } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';

interface IncentiveSummary {
  month: number;
  year: number;
  totalSales: number;
  totalArea: number;
  totalRevenue: number;
  currentSlab: number;
  incentiveRate: number;
  grossIncentive: number;
  eligibleIncentive: number;
}

interface UpcomingPayout {
  quarter: number;
  year: number;
  expectedAmount: number;
  payoutDate: string;
}

interface PaymentMilestone {
  customerName: string;
  mobileNumber: string;
  bookingDate: string;
  agreementStatus: string;
  agreementDate: string;
  eligibleSlab: string;
  paymentReceived: string;
  totalRevenue: number;
  incentiveAmount: number;
  payoutMonth: string;
  payoutStatus: string;
  status: string;
}

export default function IncentivePage() {
  const { user } = useAuth();
  const [summary, setSummary] = useState<IncentiveSummary | null>(null);
  const [upcomingPayouts, setUpcomingPayouts] = useState<UpcomingPayout[]>([]);
  const [paymentMilestones, setPaymentMilestones] = useState<PaymentMilestone[]>([]);
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [salesData, setSalesData] = useState<any[]>([]);
  const [targetData, setTargetData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [selectedUserData, setSelectedUserData] = useState<any>(null);

  // Determine if current user is admin
  const isAdmin = user?.role === "Admin" || user?.role === "Super Admin" || user?.designation === "Super Admin";

  useEffect(() => {
    const fetchIncentiveData = async () => {
      if (!user) return;
      
      try {
        // If admin, fetch users list first
        if (isAdmin) {
          const usersRes = await fetch('/api/users');
          const usersData = await usersRes.json();
          const salesUsers = usersData.filter((u: any) => 
            u.designation === "Sales Executive" || u.designation === "Executive"
          );
          setUsers(salesUsers);
          
          // If no user selected yet, select the first sales executive
          if (!selectedUserId && salesUsers.length > 0) {
            setSelectedUserId(salesUsers[0].id);
            setSelectedUserData(salesUsers[0]);
          }
        }

        // Determine which user's data to fetch
        const targetUserId = isAdmin ? selectedUserId || user.id : user.id;
        const targetUser = isAdmin ? selectedUserData || user : user;
        
        const [summaryRes, payoutsRes, salesRes, targetRes] = await Promise.all([
          fetch(`/api/incentives/summary/${targetUserId}`),
          fetch(`/api/incentives/payouts/${targetUserId}`),
          fetch(`/api/sales-monthly?userId=${targetUserId}`),
          fetch(`/api/targets/achievement/${targetUserId}`)
        ]);

        const summaryData = await summaryRes.json();
        const payoutsData = await payoutsRes.json();
        const userSalesData = await salesRes.json();
        const targetData = await targetRes.json();

        setSummary(summaryData);
        setUpcomingPayouts(payoutsData);
        setSalesData(userSalesData);
        setTargetData(targetData);
        
        // Create monthly data for Target vs Achievement chart using real target assignments from database
        const chartData = [
          { 
            month: 'Jan', 
            target: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 1)?.target || 0,
            achievement: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 1)?.achieved || 0
          },
          { 
            month: 'Feb', 
            target: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 2)?.target || 0,
            achievement: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 2)?.achieved || 0
          },
          { 
            month: 'Mar', 
            target: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 3)?.target || 0,
            achievement: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 3)?.achieved || 0
          },
          { 
            month: 'Apr', 
            target: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 4)?.target || 0,
            achievement: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 4)?.achieved || 0
          },
          { 
            month: 'May', 
            target: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 5)?.target || 0,
            achievement: targetData.monthlyBreakdown?.find((m: any) => m.year === 2025 && m.month === 5)?.achieved || 0
          }
        ];
        setMonthlyData(chartData);

        // Process comprehensive payment milestones from all sales data using authentic data
        const milestones = userSalesData.map((sale: any) => {
          const revenue = parseFloat(sale.areaSold) * parseFloat(sale.baseSalePrice);
          
          // Check eligibility: Both monthly target achievement AND overall positive performance required
          const isMonthlyTargetAchieved = monthlyAchievement >= monthlyTarget;
          const isOverallPerformancePositive = totalAchievement >= totalTarget;
          const isEligibleForIncentive = isMonthlyTargetAchieved && isOverallPerformancePositive && sale.agreementStatus === 'Yes';
          
          // Calculate slab and incentive only if eligible
          const currentSlab = isEligibleForIncentive ? (totalAreaSold >= 7100 ? 4 : totalAreaSold >= 5000 ? 3 : totalAreaSold >= 3000 ? 2 : 1) : 0;
          const incentiveRate = [0, 1, 2, 3, 4][currentSlab] / 100;
          const incentiveAmount = isEligibleForIncentive ? revenue * incentiveRate : 0;
          
          // Calculate actual payment percentage based on real payment data
          const totalBookingAmount = parseFloat(sale.finalAmount) || 0;
          const paymentReceived = parseFloat(sale.totalPaymentReceived) || 0;
          const paymentPercentage = totalBookingAmount > 0 ? Math.round((paymentReceived / totalBookingAmount) * 100) : 0;
          
          // Determine actual payment milestone reached
          let paymentMilestone = '0%';
          if (paymentPercentage >= 100) paymentMilestone = '100%';
          else if (paymentPercentage >= 75) paymentMilestone = '75%';
          else if (paymentPercentage >= 50) paymentMilestone = '50%';
          else if (paymentPercentage >= 30) paymentMilestone = '30%';
          else paymentMilestone = `${paymentPercentage}%`;
          
          // Determine payout quarter based on booking date using proper quarterly logic
          const bookingDate = new Date(sale.bookingDate);
          const month = bookingDate.getMonth() + 1; // 1-12
          let payoutMonth = '';
          
          if (month >= 1 && month <= 3) payoutMonth = 'April';        // Q1: Jan-Mar → April
          else if (month >= 4 && month <= 6) payoutMonth = 'July';    // Q2: Apr-Jun → July  
          else if (month >= 7 && month <= 9) payoutMonth = 'October'; // Q3: Jul-Sep → October
          else payoutMonth = 'January';                               // Q4: Oct-Dec → January
          
          // Determine payout status based on all eligibility conditions
          let payoutStatus = 'Not Eligible';
          if (isEligibleForIncentive) {
            if (paymentPercentage >= 30) {
              payoutStatus = paymentPercentage >= 100 ? 'Processing' : 'Pending';
            } else {
              payoutStatus = 'Pending';
            }
          }
          
          // Handle Agreement Date properly
          let displayAgreementDate = '';
          if (sale.agreementStatus === 'Yes') {
            if (sale.agreementDate && sale.agreementDate !== sale.bookingDate) {
              displayAgreementDate = new Date(sale.agreementDate).toLocaleDateString();
            } else {
              displayAgreementDate = 'Agreement not done';
            }
          } else {
            displayAgreementDate = 'Agreement not done';
          }

          return {
            customerName: sale.customerName || 'Customer Name',
            mobileNumber: sale.customerMobile || 'N/A', // Use the correct field name from database
            bookingDate: sale.bookingDate,
            agreementStatus: sale.agreementStatus || 'No',
            agreementDate: displayAgreementDate,
            eligibleSlab: isEligibleForIncentive ? `${[0, 1, 2, 3, 4][currentSlab]}%` : 'Not Eligible',
            paymentReceived: paymentMilestone,
            totalRevenue: revenue,
            incentiveAmount: incentiveAmount,
            payoutMonth: payoutMonth,
            payoutStatus: payoutStatus,
            status: payoutStatus
          };
        });
        setPaymentMilestones(milestones);

      } catch (error) {
        console.error("Error fetching incentive data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchIncentiveData();
  }, [user, selectedUserId]);

  // Handler for admin user selection
  const handleUserSelection = (userId: string) => {
    const selectedUser = users.find(u => u.id === parseInt(userId));
    setSelectedUserId(parseInt(userId));
    setSelectedUserData(selectedUser);
  };

  // Calculate real metrics from sales data and target data
  const currentMonth = new Date().getMonth() + 1;
  const currentYear = new Date().getFullYear();
  const monthKey = `${currentYear}-${currentMonth}`;
  
  // Get actual monthly target for this user from real target assignments
  const currentMonthTarget = targetData?.monthlyBreakdown?.find((month: any) => 
    month.year === currentYear && month.month === currentMonth
  )?.target || 0;
  
  const monthlyTarget = currentMonthTarget > 0 ? currentMonthTarget : (targetData?.monthlyTarget || 0);
  const totalTarget = targetData?.totalTarget || 0;
  
  // Calculate current month sales directly from sales data - exclude cancelled sales
  const currentMonthSales = salesData.filter(sale => {
    const saleDate = new Date(sale.bookingDate);
    return saleDate.getMonth() + 1 === currentMonth && 
           saleDate.getFullYear() === currentYear &&
           !sale.cancelledAt;
  });
  
  // Calculate actual achievement from real sales data - exclude cancelled sales
  const totalAreaSold = currentMonthSales.reduce((total, sale) => total + (parseFloat(sale.areaSold) || 0), 0);
  const monthlyAchievement = totalAreaSold;
  
  // Calculate total achievement across all time for overall performance check - exclude cancelled sales
  const activeSales = salesData.filter(sale => !sale.cancelledAt);
  const totalAchievement = activeSales.reduce((total, sale) => total + (parseFloat(sale.areaSold) || 0), 0);
  
  // Calculate revenue using BSP × Square feet sold
  const totalRevenue = currentMonthSales.reduce((total, sale) => {
    const areaSold = parseFloat(sale.areaSold) || 0;
    const baseSalePrice = parseFloat(sale.baseSalePrice) || 0;
    return total + (areaSold * baseSalePrice);
  }, 0);
  
  // Check target achievement eligibility
  const isTargetAchieved = monthlyAchievement >= monthlyTarget;
  const isOverallPositive = totalAchievement > 0;
  const isEligibleForIncentive = isTargetAchieved && isOverallPositive;
  
  // Determine current slab based on total area sold (per requirements document)
  const getCurrentSlab = (area: number) => {
    if (area >= 7100) return 4;  // 7,100 and above
    if (area >= 5000) return 3;  // 5,000 to 6,999  
    if (area >= 3000) return 2;  // 3,000 to 4,999
    return 1;                    // Up to 2,999
  };

  const currentSlab = getCurrentSlab(totalAreaSold);
  const slabRates = [0, 1, 2, 3, 4]; // 0%, 1%, 2%, 3%, 4%
  const expectedIncentive = isEligibleForIncentive ? totalRevenue * (slabRates[currentSlab] / 100) : 0;

  const getSlabInfo = (slab: number) => {
    const slabs = {
      1: { name: "Slab 1", range: "Up to 2,999", rate: "1%" },
      2: { name: "Slab 2", range: "3,000 to 4,999", rate: "2%" },
      3: { name: "Slab 3", range: "5,000 to 6,999", rate: "3%" },
      4: { name: "Slab 4", range: "7,100 and above", rate: "4%" }
    };
    return slabs[slab as keyof typeof slabs] || slabs[2];
  };

  const targetCompletion = Math.min((monthlyAchievement / monthlyTarget) * 100, 100);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Monthly Incentive Overview May 2025
              {isAdmin && selectedUserData && (
                <span className="text-lg text-gray-600 font-normal"> - {selectedUserData.fullName}</span>
              )}
            </h1>
            {isAdmin && (
              <div className="mt-2">
                <Select value={selectedUserId?.toString()} onValueChange={handleUserSelection}>
                  <SelectTrigger className="w-80">
                    <SelectValue placeholder="Select Sales Executive" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.map((user) => (
                      <SelectItem key={user.id} value={user.id.toString()}>
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          {user.fullName} - {user.designation}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={(isAdmin ? selectedUserData?.imageUrl : user?.imageUrl) || undefined} />
              <AvatarFallback>
                {(isAdmin ? selectedUserData?.fullName : user?.fullName)?.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">{isAdmin ? selectedUserData?.fullName : user?.fullName}</p>
              <p className="text-xs text-gray-600">{isAdmin ? selectedUserData?.designation : user?.designation}</p>
            </div>
          </div>
        </div>

        {/* Performance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700">Target Achievement</p>
                  <p className="text-2xl font-bold text-blue-900">{monthlyAchievement.toLocaleString()}/{monthlyTarget.toLocaleString()}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`bg-gradient-to-r ${isEligibleForIncentive ? 'from-green-50 to-green-100 border-green-200' : 'from-red-50 to-red-100 border-red-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${isEligibleForIncentive ? 'text-green-700' : 'text-red-700'}`}>Your Incentive</p>
                  {isEligibleForIncentive ? (
                    <>
                      <p className="text-2xl font-bold text-green-900">{getSlabInfo(currentSlab).name}</p>
                      <p className="text-sm text-green-600">{getSlabInfo(currentSlab).rate} Incentive</p>
                    </>
                  ) : (
                    <>
                      <p className="text-xl font-bold text-red-900">Not Eligible</p>
                      <p className="text-sm text-red-600">Target not achieved</p>
                    </>
                  )}
                </div>
                <Trophy className={`h-8 w-8 ${isEligibleForIncentive ? 'text-green-600' : 'text-red-600'}`} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-700">This Month Revenue</p>
                  <p className="text-2xl font-bold text-purple-900">₹ {totalRevenue.toLocaleString('en-IN')}</p>
                  <p className="text-xs text-purple-600">BSP × Area Sold</p>
                </div>
                <DollarSign className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`bg-gradient-to-r ${isEligibleForIncentive ? 'from-amber-50 to-amber-100 border-amber-200' : 'from-gray-50 to-gray-100 border-gray-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${isEligibleForIncentive ? 'text-amber-700' : 'text-gray-700'}`}>Expected Incentive</p>
                  {isEligibleForIncentive ? (
                    <p className="text-2xl font-bold text-amber-900">₹ {expectedIncentive.toLocaleString('en-IN')}</p>
                  ) : (
                    <p className="text-xl font-bold text-gray-900">₹ 0</p>
                  )}
                  <p className={`text-xs ${isEligibleForIncentive ? 'text-amber-600' : 'text-gray-600'}`}>
                    {isEligibleForIncentive ? `${slabRates[currentSlab]}% of revenue` : 'You are not eligible for the incentive'}
                  </p>
                </div>
                <DollarSign className={`h-8 w-8 ${isEligibleForIncentive ? 'text-amber-600' : 'text-gray-600'}`} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Target Completion Progress */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Target Completion</h3>
              <Badge variant="outline" className="text-sm">{targetCompletion.toFixed(0)}%</Badge>
            </div>
            <p className="text-sm text-gray-600 mb-4">You've achieved {targetCompletion.toFixed(0)}% of your monthly target!</p>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div className="bg-green-500 h-3 rounded-full" style={{ width: `${targetCompletion}%` }}></div>
            </div>
          </CardContent>
        </Card>

        {/* Graphical Overview - Full Width */}
        <Card>
          <CardHeader>
            <CardTitle>Graphical Overview</CardTitle>
            <p className="text-sm text-gray-600">Target vs Achievement from January to May</p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Bar dataKey="target" fill="#3b82f6" name="Target" />
                <Bar dataKey="achievement" fill="#10b981" name="Achievement" />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex items-center justify-center gap-4 mt-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-blue-500 rounded"></div>
                <span className="text-sm">Target</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-500 rounded"></div>
                <span className="text-sm">Achievement</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Secondary Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upcoming Payout */}

          {/* Upcoming Payout */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Upcoming Payout</CardTitle>
                <p className="text-sm text-gray-600">Expected Next Payout Date</p>
              </div>
              <Button variant="outline" size="sm" onClick={() => window.location.href = '/all-time-incentive'}>
                View All-Time Incentive
              </Button>
            </CardHeader>
            <CardContent>
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <CalendarDays className="h-5 w-5 text-blue-600" />
                  <span className="font-medium">July 15, 2025</span>
                  <Badge className="bg-blue-600">Pending</Badge>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  Your incentive is being processed and will be available on this date. You will receive only after minimum 30% collection from customers.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment Milestone Status */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Milestone Status</CardTitle>
            <p className="text-sm text-gray-600">Monitor incentive eligibility and payout status for each sale</p>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="text-left p-2 font-medium">Customer Name</th>
                    <th className="text-left p-2 font-medium">Mobile Number</th>
                    <th className="text-left p-2 font-medium">Booking Date</th>
                    <th className="text-left p-2 font-medium">Agreement Status</th>
                    <th className="text-left p-2 font-medium">Agreement Date</th>
                    <th className="text-left p-2 font-medium">Eligible Slab</th>
                    <th className="text-left p-2 font-medium">Payment Received</th>
                    <th className="text-left p-2 font-medium">Total Revenue</th>
                    <th className="text-left p-2 font-medium">Incentive Amount</th>
                    <th className="text-left p-2 font-medium">Payout Month</th>
                    <th className="text-left p-2 font-medium">Payout Status</th>
                  </tr>
                </thead>
                <tbody>
                  {paymentMilestones.map((milestone, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="p-2 font-medium">{milestone.customerName}</td>
                      <td className="p-2">{milestone.mobileNumber}</td>
                      <td className="p-2">{new Date(milestone.bookingDate).toLocaleDateString()}</td>
                      <td className="p-2">
                        <Badge 
                          className={`${milestone.agreementStatus === 'Yes' ? 'bg-green-500' : 'bg-red-500'}`}
                        >
                          {milestone.agreementStatus}
                        </Badge>
                      </td>
                      <td className="p-2">{new Date(milestone.agreementDate).toLocaleDateString()}</td>
                      <td className="p-2">
                        <Badge variant="outline" className="bg-blue-50">
                          {milestone.eligibleSlab}
                        </Badge>
                      </td>
                      <td className="p-2">
                        <Badge 
                          className={`${milestone.paymentReceived === '100%' ? 'bg-green-500' : 
                                      milestone.paymentReceived === '75%' ? 'bg-blue-500' : 
                                      milestone.paymentReceived === '50%' ? 'bg-orange-500' : 'bg-yellow-500'}`}
                        >
                          {milestone.paymentReceived}
                        </Badge>
                      </td>
                      <td className="p-2 font-medium">₹ {milestone.totalRevenue.toLocaleString('en-IN')}</td>
                      <td className="p-2 font-medium text-green-600">
                        {milestone.incentiveAmount > 0 ? `₹ ${milestone.incentiveAmount.toLocaleString('en-IN')}` : '₹ 0'}
                      </td>
                      <td className="p-2">{milestone.payoutMonth}</td>
                      <td className="p-2">
                        <Badge 
                          className={`${milestone.payoutStatus === 'Paid' ? 'bg-green-500' : 
                                      milestone.payoutStatus === 'Processing' ? 'bg-blue-500' : 
                                      milestone.payoutStatus === 'Not Eligible' ? 'bg-red-500' : 'bg-orange-500'}`}
                        >
                          {milestone.payoutStatus}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}