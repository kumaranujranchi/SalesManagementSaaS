import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Edit, Eye, Loader2, Plus, Search, Trash2, Users } from "lucide-react";
import { Department, InsertDepartment } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertDepartmentSchema } from "@shared/schema";

type DepartmentFormValues = z.infer<typeof insertDepartmentSchema>;

export default function DepartmentManagementPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingDepartment, setEditingDepartment] = useState<Department | null>(null);
  const [deletingDepartment, setDeletingDepartment] = useState<Department | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const { data: departments, isLoading } = useQuery<Department[]>({
    queryKey: ["/api/departments"],
    onError: () => {
      toast({
        title: "Failed to load departments",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  });

  const form = useForm<DepartmentFormValues>({
    resolver: zodResolver(insertDepartmentSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const createDepartment = useMutation({
    mutationFn: async (data: InsertDepartment) => {
      const res = await apiRequest("POST", "/api/departments", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Department created",
        description: "The department has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/departments"] });
      setShowAddDialog(false);
      form.reset({
        name: "",
        description: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create department.",
        variant: "destructive",
      });
    },
  });

  const updateDepartment = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertDepartment }) => {
      const res = await apiRequest("PUT", `/api/departments/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Department updated",
        description: "The department has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/departments"] });
      setShowAddDialog(false);
      setEditingDepartment(null);
      form.reset({
        name: "",
        description: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update department.",
        variant: "destructive",
      });
    },
  });

  const deleteDepartment = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/departments/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Department deleted",
        description: "The department has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/departments"] });
      setShowDeleteDialog(false);
      setDeletingDepartment(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete department.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: DepartmentFormValues) => {
    if (editingDepartment) {
      updateDepartment.mutate({ id: editingDepartment.id, data });
    } else {
      createDepartment.mutate(data);
    }
  };

  const handleEdit = (department: Department) => {
    setEditingDepartment(department);
    form.reset({
      name: department.name,
      description: department.description || "",
    });
    setShowAddDialog(true);
  };

  const handleDelete = (department: Department) => {
    setDeletingDepartment(department);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (deletingDepartment) {
      deleteDepartment.mutate(deletingDepartment.id);
    }
  };

  const closeDialog = () => {
    setShowAddDialog(false);
    setEditingDepartment(null);
    form.reset({
      name: "",
      description: "",
    });
  };

  // Filter departments by search term
  const filteredDepartments = departments
    ? departments.filter(department =>
        department.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        department.description?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const isPending = createDepartment.isPending || updateDepartment.isPending || deleteDepartment.isPending;

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <div className="mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <h1 className="text-2xl font-bold">Department Management</h1>
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button variant="default" className="mt-4 md:mt-0 px-4 py-2 rounded-md flex items-center bg-primary text-primary-foreground hover:bg-primary/90">
                    <Plus className="mr-2 h-4 w-4" />
                    Add New Department
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[550px]">
                  <DialogHeader>
                    <DialogTitle>
                      {editingDepartment ? "Edit Department" : "Add New Department"}
                    </DialogTitle>
                    <DialogDescription>
                      {editingDepartment 
                        ? "Update department details." 
                        : "Create a new department in your organization."}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={form.handleSubmit(onSubmit)}>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="name" className="text-right text-sm font-medium">
                          Department Name
                        </label>
                        <Input
                          id="name"
                          className="col-span-3"
                          placeholder="Enter department name"
                          {...form.register("name")}
                        />
                        {form.formState.errors.name && (
                          <p className="col-span-3 col-start-2 text-sm text-red-500">
                            {form.formState.errors.name.message}
                          </p>
                        )}
                      </div>
                      <div className="grid grid-cols-4 items-start gap-4">
                        <label htmlFor="description" className="text-right text-sm font-medium mt-2">
                          Description
                        </label>
                        <Textarea
                          id="description"
                          className="col-span-3"
                          placeholder="Enter department description"
                          {...form.register("description")}
                        />
                        {form.formState.errors.description && (
                          <p className="col-span-3 col-start-2 text-sm text-red-500">
                            {form.formState.errors.description.message}
                          </p>
                        )}
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={closeDialog}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={isPending}>
                        {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {editingDepartment ? "Update Department" : "Create Department"}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">TOTAL DEPARTMENTS</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{departments?.length || 0}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">EMPLOYEES</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">125</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500">ACTIVE DEPARTMENTS</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{departments?.length || 0}</div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <CardTitle>Departments</CardTitle>
                    <CardDescription>Manage your organization's departments</CardDescription>
                  </div>
                  <div className="relative mt-4 md:mt-0">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral-500" />
                    <Input
                      type="search"
                      placeholder="Search departments..."
                      className="pl-9 w-full md:w-[260px]"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Department Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Employees</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4">
                          <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                          <span className="mt-2 inline-block">Loading departments...</span>
                        </TableCell>
                      </TableRow>
                    ) : filteredDepartments.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4">
                          No departments found. {searchTerm ? "Try adjusting your search." : "Create a new department to get started."}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredDepartments.map((department) => (
                        <TableRow key={department.id}>
                          <TableCell className="font-medium">{department.name}</TableCell>
                          <TableCell>{department.description || "No description"}</TableCell>
                          <TableCell className="flex items-center">
                            <Users className="h-4 w-4 mr-2 text-neutral-500" />
                            <span>12</span> {/* This would be dynamic in a real app */}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                              onClick={() => handleEdit(department)}
                            >
                              <span className="sr-only">Edit</span>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                            >
                              <span className="sr-only">View</span>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                              onClick={() => handleDelete(department)}
                            >
                              <span className="sr-only">Delete</span>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="flex items-center justify-between">
                <div className="text-sm text-neutral-600">
                  Showing {filteredDepartments.length} of {departments?.length || 0} departments
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    Previous
                  </Button>
                  <Button variant="outline" size="sm">
                    Next
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
        </main>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the department
              "{deletingDepartment?.name}" and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 text-white hover:bg-red-700"
              disabled={deleteDepartment.isPending}
            >
              {deleteDepartment.isPending ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Deleting...</>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
