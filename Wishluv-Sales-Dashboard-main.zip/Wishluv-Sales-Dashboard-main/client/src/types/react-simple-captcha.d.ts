declare module 'react-simple-captcha' {
  export function loadCaptchaEnginge(numberOfChars: number): void;
  export function LoadCanvasTemplate(): JSX.Element;
  export function validateCaptcha(userCaptcha: string, removeString?: boolean): boolean;
  export function createCaptcha(numberOfChars: number): string;
}