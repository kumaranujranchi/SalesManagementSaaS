import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";

// This hook fetches the detailed role information for the current user
export function useUserRole() {
  const { user } = useAuth();
  
  // Don't make the API call if no user or user has Super Admin role (Super Admin gets all permissions by default)
  const enabled = !!user && typeof user.role === 'string' && user.role !== 'Super Admin';
  
  // Fetch role details for the user's role if needed
  const { data: roleDetails, isLoading } = useQuery({
    queryKey: ['/api/roles', user?.role || ''],
    queryFn: async () => {
      if (!enabled) return null;
      const res = await fetch(`/api/roles/by-name/${encodeURIComponent(user?.role || '')}`);
      if (!res.ok) throw new Error('Failed to fetch role permissions');
      return res.json();
    },
    enabled,
  });
  
  const getRolePermissions = () => {
    try {
      if (roleDetails?.permissions) {
        return JSON.parse(roleDetails.permissions);
      }
      return {};
    } catch (error) {
      console.error('Error parsing role permissions:', error);
      return {};
    }
  };
  
  return {
    roleDetails,
    permissions: getRolePermissions(),
    isLoading
  };
}