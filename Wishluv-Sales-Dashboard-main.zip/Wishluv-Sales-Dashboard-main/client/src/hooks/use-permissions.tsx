import { useAuth } from "@/hooks/use-auth";
import { useUserRole } from "@/hooks/use-user-role";

// Define a type for permissions object
export type PermissionsType = Record<string, boolean>;

// Permission check hook
export function usePermissions() {
  const { user } = useAuth();
  const { permissions: rolePermissions } = useUserRole();
  
  // Parse permissions from string or use defaults based on role
  const getUserPermissions = (): PermissionsType => {
    try {
      // Super Admin has all permissions
      if (user?.role === 'Super Admin') {
        return { "*": true };
      }
      
      // For custom roles with permissions in the database (including Admin)
      if (Object.keys(rolePermissions).length > 0) {
        return rolePermissions;
      }
      
      // Default permissions for built-in roles
      
      // CRM role permissions
      if (user?.role === 'CRM') {
        return { 
          "sales.view": true,
          "sales.edit": true,
          "sales.create": true,
          "sales.delete": true,
          "user.view": true,
          "user.edit": true,
          "user.create": true,
          "user.delete": false,
          "dashboard.view": true,
          "announcement.view": true,
          "target.view": true
        };
      }
      
      // Sales Representative role
      if (user?.role === 'Sales Representative') {
        return {
          "sales.view": true,
          "announcement.view": true,
          "user.view": user?.department === 'Sales', // Only view users in sales dept
          "target.view": true
        };
      }
      
      // Accountant role permissions
      if (user?.role === 'Accountant') {
        return { 
          "sales.view": true,
          "user.view": true,
          "dashboard.view": true,
          "announcement.view": true,
          "target.view": true
        };
      }
      
      // Default to empty permissions
      return {};
    } catch (error) {
      console.error("Error getting permissions:", error);
      return {};
    }
  };
  
  const permissions = getUserPermissions();
  
  // Check if user has a specific permission
  const hasPermission = (permission: string): boolean => {
    // Super admin has all permissions
    if (permissions["*"]) return true;
    
    // Check for specific permission
    return !!permissions[permission];
  };
  
  // Check if user should be able to see action buttons (edit/delete/etc)
  const canPerformAction = (resource: string, action: 'view' | 'create' | 'edit' | 'delete'): boolean => {
    return hasPermission(`${resource}.${action}`);
  };
  
  return {
    permissions,
    hasPermission,
    canPerformAction
  };
}