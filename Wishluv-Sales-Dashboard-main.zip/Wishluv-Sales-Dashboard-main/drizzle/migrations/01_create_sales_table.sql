CREATE TABLE IF NOT EXISTS sales (
  id SERIAL PRIMARY KEY,
  sales_executive_id INTEGER NOT NULL,
  project_id INTEGER NOT NULL,
  booking_date DATE NOT NULL,
  area_sold NUMERIC NOT NULL,
  booking_amount NUMERIC NOT NULL,
  created_by INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
