-- Add the agreement_date column to the sales table
ALTER TABLE sales ADD COLUMN agreement_date DATE;