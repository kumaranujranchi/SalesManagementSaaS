import type { Express } from "express";
import { eq, inArray, sql, and, gte, lte } from "drizzle-orm";
import { db } from "./db";
import { sales, users, SalesDesignation } from "@shared/schema";

// Team performance endpoints for sales dashboard
export function registerTeamRoutes(app: Express) {
  // API endpoint to get team sales data (all time)
  app.get("/api/team-sales", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { team: teamQuery } = req.query;

      // Only Team Leaders and Sales Head can access team performance data
      if (user.designation !== SalesDesignation.TEAM_LEADER && 
          user.designation !== SalesDesignation.SALES_HEAD) {
        return res.status(403).send("Forbidden");
      }

      // Get the current user's team (for Team Leaders) or the requested team (for Sales Head)
      const team = user.designation === SalesDesignation.TEAM_LEADER ? 
        user.team : 
        (teamQuery as string | undefined);

      // Get all sales staff in the specified team
      let salesStaff;
      
      if (user.designation === SalesDesignation.SALES_HEAD) {
        // Sales Head can see all teams or filter by team
        if (team) {
          salesStaff = await db.select().from(users)
            .where(sql`${users.team} = ${team}`);
        } else {
          salesStaff = await db.select().from(users)
            .where(eq(users.department, "Sales"));
        }
      } else {
        // Team Leader can only see their team
        salesStaff = await db.select().from(users)
          .where(sql`${users.team} = ${user.team}`);
      }
      
      // Get the user IDs of all team members
      const teamMemberIds = salesStaff.map(user => user.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]); // No team members found
      }

      // Get all sales for the team members
      const teamSalesData = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        team: users.team,
        totalSales: sql<number>`SUM(${sales.bookingAmount})`,
        totalArea: sql<number>`SUM(${sales.areaSold})`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(inArray(sales.salesExecutiveId, teamMemberIds))
      .groupBy(sales.salesExecutiveId, users.fullName, users.team)
      .orderBy(sql`SUM(${sales.bookingAmount}) DESC`);

      res.json(teamSalesData);
    } catch (error) {
      console.error("Error getting team sales data:", error);
      res.status(500).send("Error retrieving team sales data");
    }
  });

  // API endpoint to get team monthly sales data
  app.get("/api/team-sales-monthly", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { team: teamQuery } = req.query;

      // Only Team Leaders and Sales Head can access team performance data
      if (user.designation !== SalesDesignation.TEAM_LEADER && 
          user.designation !== SalesDesignation.SALES_HEAD) {
        return res.status(403).send("Forbidden");
      }

      // Get the current user's team (for Team Leaders) or the requested team (for Sales Head)
      const team = user.designation === SalesDesignation.TEAM_LEADER ? 
        user.team : 
        (teamQuery as string | undefined);

      // Get monthly date range
      const today = new Date();
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      
      const firstDayStr = firstDay.toISOString().split('T')[0];
      const lastDayStr = lastDay.toISOString().split('T')[0];
      
      // Get all sales staff in the specified team
      let salesStaff;
      
      if (user.designation === SalesDesignation.SALES_HEAD) {
        // Sales Head can see all teams or filter by team
        if (team) {
          salesStaff = await db.select().from(users)
            .where(sql`${users.team} = ${team}`);
        } else {
          salesStaff = await db.select().from(users)
            .where(eq(users.department, "Sales"));
        }
      } else {
        // Team Leader can only see their team
        salesStaff = await db.select().from(users)
          .where(sql`${users.team} = ${user.team}`);
      }
      
      // Get the user IDs of all team members
      const teamMemberIds = salesStaff.map(user => user.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]); // No team members found
      }

      // Get monthly sales for the team members
      const teamMonthlySalesData = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        team: users.team,
        totalSales: sql<number>`SUM(${sales.bookingAmount})`,
        totalArea: sql<number>`SUM(${sales.areaSold})`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      )
      .groupBy(sales.salesExecutiveId, users.fullName, users.team)
      .orderBy(sql`SUM(${sales.bookingAmount}) DESC`);

      res.json(teamMonthlySalesData);
    } catch (error) {
      console.error("Error getting team monthly sales data:", error);
      res.status(500).send("Error retrieving team monthly sales data");
    }
  });

  // API endpoint to get team yearly sales data
  app.get("/api/team-sales-yearly", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { team: teamQuery } = req.query;

      // Only Team Leaders and Sales Head can access team performance data
      if (user.designation !== SalesDesignation.TEAM_LEADER && 
          user.designation !== SalesDesignation.SALES_HEAD) {
        return res.status(403).send("Forbidden");
      }

      // Get the current user's team (for Team Leaders) or the requested team (for Sales Head)
      const team = user.designation === SalesDesignation.TEAM_LEADER ? 
        user.team : 
        (teamQuery as string | undefined);

      // Get yearly date range (since Jan 1 of current year)
      const today = new Date();
      const firstDay = new Date(today.getFullYear(), 0, 1);
      const lastDay = today;
      
      const firstDayStr = firstDay.toISOString().split('T')[0];
      const lastDayStr = lastDay.toISOString().split('T')[0];
      
      // Get all sales staff in the specified team
      let salesStaff;
      
      if (user.designation === SalesDesignation.SALES_HEAD) {
        // Sales Head can see all teams or filter by team
        if (team) {
          salesStaff = await db.select().from(users)
            .where(sql`${users.team} = ${team}`);
        } else {
          salesStaff = await db.select().from(users)
            .where(eq(users.department, "Sales"));
        }
      } else {
        // Team Leader can only see their team
        salesStaff = await db.select().from(users)
          .where(sql`${users.team} = ${user.team}`);
      }
      
      // Get the user IDs of all team members
      const teamMemberIds = salesStaff.map(user => user.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]); // No team members found
      }

      // Get yearly sales for the team members
      const teamYearlySalesData = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        team: users.team,
        totalSales: sql<number>`SUM(${sales.bookingAmount})`,
        totalArea: sql<number>`SUM(${sales.areaSold})`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      )
      .groupBy(sales.salesExecutiveId, users.fullName, users.team)
      .orderBy(sql`SUM(${sales.bookingAmount}) DESC`);

      res.json(teamYearlySalesData);
    } catch (error) {
      console.error("Error getting team yearly sales data:", error);
      res.status(500).send("Error retrieving team yearly sales data");
    }
  });
}