import { 
  users, 
  projects, 
  departments, 
  roles, 
  activities, 
  leaderboard,
  announcements,
  sales,
  payments,
  targets,
  incentives,
  incentivePayouts,
  siteVisits,
  type User, 
  type Project, 
  type Department, 
  type Role, 
  type Activity, 
  type Leaderboard,
  type Announcement,
  type Sales,
  type Target,
  type Incentive,
  type IncentivePayout,
  type InsertUser, 
  type InsertProject, 
  type InsertDepartment, 
  type InsertRole, 
  type InsertActivity, 
  type InsertLeaderboard,
  type InsertAnnouncement,
  type InsertSales,
  type InsertPayment,
  type InsertTarget,
  type InsertIncentive,
  type InsertIncentivePayout,
  type SiteVisit,
  type InsertSiteVisit
} from "@shared/schema";
import session from "express-session";
import { db, pool } from "./db";
import { eq, desc, and, gte, lte, sql, count, or, isNull } from "drizzle-orm";
import connectPg from "connect-pg-simple";

const PostgresSessionStore = connectPg(session);

import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    // Clean joining date input - make sure it's either null or a valid date
    let joiningDate = null;
    if (user.joiningDate) {
      try {
        if (typeof user.joiningDate === 'string') {
          // If it's a string format YYYY-MM-DD, parse it
          const dateString = user.joiningDate as string;
          const parts = dateString.split('-');
          if (parts.length === 3) {
            const year = parseInt(parts[0], 10);
            const month = parseInt(parts[1], 10);
            const day = parseInt(parts[2], 10);
            joiningDate = new Date(year, month - 1, day);
          }
        } else if (user.joiningDate instanceof Date) {
          joiningDate = user.joiningDate;
        }
      } catch (e) {
        console.error("Error parsing joining date:", e);
        joiningDate = null;
      }
    }
    
    const userWithDefaults: typeof user = {
      ...user,
      phone: user.phone ?? null,
      designation: user.designation ?? null,
      department: user.department ?? null,
      reportingManager: user.reportingManager ?? null,
      reportingManagerId: user.reportingManagerId ?? null,
      team: user.team ?? null,
      imageUrl: user.imageUrl ?? null,
      role: user.role ?? null,
      status: user.status ?? true,
      employeeId: user.employeeId ?? null,
      joiningDate: joiningDate,
      monthlyTarget: user.monthlyTarget ?? null
    };
    
    const [newUser] = await db.insert(users).values(userWithDefaults).returning();
    return newUser;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    // Handle joining date properly
    if (userData.joiningDate !== undefined) {
      try {
        if (userData.joiningDate === null) {
          // Keep as null
        } else if (typeof userData.joiningDate === 'string') {
          // If it's a string format YYYY-MM-DD, parse it
          const dateString = userData.joiningDate as string;
          const parts = dateString.split('-');
          if (parts.length === 3) {
            const year = parseInt(parts[0], 10);
            const month = parseInt(parts[1], 10);
            const day = parseInt(parts[2], 10);
            userData.joiningDate = new Date(year, month - 1, day);
          } else {
            userData.joiningDate = null;
          }
        } else if (userData.joiningDate instanceof Date) {
          // Already a date, keep as is
        } else {
          userData.joiningDate = null;
        }
      } catch (e) {
        console.error("Error parsing joining date during update:", e);
        userData.joiningDate = null;
      }
    }
    
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return !!result;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  // Project management
  async createProject(project: InsertProject): Promise<Project> {
    const projectWithDefaults: typeof project = {
      ...project,
      status: project.status ?? null,
      description: project.description ?? null,
      deadline: project.deadline ?? null
    };
    
    const [newProject] = await db.insert(projects).values(projectWithDefaults).returning();
    return newProject;
  }
  
  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }
  
  async updateProject(id: number, projectData: Partial<InsertProject>): Promise<Project | undefined> {
    const [updatedProject] = await db
      .update(projects)
      .set(projectData)
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }
  
  async deleteProject(id: number): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return !!result;
  }
  
  async getAllProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }
  
  // Department management
  async createDepartment(department: InsertDepartment): Promise<Department> {
    const departmentWithDefaults: typeof department = {
      ...department,
      description: department.description ?? null
    };
    
    const [newDepartment] = await db.insert(departments).values(departmentWithDefaults).returning();
    return newDepartment;
  }
  
  async getDepartment(id: number): Promise<Department | undefined> {
    const [department] = await db.select().from(departments).where(eq(departments.id, id));
    return department;
  }
  
  async updateDepartment(id: number, departmentData: Partial<InsertDepartment>): Promise<Department | undefined> {
    const [updatedDepartment] = await db
      .update(departments)
      .set(departmentData)
      .where(eq(departments.id, id))
      .returning();
    return updatedDepartment;
  }
  
  async deleteDepartment(id: number): Promise<boolean> {
    const result = await db.delete(departments).where(eq(departments.id, id));
    return !!result;
  }
  
  async getAllDepartments(): Promise<Department[]> {
    return await db.select().from(departments);
  }
  
  // Role management
  async createRole(role: InsertRole): Promise<Role> {
    const roleWithDefaults: typeof role = {
      ...role,
      description: role.description ?? null
    };
    
    const [newRole] = await db.insert(roles).values(roleWithDefaults).returning();
    return newRole;
  }
  
  async getRole(id: number): Promise<Role | undefined> {
    const [role] = await db.select().from(roles).where(eq(roles.id, id));
    return role;
  }
  
  async updateRole(id: number, roleData: Partial<InsertRole>): Promise<Role | undefined> {
    const [updatedRole] = await db
      .update(roles)
      .set(roleData)
      .where(eq(roles.id, id))
      .returning();
    return updatedRole;
  }
  
  async deleteRole(id: number): Promise<boolean> {
    const result = await db.delete(roles).where(eq(roles.id, id));
    return !!result;
  }
  
  async getAllRoles(): Promise<Role[]> {
    return await db.select().from(roles);
  }
  
  // Activity management
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const activityWithTimestamp = {
      ...activity,
      timestamp: new Date()
    };
    const [newActivity] = await db.insert(activities).values(activityWithTimestamp).returning();
    return newActivity;
  }
  
  async getAllActivities(): Promise<Activity[]> {
    return await db.select().from(activities).orderBy(desc(activities.timestamp));
  }
  
  // Leaderboard management
  async createLeaderboardEntry(entry: InsertLeaderboard): Promise<Leaderboard> {
    const entryWithDefaults: typeof entry = {
      ...entry,
      score: entry.score ?? null
    };
    
    const [newEntry] = await db.insert(leaderboard).values(entryWithDefaults).returning();
    return newEntry;
  }
  
  async getLeaderboard(): Promise<Leaderboard[]> {
    return await db.select().from(leaderboard);
  }
  
  // Announcement management
  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const announcementWithDefaults: typeof announcement = {
      ...announcement,
      isImportant: announcement.isImportant ?? false
    };
    
    const [newAnnouncement] = await db.insert(announcements).values(announcementWithDefaults).returning();
    return newAnnouncement;
  }
  
  async getAnnouncement(id: number): Promise<Announcement | undefined> {
    const [announcement] = await db.select().from(announcements).where(eq(announcements.id, id));
    return announcement;
  }
  
  async deleteAnnouncement(id: number): Promise<boolean> {
    const result = await db.delete(announcements).where(eq(announcements.id, id));
    return !!result;
  }
  
  async getAllAnnouncements(): Promise<Announcement[]> {
    return await db.select().from(announcements).orderBy(desc(announcements.createdAt));
  }
  
  // Sales management
  async createSale(sale: InsertSales): Promise<Sales> {
    const [newSale] = await db.insert(sales).values(sale).returning();
    return newSale;
  }
  
  async getSale(id: number): Promise<Sales | undefined> {
    const [sale] = await db.select().from(sales).where(eq(sales.id, id));
    return sale;
  }
  
  async updateSale(id: number, saleData: Partial<InsertSales>): Promise<Sales | undefined> {
    const [updatedSale] = await db
      .update(sales)
      .set(saleData)
      .where(eq(sales.id, id))
      .returning();
    return updatedSale;
  }
  
  async cancelSale(id: number, cancelledBy: number, cancellationReason: string): Promise<Sales | undefined> {
    try {
      const [result] = await db
        .update(sales)
        .set({
          status: "cancelled",
          cancelledAt: new Date(),
          cancelledBy: cancelledBy,
          cancellationReason: cancellationReason
        })
        .where(eq(sales.id, id))
        .returning();
      
      return result;
    } catch (error) {
      console.error("Error cancelling sale:", error);
      return undefined;
    }
  }

  async deleteSale(id: number): Promise<boolean> {
    const result = await db.delete(sales).where(eq(sales.id, id));
    return !!result;
  }
  
  async getAllSales(): Promise<Sales[]> {
    return await db.select().from(sales).orderBy(desc(sales.createdAt));
  }
  
  // Sales dashboard data methods
  async getMonthlySalesByUser(userId?: number): Promise<any[]> {
    // Get current date info
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth(); // 0-indexed (0 = January)
    
    // Create date objects for first and last day of current month
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);
    
    // Convert dates to ISO string format for SQL comparison
    const firstDayIso = firstDayOfMonth.toISOString();
    const lastDayIso = lastDayOfMonth.toISOString();
    
    // Base query conditions - exclude cancelled sales
    let conditions = and(
      gte(sales.bookingDate, sql`${firstDayIso}::date`),
      lte(sales.bookingDate, sql`${lastDayIso}::date`),
      isNull(sales.cancelledAt)
    );
    
    // Add filter for specific user if userId is provided
    if (userId !== undefined) {
      conditions = and(conditions, eq(sales.salesExecutiveId, userId));
    }
    
    // Execute query and return results
    return await db.select().from(sales).where(conditions);
  }
  
  async getYearlySalesByUser(userId?: number): Promise<any[]> {
    // Get current date info
    const now = new Date();
    const currentYear = now.getFullYear();
    
    // Create date objects for first and last day of current year
    const firstDayOfYear = new Date(currentYear, 0, 1);
    const lastDayOfYear = new Date(currentYear, 11, 31);
    
    // Convert dates to ISO string format for SQL comparison
    const firstDayIso = firstDayOfYear.toISOString();
    const lastDayIso = lastDayOfYear.toISOString();
    
    // Base query conditions - exclude cancelled sales
    let conditions = and(
      gte(sales.bookingDate, sql`${firstDayIso}::date`),
      lte(sales.bookingDate, sql`${lastDayIso}::date`),
      isNull(sales.cancelledAt)
    );
    
    // Add filter for specific user if userId is provided
    if (userId !== undefined) {
      conditions = and(conditions, eq(sales.salesExecutiveId, userId));
    }
    
    // Execute query and return results
    return await db.select().from(sales).where(conditions);
  }
  
  async getCrystalCityContestSales(userId?: number): Promise<any[]> {
    // Contest date range: March 15 - May 15, 2025
    const contestStartDate = new Date(2025, 2, 15); // March 15, 2025
    const contestEndDate = new Date(2025, 4, 15);   // May 15, 2025
    
    // Convert dates to ISO string format for SQL comparison
    const startDateIso = contestStartDate.toISOString();
    const endDateIso = contestEndDate.toISOString();
    
    console.log('Crystal City Contest date range:', {
      start: contestStartDate.toDateString(),
      end: contestEndDate.toDateString(),
      startIso: startDateIso,
      endIso: endDateIso
    });
    
    // Find Crystal City project by name
    const allProjects = await db.select().from(projects);
    const crystalCityProject = allProjects.find(p => p.name.toLowerCase().includes('crystal city'));
    
    // Base date range conditions - exclude cancelled sales
    let conditions = and(
      gte(sales.bookingDate, sql`${startDateIso}::date`),
      lte(sales.bookingDate, sql`${endDateIso}::date`),
      isNull(sales.cancelledAt)
    );
    
    // Filter by Crystal City project if found, otherwise just use date range
    if (crystalCityProject) {
      conditions = and(conditions, eq(sales.projectId, crystalCityProject.id));
      console.log(`Found Crystal City project with ID: ${crystalCityProject.id}`);
    } else {
      console.log('Crystal City project not found, using only date range filter');
    }
    
    // Add filter for specific user if userId is provided
    if (userId !== undefined) {
      conditions = and(conditions, eq(sales.salesExecutiveId, userId));
    }
    
    // Execute query and return results
    const results = await db.select().from(sales).where(conditions);
    console.log(`Found ${results.length} sales for Crystal City contest period`);
    
    // Log the first few sales to debug
    if (results.length > 0) {
      console.log('Sample contest sales:', results.slice(0, 3).map(sale => ({
        id: sale.id,
        projectId: sale.projectId,
        bookingDate: sale.bookingDate,
        finalAmount: sale.finalAmount
      })));
    }
    
    return results;
  }
  
  // Target management
  async createTarget(target: InsertTarget): Promise<Target> {
    // Check if a target already exists for this user/year/month combination
    const existingTarget = await this.getTarget(target.userId, target.year, target.month);
    
    if (existingTarget) {
      // Update the existing target instead of creating a new one
      return await this.updateTarget(existingTarget.id, { targetValue: target.targetValue }) as Target;
    }
    
    const [newTarget] = await db.insert(targets).values(target).returning();
    return newTarget;
  }

  async getTarget(userId: number, year: number, month: number): Promise<Target | undefined> {
    const [target] = await db
      .select()
      .from(targets)
      .where(
        and(
          eq(targets.userId, userId),
          eq(targets.year, year),
          eq(targets.month, month)
        )
      );
    return target;
  }

  async updateTarget(id: number, targetData: Partial<InsertTarget>): Promise<Target | undefined> {
    const [updatedTarget] = await db
      .update(targets)
      .set({
        ...targetData,
        lastUpdated: new Date()
      })
      .where(eq(targets.id, id))
      .returning();
    return updatedTarget;
  }

  async deleteTarget(id: number): Promise<boolean> {
    const result = await db.delete(targets).where(eq(targets.id, id));
    return !!result.rowCount;
  }

  // Target vs Achievement data methods
  async getUserTargets(userId: number): Promise<Target[]> {
    return await db
      .select()
      .from(targets)
      .where(eq(targets.userId, userId))
      .orderBy(desc(targets.year), desc(targets.month));
  }

  async getAllTargets(): Promise<Target[]> {
    try {
      const results = await db
        .select()
        .from(targets)
        .orderBy(desc(targets.year), desc(targets.month));
      
      console.log("getAllTargets result count:", results.length);
      console.log("Sample targets:", results.slice(0, 3));
      
      return results;
    } catch (error) {
      console.error("Error in getAllTargets:", error);
      throw error;
    }
  }

  async calculateUserAchievement(userId: number, startDate?: Date, endDate?: Date): Promise<any> {
    // Get the user to check joining date
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Determine start and end dates for calculation
    const now = new Date();
    let calculationStartDate: Date;
    
    // Get all targets for this user to find the earliest target assignment date
    const allUserTargets = await this.getUserTargets(userId);
    
    if (startDate) {
      calculationStartDate = startDate;
    } else if (allUserTargets && allUserTargets.length > 0) {
      // Find earliest target date
      const earliestTargetDate = allUserTargets.reduce((earliest, target) => {
        const targetDate = new Date(target.year, target.month - 1, 1);
        return targetDate < earliest ? targetDate : earliest;
      }, new Date()); // Start with current date as initial value
      
      // If user has joining date, use the later of joining date or earliest target date
      if (user.joiningDate) {
        const joiningDate = new Date(user.joiningDate);
        calculationStartDate = joiningDate > earliestTargetDate ? joiningDate : earliestTargetDate;
      } else {
        calculationStartDate = earliestTargetDate;
      }
    } else if (user.joiningDate) {
      // Use joining date if available and no targets found
      calculationStartDate = new Date(user.joiningDate);
    } else {
      // Default to January 1, 2024 if no joining date or targets
      calculationStartDate = new Date(2024, 0, 1);
    }
    
    const calculationEndDate = endDate || now;
    
    // We already have the targets from earlier, don't fetch them again
    
    // Get sales data for this user - exclude cancelled sales
    const salesData = await db
      .select()
      .from(sales)
      .where(and(
        eq(sales.salesExecutiveId, userId),
        gte(
          sales.bookingDate, 
          // Format to YYYY-MM-DD to avoid timezone issues
          calculationStartDate.toISOString().substring(0, 10)
        ),
        lte(
          sales.bookingDate, 
          calculationEndDate.toISOString().substring(0, 10)
        ),
        isNull(sales.cancelledAt)
      ));
    
    console.log(`Found ${salesData.length} sales records for user ${userId}`);
    
    // Calculate achievements by month
    const achievements: Record<string, number> = {};
    
    for (const sale of salesData) {
      const saleDate = new Date(sale.bookingDate);
      const yearMonth = `${saleDate.getFullYear()}-${saleDate.getMonth() + 1}`;
      
      // Sum up area sold by month for achievement calculation
      if (!achievements[yearMonth]) {
        achievements[yearMonth] = 0;
      }
      
      // Make sure we have a valid number value for area sold
      // Handle different types of areaSold values that might come from the database
      let areaValue = 0;
      if (sale.areaSold !== null && sale.areaSold !== undefined) {
        if (typeof sale.areaSold === 'number') {
          areaValue = sale.areaSold;
        } else if (typeof sale.areaSold === 'string') {
          areaValue = parseFloat(sale.areaSold);
        }
      }
      
      if (!isNaN(areaValue)) {
        achievements[yearMonth] += areaValue;
      }
    }
    
    console.log(`Calculated achievements for user ${userId}:`, achievements);
    
    // Calculate monthly targets
    let totalTarget = 0;
    let totalAchievement = 0;
    const monthlyBreakdown = [];
    
    // Start from the first day of the first month
    const startMonth = calculationStartDate.getMonth();
    const startYear = calculationStartDate.getFullYear();
    const startDay = calculationStartDate.getDate();
    
    // Calculate up to the current month or end date
    const endMonth = calculationEndDate.getMonth(); 
    const endYear = calculationEndDate.getFullYear();
    const endDay = calculationEndDate.getDate();
    
    // Initialize current date for iteration
    let currentDate = new Date(startYear, startMonth, 1);
    
    // For each month in the range
    while (
      currentDate.getFullYear() < endYear || 
      (currentDate.getFullYear() === endYear && currentDate.getMonth() <= endMonth)
    ) {
      const year = currentDate.getFullYear();
      const month = currentDate.getMonth() + 1; // 1-12 format
      const yearMonthKey = `${year}-${month}`;
      
      // Get target for this month if exists
      const targetForMonth = allUserTargets.find((t: any) => t.year === year && t.month === month);
      
      // Only use the target value if it exists in the database
      // Do not use default values or monthly target from user profile
      // Always use exactly what was assigned in the Admin Panel without proration
      const monthlyTargetValue = targetForMonth ? targetForMonth.targetValue : 0;
      
      // Get achievement for this month
      const achievementForMonth = achievements[yearMonthKey] || 0;
      
      // Update totals
      totalTarget += monthlyTargetValue;
      totalAchievement += achievementForMonth;
      
      // Calculate percentage achieved
      const percentageAchieved = monthlyTargetValue > 0 
        ? (achievementForMonth / monthlyTargetValue) * 100 
        : 0;
      
      // Only add to monthly breakdown if there is an actual target assigned
      // or if there are sales achievements for this month
      if (targetForMonth || achievementForMonth > 0) {
        monthlyBreakdown.push({
          year,
          month,
          monthName: new Date(year, month - 1, 1).toLocaleString('default', { month: 'long' }),
          target: monthlyTargetValue,
          achieved: achievementForMonth,
          difference: achievementForMonth - monthlyTargetValue,
          percentageAchieved: percentageAchieved
        });
      }
      
      // Move to next month
      currentDate.setMonth(currentDate.getMonth() + 1);
    }
    
    // Sort monthly breakdown by most recent first
    monthlyBreakdown.sort((a, b) => {
      if (a.year !== b.year) return b.year - a.year;
      return b.month - a.month;
    });
    
    return {
      userId,
      userName: user.fullName,
      monthlyTarget: user.monthlyTarget || 0,
      joiningDate: user.joiningDate,
      calculationPeriod: {
        start: calculationStartDate,
        end: calculationEndDate
      },
      totalTarget,
      totalAchievement,
      difference: totalAchievement - totalTarget,
      percentageAchieved: totalTarget > 0 ? (totalAchievement / totalTarget) * 100 : 0,
      isPositive: totalAchievement >= totalTarget,
      monthlyBreakdown,
      yearProgress: Math.round((totalAchievement / totalTarget) * 100) // Added for consistency
    };
  }

  // Initialize with default data
  async seedInitialData() {
    // Check if roles exist
    const existingRoles = await this.getAllRoles();
    if (existingRoles.length === 0) {
      // Create initial roles
      const roles = [
        { name: "Super Admin", description: "System administrator with full access" },
        { name: "Admin", description: "Administrator with limited access" },
        { name: "Manager", description: "Department manager" },
        { name: "Sales Representative", description: "Sales team member" },
        { name: "Accountant", description: "Manages financial records and has access to Sales Management" },
        { name: "CRM", description: "Customer Relationship Management with full access to Sales Management" }
      ];
      
      for (const role of roles) {
        await this.createRole(role);
      }
    }
    
    // Check if departments exist
    const existingDepartments = await this.getAllDepartments();
    if (existingDepartments.length === 0) {
      // Create initial departments
      const departments = [
        { name: "HR", description: "Human Resources Department" },
        { name: "Sales", description: "Sales Department" },
        { name: "Development", description: "Development Department" },
        { name: "Marketing", description: "Marketing Department" }
      ];
      
      for (const dept of departments) {
        await this.createDepartment(dept);
      }
    }
  }

  // Payment management methods
  async createPayment(payment: InsertPayment): Promise<any> {
    try {
      const [result] = await db.insert(payments).values({
        saleId: payment.saleId, // This gets mapped to sale_id by Drizzle ORM
        paymentDate: payment.paymentDate,
        amount: payment.amount,
        paymentMode: payment.paymentMode,
        paymentType: payment.paymentType,
        remarks: payment.remarks || null,
        createdBy: payment.createdBy,
        createdAt: new Date()
      }).returning();
      
      return result;
    } catch (error) {
      console.error("Error creating payment:", error);
      throw new Error("Failed to create payment record");
    }
  }
  
  async getPaymentsBySale(saleId: number): Promise<any[]> {
    try {
      const result = await db.select({
        payment: payments,
        createdByName: users.fullName
      })
      .from(payments)
      .leftJoin(users, eq(payments.createdBy, users.id))
      .where(eq(payments.saleId, saleId)) // saleId maps to sale_id in DB
      .orderBy(desc(payments.paymentDate));
      
      // Transform the result to flatten the structure
      return result.map(row => ({
        ...row.payment,
        createdByName: row.createdByName
      }));
    } catch (error) {
      console.error("Error fetching payments:", error);
      return [];
    }
  }
  
  async getPayment(id: number): Promise<any> {
    try {
      const result = await db.select({
        payment: payments,
        createdByName: users.fullName
      })
      .from(payments)
      .leftJoin(users, eq(payments.createdBy, users.id))
      .where(eq(payments.id, id));
      
      if (result.length === 0) {
        return null;
      }
      
      // Transform the result to flatten the structure
      return {
        ...result[0].payment,
        createdByName: result[0].createdByName
      };
    } catch (error) {
      console.error("Error fetching payment:", error);
      return null;
    }
  }
  
  async updatePayment(id: number, paymentData: any): Promise<any> {
    try {
      const [updatedPayment] = await db
        .update(payments)
        .set({
          ...paymentData,
          updatedAt: new Date()
        })
        .where(eq(payments.id, id))
        .returning();
      
      return updatedPayment;
    } catch (error) {
      console.error("Error updating payment:", error);
      throw error;
    }
  }
  
  async getTotalPaymentsForSale(saleId: number): Promise<number> {
    try {
      const result = await db.execute(sql`
        SELECT SUM(CAST("amount" AS FLOAT)) as total_amount
        FROM ${payments}
        WHERE "sale_id" = ${saleId}
      `);
      
      // Handle the case where total_amount might be null
      const totalAmount = result.rows[0]?.total_amount;
      return totalAmount ? parseFloat(totalAmount.toString()) : 0;
    } catch (error) {
      console.error("Error calculating total payments:", error);
      return 0;
    }
  }

  // Incentive calculation methods
  async calculateIncentiveForSale(saleId: number): Promise<any> {
    try {
      // Get the sale details
      const saleData = await this.getSale(saleId);
      if (!saleData) {
        throw new Error('Sale not found');
      }

      const areaSold = parseFloat(saleData.areaSold);
      const totalRevenue = parseFloat(saleData.finalAmount || '0');
      
      // Define incentive slabs based on area sold (as per requirements document)
      const getIncentiveSlab = (area: number) => {
        if (area >= 7100) return { slab: 4, rate: 4.0 };  // 7,100 and above
        if (area >= 5000) return { slab: 3, rate: 3.0 };  // 5,000 to 6,999
        if (area >= 3000) return { slab: 2, rate: 2.0 };  // 3,000 to 4,999
        return { slab: 1, rate: 1.0 };                    // Up to 2,999
      };

      const slabInfo = getIncentiveSlab(areaSold);
      const grossIncentive = totalRevenue * (slabInfo.rate / 100);

      // Get payment percentage
      const totalPayments = await this.getTotalPaymentsForSale(saleId);
      const paymentPercentage = totalRevenue > 0 ? (totalPayments / totalRevenue) * 100 : 0;

      // Calculate milestone reached
      let milestoneReached = 0;
      if (paymentPercentage >= 100) milestoneReached = 100;
      else if (paymentPercentage >= 75) milestoneReached = 75;
      else if (paymentPercentage >= 50) milestoneReached = 50;
      else if (paymentPercentage >= 30) milestoneReached = 30;

      // Calculate eligible incentive based on milestone
      let eligibleIncentive = 0;
      if (milestoneReached >= 30) {
        eligibleIncentive = grossIncentive * (milestoneReached / 100);
      }

      const bookingDate = new Date(saleData.bookingDate);
      const quarter = Math.ceil((bookingDate.getMonth() + 1) / 3);
      const payoutMonth = quarter === 1 ? 4 : quarter === 2 ? 7 : quarter === 3 ? 10 : 1;
      const payoutYear = quarter === 4 ? bookingDate.getFullYear() + 1 : bookingDate.getFullYear();

      return {
        saleId,
        userId: saleData.salesExecutiveId,
        month: bookingDate.getMonth() + 1,
        year: bookingDate.getFullYear(),
        areaSold,
        totalRevenue,
        slabNumber: slabInfo.slab,
        incentiveRate: slabInfo.rate,
        grossIncentive,
        paymentPercentage,
        eligibleIncentive,
        quarter,
        payoutMonth,
        payoutYear,
        milestoneReached,
        isPaid: false
      };
    } catch (error) {
      console.error('Error calculating incentive:', error);
      throw error;
    }
  }

  async getUserIncentives(userId: number, month?: number, year?: number): Promise<any[]> {
    try {
      let whereConditions: any = eq(incentives.userId, userId);
      
      if (month && year) {
        whereConditions = and(
          whereConditions,
          eq(incentives.month, month),
          eq(incentives.year, year)
        );
      }

      const userIncentives = await db.select().from(incentives).where(whereConditions);
      return userIncentives;
    } catch (error) {
      console.error('Error fetching user incentives:', error);
      return [];
    }
  }

  async getUserIncentivesSummary(userId: number, month: number, year: number): Promise<any> {
    try {
      const incentivesData = await this.getUserIncentives(userId, month, year);
      
      const totalGrossIncentive = incentivesData.reduce((sum, inc) => sum + parseFloat(inc.grossIncentive.toString()), 0);
      const totalEligibleIncentive = incentivesData.reduce((sum, inc) => sum + parseFloat(inc.eligibleIncentive.toString()), 0);
      const totalAreaSold = incentivesData.reduce((sum, inc) => sum + parseFloat(inc.areaSold.toString()), 0);
      
      return {
        month,
        year,
        totalSales: incentivesData.length,
        totalAreaSold,
        totalGrossIncentive,
        totalEligibleIncentive,
        averageIncentiveRate: incentivesData.length > 0 ? totalGrossIncentive / incentivesData.length : 0,
        incentives: incentivesData
      };
    } catch (error) {
      console.error('Error getting incentives summary:', error);
      return null;
    }
  }

  async getUpcomingPayouts(userId: number): Promise<any[]> {
    try {
      const result = await db.select().from(incentivePayouts)
        .where(and(
          eq(incentivePayouts.userId, userId),
          eq(incentivePayouts.status, 'pending')
        ))
        .orderBy(desc(incentivePayouts.year), desc(incentivePayouts.quarter));

      return result;
    } catch (error) {
      console.error('Error fetching upcoming payouts:', error);
      return [];
    }
  }

  async getIncentiveHistory(userId: number): Promise<any[]> {
    try {
      const result = await db.select().from(incentivePayouts)
        .where(eq(incentivePayouts.userId, userId))
        .orderBy(desc(incentivePayouts.year), desc(incentivePayouts.quarter));

      return result;
    } catch (error) {
      console.error('Error fetching incentive history:', error);
      return [];
    }
  }

  async updatePaymentMilestones(): Promise<void> {
    try {
      // Get all sales with incomplete payments
      const allSales = await this.getAllSales();
      
      for (const sale of allSales) {
        const totalPayments = await this.getTotalPaymentsForSale(sale.id);
        const finalAmount = parseFloat(sale.finalAmount || '0');
        const paymentPercentage = finalAmount > 0 ? (totalPayments / finalAmount) * 100 : 0;

        // Update incentive records for this sale
        await db.update(incentives)
          .set({
            paymentPercentage,
            milestoneReached: paymentPercentage >= 100 ? 100 :
                             paymentPercentage >= 75 ? 75 :
                             paymentPercentage >= 50 ? 50 :
                             paymentPercentage >= 30 ? 30 : 0,
            eligibleIncentive: sql`CASE 
              WHEN ${paymentPercentage} >= 30 THEN "gross_incentive" * (${paymentPercentage} / 100)
              ELSE 0
            END`,
            updatedAt: new Date()
          })
          .where(eq(incentives.saleId, sale.id));
      }
    } catch (error) {
      console.error('Error updating payment milestones:', error);
      throw error;
    }
  }

  // Site Visit Management methods
  async createSiteVisit(siteVisit: InsertSiteVisit): Promise<SiteVisit> {
    const [createdSiteVisit] = await db
      .insert(siteVisits)
      .values(siteVisit)
      .returning();
    return createdSiteVisit;
  }

  async getSiteVisit(id: number): Promise<SiteVisit | undefined> {
    const [siteVisit] = await db
      .select()
      .from(siteVisits)
      .where(eq(siteVisits.id, id));
    return siteVisit || undefined;
  }

  async updateSiteVisit(id: number, siteVisitData: Partial<InsertSiteVisit>): Promise<SiteVisit | undefined> {
    const [updatedSiteVisit] = await db
      .update(siteVisits)
      .set({ ...siteVisitData, updatedAt: new Date() })
      .where(eq(siteVisits.id, id))
      .returning();
    return updatedSiteVisit || undefined;
  }

  async deleteSiteVisit(id: number): Promise<boolean> {
    const result = await db
      .delete(siteVisits)
      .where(eq(siteVisits.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getAllSiteVisits(): Promise<any[]> {
    return await db
      .select({
        id: siteVisits.id,
        status: siteVisits.status,
        createdAt: siteVisits.createdAt,
        salesExecutiveId: siteVisits.salesExecutiveId,
        customerName: siteVisits.customerName,
        remarks: siteVisits.remarks,
        visitDate: siteVisits.visitDate,
        visitTime: siteVisits.visitTime,
        pickupLocation: siteVisits.pickupLocation,
        projectIds: siteVisits.projectIds,
        notes: siteVisits.notes,
        approvedBy: siteVisits.approvedBy,
        approvedAt: siteVisits.approvedAt,
        assignedDriverId: siteVisits.assignedDriverId,
        startOdometer: siteVisits.startOdometer,
        endOdometer: siteVisits.endOdometer,
        completedAt: siteVisits.completedAt,
        cancelledBy: siteVisits.cancelledBy,
        cancelledAt: siteVisits.cancelledAt,
        updatedAt: siteVisits.updatedAt,
        salesExecutiveName: users.fullName
      })
      .from(siteVisits)
      .leftJoin(users, eq(siteVisits.salesExecutiveId, users.id))
      .orderBy(desc(siteVisits.createdAt));
  }

  async getSiteVisitsByUser(userId: number): Promise<any[]> {
    return await db
      .select({
        id: siteVisits.id,
        status: siteVisits.status,
        createdAt: siteVisits.createdAt,
        salesExecutiveId: siteVisits.salesExecutiveId,
        customerName: siteVisits.customerName,
        remarks: siteVisits.remarks,
        visitDate: siteVisits.visitDate,
        visitTime: siteVisits.visitTime,
        pickupLocation: siteVisits.pickupLocation,
        projectIds: siteVisits.projectIds,
        notes: siteVisits.notes,
        approvedBy: siteVisits.approvedBy,
        approvedAt: siteVisits.approvedAt,
        assignedDriverId: siteVisits.assignedDriverId,
        startOdometer: siteVisits.startOdometer,
        endOdometer: siteVisits.endOdometer,
        completedAt: siteVisits.completedAt,
        cancelledBy: siteVisits.cancelledBy,
        cancelledAt: siteVisits.cancelledAt,
        updatedAt: siteVisits.updatedAt,
        salesExecutiveName: users.fullName
      })
      .from(siteVisits)
      .leftJoin(users, eq(siteVisits.salesExecutiveId, users.id))
      .where(eq(siteVisits.salesExecutiveId, userId))
      .orderBy(desc(siteVisits.createdAt));
  }

  async getSiteVisitsByDriver(driverId: number): Promise<SiteVisit[]> {
    return await db
      .select()
      .from(siteVisits)
      .where(eq(siteVisits.assignedDriverId, driverId))
      .orderBy(desc(siteVisits.createdAt));
  }

  async approveSiteVisit(id: number, approvedBy: number, assignedDriverId?: number): Promise<SiteVisit | undefined> {
    const updateData: any = {
      status: 'approved',
      approvedBy,
      approvedAt: new Date(),
      updatedAt: new Date()
    };
    
    if (assignedDriverId) {
      updateData.assignedDriverId = assignedDriverId;
    }

    const [updatedSiteVisit] = await db
      .update(siteVisits)
      .set(updateData)
      .where(eq(siteVisits.id, id))
      .returning();
    return updatedSiteVisit || undefined;
  }

  async completeSiteVisit(id: number, startOdometer: number, endOdometer: number, remarks?: string): Promise<SiteVisit | undefined> {
    const [updatedSiteVisit] = await db
      .update(siteVisits)
      .set({
        status: 'completed',
        startOdometer: startOdometer.toString(),
        endOdometer: endOdometer.toString(),
        remarks,
        completedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(siteVisits.id, id))
      .returning();
    return updatedSiteVisit || undefined;
  }
}