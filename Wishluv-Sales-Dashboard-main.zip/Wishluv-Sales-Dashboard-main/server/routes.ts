import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import fetch from "node-fetch";
import { eq, inArray, sql, and, gte, lte, isNull } from "drizzle-orm";
import { db, pool } from "./db";
import { registerTeamRoutes } from "./team-routes";
import { registerManagerRoutes } from "./manager-routes";

// Helper function to handle nullable team queries
const teamFilter = (team: string | null) => {
  return team ? eq(users.team, team) : sql`${users.team} IS NULL`;
};
import { 
  insertUserSchema, 
  insertProjectSchema, 
  insertDepartmentSchema, 
  insertRoleSchema,
  insertActivitySchema,
  insertLeaderboardSchema,
  insertSalesSchema,
  insertTargetSchema,
  sales,
  targets,
  users,
  SalesDesignation
} from "@shared/schema";

// Helper function to create activity logs for user actions
async function logActivity(userId: number, description: string) {
  try {
    await storage.createActivity({
      userId,
      description
    });
  } catch (error) {
    console.error("Failed to log activity:", error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Register team performance routes
  registerTeamRoutes(app);
  
  // Register manager performance routes
  registerManagerRoutes(app);

  // Middleware to check if user is authenticated
  const isAuthenticated = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // User management routes
  app.get("/api/users", isAuthenticated, async (req, res, next) => {
    try {
      const allUsers = await storage.getAllUsers();
      res.json(allUsers);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/users/:id", isAuthenticated, async (req, res, next) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/users/:id", isAuthenticated, async (req, res, next) => {
    try {
      const parsedData = insertUserSchema.parse(req.body);
      const userId = parseInt(req.params.id);
      const user = await storage.updateUser(userId, parsedData);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  app.delete("/api/users/:id", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      const result = await storage.deleteUser(userId);
      if (!result) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Project management routes
  app.get("/api/projects", isAuthenticated, async (req, res, next) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req, res, next) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/projects", isAuthenticated, async (req, res, next) => {
    try {
      const parsedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject({
        ...parsedData,
        createdBy: req.user!.id,
      });
      
      // Log activity for project creation
      await logActivity(
        req.user!.id, 
        `${req.user!.fullName} created new project: ${project.name}`
      );
      
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  app.put("/api/projects/:id", isAuthenticated, async (req, res, next) => {
    try {
      const projectId = parseInt(req.params.id);
      const parsedData = insertProjectSchema.omit({ createdBy: true }).parse(req.body);
      const project = await storage.updateProject(projectId, parsedData);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });
  
  // Add PATCH endpoint for partial updates
  app.patch("/api/projects/:id", isAuthenticated, async (req, res, next) => {
    try {
      const projectId = parseInt(req.params.id);
      // Allow partial updates
      const parsedData = insertProjectSchema.omit({ createdBy: true }).partial().parse(req.body);
      const project = await storage.updateProject(projectId, parsedData);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      // Make sure we're returning valid JSON
      res.json({ success: true, project });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  app.delete("/api/projects/:id", isAuthenticated, async (req, res, next) => {
    try {
      const projectId = parseInt(req.params.id);
      const result = await storage.deleteProject(projectId);
      if (!result) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Department management routes
  app.get("/api/departments", isAuthenticated, async (req, res, next) => {
    try {
      const departments = await storage.getAllDepartments();
      res.json(departments);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/departments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const departmentId = parseInt(req.params.id);
      const department = await storage.getDepartment(departmentId);
      if (!department) {
        return res.status(404).json({ message: "Department not found" });
      }
      res.json(department);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/departments", isAuthenticated, async (req, res, next) => {
    try {
      const parsedData = insertDepartmentSchema.parse(req.body);
      const department = await storage.createDepartment(parsedData);
      res.status(201).json(department);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  app.put("/api/departments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const departmentId = parseInt(req.params.id);
      const parsedData = insertDepartmentSchema.parse(req.body);
      const department = await storage.updateDepartment(departmentId, parsedData);
      if (!department) {
        return res.status(404).json({ message: "Department not found" });
      }
      res.json(department);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  app.delete("/api/departments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const departmentId = parseInt(req.params.id);
      const result = await storage.deleteDepartment(departmentId);
      if (!result) {
        return res.status(404).json({ message: "Department not found" });
      }
      res.json({ message: "Department deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Role management routes
  app.get("/api/roles", isAuthenticated, async (req, res, next) => {
    try {
      const roles = await storage.getAllRoles();
      res.json(roles);
    } catch (error) {
      next(error);
    }
  });
  
  // Get role by name - used for permission checking
  app.get("/api/roles/by-name/:name", isAuthenticated, async (req, res, next) => {
    try {
      const roleName = req.params.name;
      
      // Get all roles and find the one with matching name (case-insensitive)
      const roles = await storage.getAllRoles();
      const role = roles.find(r => r.name.toLowerCase() === roleName.toLowerCase());
      
      if (!role) {
        return res.status(404).json({ error: "Role not found" });
      }
      
      res.json(role);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/roles/:id", isAuthenticated, async (req, res, next) => {
    try {
      const roleId = parseInt(req.params.id);
      const role = await storage.getRole(roleId);
      if (!role) {
        return res.status(404).json({ message: "Role not found" });
      }
      res.json(role);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/roles", isAuthenticated, async (req, res, next) => {
    try {
      const parsedData = insertRoleSchema.parse(req.body);
      const role = await storage.createRole(parsedData);
      res.status(201).json(role);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  app.put("/api/roles/:id", isAuthenticated, async (req, res, next) => {
    try {
      const roleId = parseInt(req.params.id);
      const parsedData = insertRoleSchema.parse(req.body);
      const role = await storage.updateRole(roleId, parsedData);
      if (!role) {
        return res.status(404).json({ message: "Role not found" });
      }
      res.json(role);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  app.delete("/api/roles/:id", isAuthenticated, async (req, res, next) => {
    try {
      const roleId = parseInt(req.params.id);
      const result = await storage.deleteRole(roleId);
      if (!result) {
        return res.status(404).json({ message: "Role not found" });
      }
      res.json({ message: "Role deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Activities routes
  app.get("/api/activities", isAuthenticated, async (req, res, next) => {
    try {
      const activities = await storage.getAllActivities();
      res.json(activities);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/activities", isAuthenticated, async (req, res, next) => {
    try {
      const parsedData = insertActivitySchema.parse({
        ...req.body,
        userId: req.user!.id,
      });
      const activity = await storage.createActivity(parsedData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  // Leaderboard routes
  app.get("/api/leaderboard", isAuthenticated, async (req, res, next) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/leaderboard", isAuthenticated, async (req, res, next) => {
    try {
      const parsedData = insertLeaderboardSchema.parse(req.body);
      const entry = await storage.createLeaderboardEntry(parsedData);
      res.status(201).json(entry);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });
  
  // Announcements routes
  app.get("/api/announcements", isAuthenticated, async (req, res, next) => {
    try {
      const announcements = await storage.getAllAnnouncements();
      res.json(announcements);
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/announcements", isAuthenticated, async (req, res, next) => {
    try {
      // Create a date string in the format "Apr 20, 2025"
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric' 
      };
      const dateStr = now.toLocaleDateString('en-US', options);
      
      const announcement = await storage.createAnnouncement({
        ...req.body,
        createdBy: req.user!.id,
        createdAt: dateStr
      });
      
      // Log activity for announcement creation
      await logActivity(
        req.user!.id, 
        `${req.user!.fullName} posted a new announcement: ${announcement.title}`
      );
      
      res.status(201).json(announcement);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/announcements/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const result = await storage.deleteAnnouncement(id);
      if (!result) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      res.json({ message: "Announcement deleted successfully" });
    } catch (error) {
      next(error);
    }
  });
  
  // Sales management routes
  app.get("/api/sales", isAuthenticated, async (req, res, next) => {
    try {
      const allSales = await storage.getAllSales();
      res.json(allSales);
    } catch (error) {
      next(error);
    }
  });
  
  // Get sales for a specific user (either their own sales or their team's sales if they are a manager)
  app.get("/api/sales/user", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Check if user is a Sales Executive or Executive - return only their sales
      if (user.designation === "Sales Executive" || user.designation === "Executive") {
        const userSales = await storage.getAllSales().then(sales => 
          sales.filter(sale => sale.salesExecutiveId === userId)
        );
        return res.json(userSales);
      }
      
      // Check if user is a Team Leader, Sales Head, or Manager - return their team's sales
      if (["Team Leader", "Sales Head", "Sales Manager", "Manager"].includes(user.designation || "")) {
        // Get all team members (users who report to this manager)
        const teamMembers = await storage.getAllUsers().then(users => 
          users.filter(u => u.reportingManagerId === userId)
        );
        
        // Get all team member IDs including the manager
        const teamIds = [userId, ...teamMembers.map(member => member.id)];
        
        // Get all sales from the team members
        const teamSales = await storage.getAllSales().then(sales =>
          sales.filter(sale => teamIds.includes(sale.salesExecutiveId))
        );
        
        return res.json(teamSales);
      }
      
      // For admin users or others, return all sales
      if (user.role && ["admin", "Admin", "Super Admin", "CRM", "Accountant"].includes(user.role as string)) {
        const allSales = await storage.getAllSales();
        return res.json(allSales);
      }
      
      // Default case - return empty array for users without proper permissions
      res.json([]);
    } catch (error) {
      next(error);
    }
  });
  
  // Payment routes
  app.get("/api/payments/:saleId", isAuthenticated, async (req, res, next) => {
    try {
      const saleId = parseInt(req.params.saleId);
      if (isNaN(saleId)) {
        return res.status(400).json({ error: "Invalid sale ID" });
      }
      
      const payments = await storage.getPaymentsBySale(saleId);
      res.json(payments);
    } catch (error) {
      next(error);
    }
  });
  
  // Get all payments across all sales (useful for dashboard charts)
  app.get("/api/payments", isAuthenticated, async (req, res, next) => {
    try {
      // Get all sales
      const allSales = await storage.getAllSales();
      
      // Get all projects for name lookup
      const allProjects = await storage.getAllProjects();
      const projectsMap = new Map();
      allProjects.forEach(project => {
        projectsMap.set(project.id, project.name);
      });
      
      // For each sale, get the payments
      const allPaymentsPromises = allSales.map(async (sale) => {
        const payments = await storage.getPaymentsBySale(sale.id);
        // Add sale information to each payment
        return payments.map(payment => ({
          ...payment,
          saleProjectId: sale.projectId,
          saleProjectName: projectsMap.get(sale.projectId) || `Project ${sale.projectId}`,
          saleCustomerName: sale.customerName,
          saleBookingDate: sale.bookingDate
        }));
      });
      
      const allPayments = await Promise.all(allPaymentsPromises);
      // Flatten array of arrays into a single array
      const flattenedPayments = allPayments.flat();
      
      res.json(flattenedPayments);
    } catch (error) {
      console.error("Error fetching all payments:", error);
      next(error);
    }
  });
  
  app.post("/api/payments", isAuthenticated, async (req, res, next) => {
    try {
      if (!req.body.saleId || !req.body.amount || !req.body.paymentDate || 
          !req.body.paymentMode || !req.body.paymentType) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Make sure user is authenticated
      if (!req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      console.log("Creating new payment with data:", req.body);
      
      // Ensure amount is consistently handled as a string
      const paymentAmount = typeof req.body.amount === 'number' 
        ? req.body.amount.toString() 
        : req.body.amount;
      
      const payment = await storage.createPayment({
        ...req.body,
        amount: paymentAmount,
        createdBy: req.user.id
      });
      
      // After creating the payment, we need to update the sale's payment information
      const sale = await storage.getSale(payment.saleId);
      let updatedSale = null;
      
      if (sale) {
        try {
          // Calculate new amount paid
          const totalPayments = await storage.getTotalPaymentsForSale(payment.saleId);
          const finalAmount = parseFloat(sale.finalAmount || "0");
          const paymentPercentage = finalAmount > 0 ? (totalPayments / finalAmount) * 100 : 0;
          
          console.log(`Updating sale #${payment.saleId} with payment information:`, {
            totalPayments,
            finalAmount,
            paymentPercentage
          });
          
          // Update the sale with new payment information
          updatedSale = await storage.updateSale(payment.saleId, {
            amountPaid: totalPayments.toString(),
            paymentPercentage: paymentPercentage.toString()
          });
          
          console.log("Updated sale:", updatedSale);
        } catch (error) {
          console.error("Error updating sale payment information:", error);
          // Continue since payment was created successfully, even if updating the sale failed
        }
        
        // Log activity
        await logActivity(
          req.user.id,
          `${req.user.fullName} recorded a payment of ₹${paymentAmount} for sale #${payment.saleId}`
        );
      }
      
      // Get the most up-to-date sale data to return to the client
      const updatedSaleData = await storage.getSale(payment.saleId);
      
      res.status(201).json({
        ...payment,
        updatedSaleData // Include the updated sale data
      });
    } catch (error) {
      console.error("Error creating payment:", error);
      next(error);
    }
  });
  
  // Update payment
  // Support both PATCH and PUT for payment updates to ensure compatibility with client
  app.patch("/api/payments/:id", isAuthenticated, handlePaymentUpdate);
  app.put("/api/payments/:id", isAuthenticated, handlePaymentUpdate);
  
  // Separate function to handle payment updates to avoid code duplication
  async function handlePaymentUpdate(req: any, res: any, next: any) {
    try {
      if (!req.body.amount || !req.body.paymentDate || 
          !req.body.paymentMode || !req.body.paymentType) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Make sure user is authenticated
      if (!req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const paymentId = parseInt(req.params.id);
      console.log(`Updating payment #${paymentId} with data:`, req.body);
      
      // First get the payment to check if it exists and get the saleId
      const existingPayment = await storage.getPayment(paymentId);
      if (!existingPayment) {
        return res.status(404).json({ error: "Payment not found" });
      }
      
      // Ensure amount is consistently handled as a string
      const paymentAmount = typeof req.body.amount === 'number' 
        ? req.body.amount.toString() 
        : req.body.amount;
      
      // Update the payment
      const payment = await storage.updatePayment(paymentId, {
        amount: paymentAmount,
        paymentDate: req.body.paymentDate,
        paymentMode: req.body.paymentMode,
        paymentType: req.body.paymentType,
        remarks: req.body.remarks
      });
      
      // After updating the payment, we need to update the sale's payment information
      const sale = await storage.getSale(existingPayment.saleId);
      if (sale) {
        // Calculate new amount paid
        const totalPayments = await storage.getTotalPaymentsForSale(existingPayment.saleId);
        const finalAmount = parseFloat(sale.finalAmount || "0");
        const paymentPercentage = finalAmount > 0 ? (totalPayments / finalAmount) * 100 : 0;
        
        console.log(`Recalculated payment totals for sale #${existingPayment.saleId}:`, {
          totalPayments,
          finalAmount,
          paymentPercentage
        });
        
        // Update the sale with new payment information
        const updatedSale = await storage.updateSale(existingPayment.saleId, {
          amountPaid: totalPayments.toString(),
          paymentPercentage: paymentPercentage.toString()
        });
        
        console.log("Updated sale data:", updatedSale);
        
        // Log activity
        await logActivity(
          req.user.id,
          `${req.user.fullName} updated a payment of ₹${paymentAmount} for sale #${existingPayment.saleId}`
        );
      }
      
      // Get the most up-to-date sale data to return to the client
      const updatedSaleData = await storage.getSale(existingPayment.saleId);
      
      res.status(200).json({
        ...payment,
        updatedSaleData // Include the updated sale data
      });
    } catch (error) {
      console.error("Error updating payment:", error);
      next(error);
    }
  }
  
  app.get("/api/sales/:id", isAuthenticated, async (req, res, next) => {
    try {
      const saleId = parseInt(req.params.id);
      const sale = await storage.getSale(saleId);
      if (!sale) {
        return res.status(404).json({ message: "Sale not found" });
      }
      res.json(sale);
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/sales", isAuthenticated, async (req, res, next) => {
    try {
      // Basic validation
      if (!req.user || !req.user.id) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      console.log("Sale creation request body:", req.body);
    
    // Check for required fields and log which ones are missing
    const requiredFields = ['salesExecutiveId', 'projectId', 'bookingDate', 'areaSold', 'baseSalePrice'];
    const missingFields = requiredFields.filter(field => !req.body[field]);
    
    if (missingFields.length > 0) {
      console.log("Missing fields:", missingFields);
      return res.status(400).json({ 
        error: "Missing required fields", 
        missingFields: missingFields 
      });
    }
      
      console.log("Creating sale with data:", {
        ...req.body,
        createdBy: req.user.id
      });
      
      // Calculate final amount (area sold * base sale price)
      const areaSold = parseFloat(req.body.areaSold);
      const baseSalePrice = parseFloat(req.body.baseSalePrice);
      const finalAmount = (areaSold * baseSalePrice).toString();
      
      // Use direct SQL query to bypass all schema validation issues
      const query = `
        INSERT INTO sales 
        (sales_executive_id, project_id, booking_date, customer_name, customer_mobile, area_sold, base_sale_price, final_amount, booking_amount, created_by, created_at, amount_paid, payment_percentage, development_charges, preferred_location_charge, plot_no, booking_done, booking_data, agreement_date)
        VALUES 
        ($1, $2, $3, $4, $5, $6, $7, $8, $8, $9, $10, '0', '0', $11, $12, $13, $14, $15, $16)
        RETURNING *;
      `;
      
      const values = [
        parseInt(req.body.salesExecutiveId),
        parseInt(req.body.projectId),
        req.body.bookingDate,
        req.body.customerName || null,
        req.body.customerMobile || null,
        req.body.areaSold,
        req.body.baseSalePrice,
        finalAmount,
        req.user.id,
        new Date(),
        req.body.developmentCharges || '0',
        req.body.preferredLocationCharge || '0',
        req.body.plotNo || null,
        req.body.bookingDone || 'No',
        req.body.bookingData || null,
        req.body.agreementDate || null
      ];
      
      const result = await pool.query(query, values);
      
      if (result.rows && result.rows.length > 0) {
        const newSale = result.rows[0];
        console.log("Sale created successfully:", newSale);
        
        // Log the activity
        await logActivity(
          req.user.id,
          `Created new sale - ₹${finalAmount} (${req.body.areaSold} sq. ft.) for Project ID ${req.body.projectId}`
        );
        
        return res.json(newSale);
      } else {
        throw new Error("Failed to insert sales record");
      }
    } catch (error) {
      console.error("Error creating sale:", error);
      res.status(500).json({ error: "Failed to create sale", details: String(error) });
    }
  });
  
  app.put("/api/sales/:id", isAuthenticated, async (req, res, next) => {
    try {
      // Basic validation
      if (!req.user || !req.user.id) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const saleId = parseInt(req.params.id);
      if (isNaN(saleId)) {
        return res.status(400).json({ error: "Invalid sale ID" });
      }
      
      // Check if the sale exists
      const existingSale = await storage.getSale(saleId);
      if (!existingSale) {
        return res.status(404).json({ error: "Sale not found" });
      }

      // Calculate the finalAmount based on area sold and base sale price
      const areaSold = parseFloat(req.body.areaSold);
      const baseSalePrice = parseFloat(req.body.baseSalePrice || '0');
      const finalAmount = (areaSold * baseSalePrice).toString();
      
      // Prepare the update data
      const updateData = {
        salesExecutiveId: parseInt(req.body.salesExecutiveId),
        projectId: parseInt(req.body.projectId),
        bookingDate: req.body.bookingDate,
        areaSold: req.body.areaSold,
        bookingAmount: req.body.bookingAmount,
        baseSalePrice: req.body.baseSalePrice,
        finalAmount: finalAmount,
        customerName: req.body.customerName,
        customerMobile: req.body.customerMobile,
        bookingDone: req.body.bookingDone,
        bookingData: req.body.bookingData,
        agreementDate: req.body.agreementDate,
        developmentCharges: req.body.developmentCharges || '0',
        preferredLocationCharge: req.body.preferredLocationCharge || '0',
        plotNo: req.body.plotNo || null
      };
      
      console.log("Updating sale with data:", updateData);
      
      // Use the storage method to update the sale
      const updatedSale = await storage.updateSale(saleId, updateData);
      
      if (!updatedSale) {
        throw new Error("Failed to update sale record");
      }
      
      console.log("Sale updated successfully:", updatedSale);
      
      // Log the activity
      if (req.user) {
        await logActivity(
          req.user.id,
          `Updated sale #${saleId} - ₹${finalAmount} for Project ID ${req.body.projectId}`
        );
      }
      
      return res.json(updatedSale);
    } catch (error) {
      console.error("Error updating sale:", error);
      res.status(500).json({ error: "Failed to update sale", details: String(error) });
    }
  });
  
  // Cancel sale instead of deleting
  app.patch("/api/sales/:id/cancel", isAuthenticated, async (req, res, next) => {
    try {
      const saleId = parseInt(req.params.id);
      const { cancellationReason } = req.body;
      
      if (!cancellationReason || cancellationReason.trim() === '') {
        return res.status(400).json({ message: "Cancellation reason is required" });
      }
      
      const cancelledSale = await storage.cancelSale(saleId, req.user!.id, cancellationReason);
      
      if (!cancelledSale) {
        return res.status(404).json({ message: "Sale not found" });
      }
      
      await logActivity(req.user!.id, `Cancelled sale #${saleId} - Reason: ${cancellationReason}`);
      res.json(cancelledSale);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/sales/:id", isAuthenticated, async (req, res, next) => {
    try {
      const saleId = parseInt(req.params.id);
      const result = await storage.deleteSale(saleId);
      if (!result) {
        return res.status(404).json({ message: "Sale not found" });
      }
      res.json({ message: "Sale deleted successfully" });
    } catch (error) {
      next(error);
    }
  });
  
  // Weather API endpoint (accessible to all authenticated users)
  app.get("/api/weather", isAuthenticated, async (req, res, next) => {
    try {
      const city = req.query.city as string;
      if (!city) {
        return res.status(400).json({ error: "City parameter is required" });
      }
      
      // Using wttr.in which is a free weather service that doesn't need API keys
      console.log("Requesting weather for city:", city);
      
      const url = `https://wttr.in/${encodeURIComponent(city)}?format=j1`;
      console.log("Weather API URL:", url);
      
      const response = await fetch(url);
      
      if (!response.ok) {
        const responseText = await response.text();
        console.log("Weather API error response:", responseText);
        throw new Error(`Weather API error: ${response.status} - ${responseText}`);
      }
      
      const weatherData = await response.json();
      console.log("Weather API response:", weatherData);
      
      res.json(weatherData);
    } catch (err: any) {
      console.error("Weather API error:", err);
      res.status(500).json({ error: "Failed to fetch weather data", details: err.message || String(err) });
    }
  });
  
  // Sales dashboard data routes - these need to be before the /api/sales/:id route to avoid conflict
  app.get("/api/sales-monthly", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const sales = await storage.getMonthlySalesByUser(userId);
      res.json(sales);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/sales-yearly", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const sales = await storage.getYearlySalesByUser(userId);
      res.json(sales);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/sales-contest", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const sales = await storage.getCrystalCityContestSales(userId);
      res.json(sales);
    } catch (error) {
      next(error);
    }
  });
  
  // Target vs Achievement API routes
  app.get("/api/targets", isAuthenticated, async (req, res, next) => {
    try {
      // Admin users can see all targets, others can only see their own
      const targets = req.user?.role === "admin" 
        ? await storage.getAllTargets()
        : await storage.getUserTargets(req.user?.id || 0);
      
      res.json(targets);
    } catch (error) {
      next(error);
    }
  });
  
  // Get a specific user's targets
  app.get("/api/targets/user/:userId", isAuthenticated, async (req, res, next) => {
    try {
      // Check if user is authorized (admin or viewing own targets)
      if (req.user?.role !== "admin" && req.user?.id !== parseInt(req.params.userId)) {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const userId = parseInt(req.params.userId);
      const targets = await storage.getUserTargets(userId);
      
      res.json(targets);
    } catch (error) {
      next(error);
    }
  });
  
  // Add a target (duplicate route - removing this one)
  // app.post("/api/targets", isAuthenticated, async (req, res, next) => {
  //   try {
  //     // Only admin users can add targets
  //     if (req.user?.role !== "admin") {
  //       return res.status(403).json({ error: "Unauthorized" });
  //     }
  //     
  //     const target = await storage.createTarget(req.body);
  //     await logActivity(req.user?.id || 0, `Added target for user ID ${req.body.userId}`);
  //     
  //     res.status(201).json(target);
  //   } catch (error) {
  //     next(error);
  //   }
  // });
  
  // Update a target (duplicate route - removing this one)
  // app.put("/api/targets/:id", isAuthenticated, async (req, res, next) => {
  //   try {
  //     // Only admin users can update targets
  //     if (req.user?.role !== "admin") {
  //       return res.status(403).json({ error: "Unauthorized" });
  //     }
  //     
  //     const targetId = parseInt(req.params.id);
  //     const updatedTarget = await storage.updateTarget(targetId, req.body);
  //     
  //     if (!updatedTarget) {
  //       return res.status(404).json({ error: "Target not found" });
  //     }
  //     
  //     await logActivity(req.user?.id || 0, `Updated target ID ${targetId}`);
  //     
  //     res.json(updatedTarget);
  //   } catch (error) {
  //     next(error);
  //   }
  // });
  
  // Delete a target (duplicate route - removing this one)
  // app.delete("/api/targets/:id", isAuthenticated, async (req, res, next) => {
  //   try {
  //     // Only admin users can delete targets
  //     if (req.user?.role !== "admin") {
  //       return res.status(403).json({ error: "Unauthorized" });
  //     }
  //     
  //     const targetId = parseInt(req.params.id);
  //     const success = await storage.deleteTarget(targetId);
  //     
  //     if (!success) {
  //       return res.status(404).json({ error: "Target not found" });
  //     }
  //     
  //     await logActivity(req.user?.id || 0, `Deleted target ID ${targetId}`);
  //     
  //     res.json({ success: true });
  //   } catch (error) {
  //     next(error);
  //   }
  // });
  
  // Get achievement data for a user
  app.get("/api/targets/achievement/:userId", isAuthenticated, async (req, res, next) => {
    try {
      // Check if user is authorized (admin or viewing own achievements)
      if (req.user?.role !== "admin" && req.user?.id !== parseInt(req.params.userId)) {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const userId = parseInt(req.params.userId);
      
      // Get optional date range from query params
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      // Use cache busting query parameter to ensure fresh data
      const forceFresh = req.query.fresh === 'true';
      
      // Log the request for debugging
      console.log(`Achievement request for user ${userId}`, { 
        startDate, 
        endDate, 
        forceFresh,
        timestamp: new Date().toISOString()
      });
      
      const achievementData = await storage.calculateUserAchievement(userId, startDate, endDate);
      
      // Add cache control headers to prevent caching
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      res.json(achievementData);
    } catch (error) {
      console.error(`Error calculating achievement for user ${req.params.userId}:`, error);
      next(error);
    }
  });
  
  // Get team-specific monthly sales data
  app.get("/api/team-sales-monthly", isAuthenticated, async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const { department, designation, team } = req.user;
      
      // If not from Sales department, deny access
      if (department !== "Sales") {
        return res.status(403).json({ error: "Access denied: Not a Sales department member" });
      }
      
      // If not a Team Leader or Sales Head, deny access
      if (designation !== SalesDesignation.TEAM_LEADER && designation !== SalesDesignation.SALES_HEAD) {
        return res.status(403).json({ error: "Access denied: Insufficient permissions" });
      }
      
      let teamToQuery = req.query.team as string;
      
      // For Team Leaders, they can only see their own team's data
      if (designation === SalesDesignation.TEAM_LEADER && teamToQuery !== team) {
        return res.status(403).json({ error: "Access denied: You can only view your own team's data" });
      }
      
      // Get current month's first and last day
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      const firstDayStr = firstDay.toISOString().split('T')[0];
      const lastDayStr = lastDay.toISOString().split('T')[0];
      
      // Get all sales staff in the specified team or all teams for Sales Head
      let salesStaff;
      
      if (designation === SalesDesignation.SALES_HEAD) {
        // Sales Head can see all teams or filter by team
        if (teamToQuery) {
          salesStaff = await db.select().from(users).where(teamFilter(teamToQuery));
        } else {
          salesStaff = await db.select().from(users).where(eq(users.department, "Sales"));
        }
      } else {
        // Team Leader can only see their team
        salesStaff = await db.select().from(users).where(teamFilter(team));
      }
      
      // Get the user IDs of all team members
      const teamMemberIds = salesStaff.map(user => user.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]);  // No team members found
      }
      
      // Get monthly sales data for the team members
      const result = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        team: users.team,
        totalSales: sql`SUM(${sales.finalAmount})`.as("totalSales"),
        totalArea: sql`SUM(${sales.areaSold})`.as("totalArea"),
        salesCount: sql`COUNT(*)`.as("salesCount")
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(
        sql`${sales.bookingDate} >= ${firstDayStr} AND ${sales.bookingDate} <= ${lastDayStr} AND ${inArray(sales.salesExecutiveId, teamMemberIds)}`
      )
      .groupBy(sales.salesExecutiveId, users.fullName, users.team)
      .orderBy(sql`SUM(${sales.finalAmount}) DESC`);
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching team monthly sales:", error);
      next(error);
    }
  });
  
  // Get team-specific yearly sales data
  app.get("/api/team-sales-yearly", isAuthenticated, async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const { department, designation, team } = req.user;
      
      // If not from Sales department, deny access
      if (department !== "Sales") {
        return res.status(403).json({ error: "Access denied: Not a Sales department member" });
      }
      
      // If not a Team Leader or Sales Head, deny access
      if (designation !== SalesDesignation.TEAM_LEADER && designation !== SalesDesignation.SALES_HEAD) {
        return res.status(403).json({ error: "Access denied: Insufficient permissions" });
      }
      
      let teamToQuery = req.query.team as string;
      
      // For Team Leaders, they can only see their own team's data
      if (designation === SalesDesignation.TEAM_LEADER && teamToQuery !== team) {
        return res.status(403).json({ error: "Access denied: You can only view your own team's data" });
      }
      
      // Get current year's first day
      const currentYear = new Date().getFullYear();
      const firstDayOfYear = `${currentYear}-01-01`;
      
      // Get all sales staff in the specified team or all teams for Sales Head
      let salesStaff;
      
      if (designation === SalesDesignation.SALES_HEAD) {
        // Sales Head can see all teams or filter by team
        if (teamToQuery) {
          salesStaff = await db.select().from(users).where(teamFilter(teamToQuery));
        } else {
          salesStaff = await db.select().from(users).where(eq(users.department, "Sales"));
        }
      } else {
        // Team Leader can only see their team
        salesStaff = await db.select().from(users).where(teamFilter(team));
      }
      
      // Get the user IDs of all team members
      const teamMemberIds = salesStaff.map(user => user.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]);  // No team members found
      }
      
      // Get yearly sales data for the team members
      const result = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        team: users.team,
        totalSales: sql`SUM(${sales.finalAmount})`.as("totalSales"),
        totalArea: sql`SUM(${sales.areaSold})`.as("totalArea"),
        salesCount: sql`COUNT(*)`.as("salesCount")
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(
        sql`${sales.bookingDate} >= ${firstDayOfYear} AND ${inArray(sales.salesExecutiveId, teamMemberIds)}`
      )
      .groupBy(sales.salesExecutiveId, users.fullName, users.team)
      .orderBy(sql`SUM(${sales.finalAmount}) DESC`);
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching team yearly sales:", error);
      next(error);
    }
  });
  
  // Get aggregated team sales data for all time
  app.get("/api/team-sales", isAuthenticated, async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const { department, designation, team } = req.user;
      
      // If not from Sales department, deny access
      if (department !== "Sales") {
        return res.status(403).json({ error: "Access denied: Not a Sales department member" });
      }
      
      // If not a Team Leader or Sales Head, deny access
      if (designation !== SalesDesignation.TEAM_LEADER && designation !== SalesDesignation.SALES_HEAD) {
        return res.status(403).json({ error: "Access denied: Insufficient permissions" });
      }
      
      let teamToQuery = req.query.team as string;
      
      // For Team Leaders, they can only see their own team's data
      if (designation === SalesDesignation.TEAM_LEADER && teamToQuery !== team) {
        return res.status(403).json({ error: "Access denied: You can only view your own team's data" });
      }
      
      // Get all sales staff in the specified team or all teams for Sales Head
      let salesStaff;
      
      if (designation === SalesDesignation.SALES_HEAD) {
        // Sales Head can see all teams or filter by team
        if (teamToQuery) {
          salesStaff = await db.select().from(users).where(teamFilter(teamToQuery));
        } else {
          salesStaff = await db.select().from(users).where(eq(users.department, "Sales"));
        }
      } else {
        // Team Leader can only see their team
        salesStaff = await db.select().from(users).where(teamFilter(team));
      }
      
      // Get the user IDs of all team members
      const teamMemberIds = salesStaff.map(user => user.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]);  // No team members found
      }
      
      // Get sales data for all team members
      const result = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        team: users.team,
        totalSales: sql`SUM(${sales.finalAmount})`.as("totalSales"),
        totalArea: sql`SUM(${sales.areaSold})`.as("totalArea"),
        salesCount: sql`COUNT(*)`.as("salesCount")
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(inArray(sales.salesExecutiveId, teamMemberIds))
      .groupBy(sales.salesExecutiveId, users.fullName, users.team)
      .orderBy(sql`SUM(${sales.finalAmount}) DESC`);
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching team sales:", error);
      next(error);
    }
  });

  // TEMPORARY endpoint for development only - to be removed
  app.get("/api/reset-test-passwords", async (req, res) => {
    try {
      // Import required modules
      const { scrypt, randomBytes } = await import('crypto');
      const { promisify } = await import('util');
      const { users } = await import('@shared/schema');
      const { eq } = await import('drizzle-orm');
      const { db } = await import('./db');
      
      const scryptAsync = promisify(scrypt);
      
      // Hash password function
      const hashPassword = async (password: string) => {
        const salt = randomBytes(16).toString("hex");
        const buf = (await scryptAsync(password, salt, 64)) as Buffer;
        return `${buf.toString("hex")}.${salt}`;
      };
      
      // Create a simple password for testing
      const hashedPassword = await hashPassword("password123");
      
      // Reset the admin user password
      await db.update(users)
        .set({ password: hashedPassword })
        .where(eq(users.email, "admin@wishluv.com"));
        
      // Reset the test user password
      await db.update(users)
        .set({ password: hashedPassword })
        .where(eq(users.email, "test@test.com"));
        
      console.log("Test passwords reset successfully");
      res.json({ 
        success: true, 
        message: "Test passwords reset to 'password123'",
        users: [
          { email: "admin@wishluv.com", role: "admin" },
          { email: "test@test.com", role: "Sales Representative" }
        ]
      });
    } catch (error) {
      console.error("Error resetting passwords:", error);
      res.status(500).json({ success: false, message: "Failed to reset passwords", error: String(error) });
    }
  });

  // Target vs Achievement API Routes
  // Get all targets or targets by user ID
  app.get("/api/targets", isAuthenticated, async (req, res, next) => {
    try {
      console.log("GET /api/targets called with query:", req.query);
      
      if (req.query.userId) {
        const userId = parseInt(req.query.userId as string);
        console.log("Fetching targets for userId:", userId);
        const targets = await storage.getUserTargets(userId);
        console.log("User targets found:", targets.length);
        return res.json(targets);
      }
      
      console.log("Fetching all targets");
      const targets = await storage.getAllTargets();
      console.log("All targets found:", targets.length);
      res.json(targets);
    } catch (error) {
      console.error("Error in GET /api/targets:", error);
      next(error);
    }
  });
  
  // Calculate user achievement - new endpoint to match client requests
  app.get("/api/targets/achievement/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Check if this is the same user or a manager/admin
      if (req.user?.id !== userId && req.user?.designation !== "Manager" && 
          req.user?.designation !== "Admin" && req.user?.role !== "Admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Used for logging/debugging
      console.log("Achievement request for user", userId, {
        startDate: req.query.startDate ? new Date(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate as string) : undefined,
        forceFresh: req.query.fresh === "true",
        timestamp: new Date().toISOString()
      });
      
      // Parse optional date parameters
      let startDate = undefined;
      let endDate = undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
      }
      
      const achievementData = await storage.calculateUserAchievement(userId, startDate, endDate);
      res.json(achievementData);
    } catch (error) {
      console.error("Error calculating achievements:", error);
      res.status(500).json({ 
        error: "Failed to calculate achievements", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get targets by user ID
  app.get("/api/targets/user/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      const targets = await storage.getUserTargets(userId);
      res.json(targets);
    } catch (error) {
      next(error);
    }
  });
  


  // Create a new target
  app.post("/api/targets", isAuthenticated, async (req, res, next) => {
    try {
      const parsedData = insertTargetSchema.parse(req.body);
      const target = await storage.createTarget(parsedData);
      
      // Log activity
      if (req.user) {
        await logActivity(
          req.user.id,
          `Created monthly target of ${target.targetValue} sq ft for User ID ${target.userId} (${target.year}-${target.month})`
        );
      }
      
      res.status(201).json(target);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  // Update a target
  app.put("/api/targets/:id", isAuthenticated, async (req, res, next) => {
    try {
      const targetId = parseInt(req.params.id);
      const parsedData = insertTargetSchema.partial().parse(req.body);
      const target = await storage.updateTarget(targetId, parsedData);
      
      if (!target) {
        return res.status(404).json({ message: "Target not found" });
      }
      
      // Log activity
      if (req.user) {
        await logActivity(
          req.user.id,
          `Updated monthly target for User ID ${target.userId} (${target.year}-${target.month})`
        );
      }
      
      res.json(target);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      next(error);
    }
  });

  // Delete a target
  app.delete("/api/targets/:id", isAuthenticated, async (req, res, next) => {
    try {
      const targetId = parseInt(req.params.id);
      const result = await storage.deleteTarget(targetId);
      
      if (!result) {
        return res.status(404).json({ message: "Target not found" });
      }
      
      // Log activity
      if (req.user) {
        await logActivity(req.user.id, `Deleted target ID ${targetId}`);
      }
      
      res.json({ message: "Target deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Calculate user achievement
  app.get("/api/achievements/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Parse optional date parameters
      let startDate = undefined;
      let endDate = undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
      }
      
      const achievementData = await storage.calculateUserAchievement(userId, startDate, endDate);
      res.json(achievementData);
    } catch (error) {
      console.error("Error calculating achievements:", error);
      res.status(500).json({ 
        error: "Failed to calculate achievements", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get target by user, year, and month
  app.get("/api/targets/:userId/:year/:month", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      const target = await storage.getTarget(userId, year, month);
      
      if (!target) {
        return res.status(404).json({ message: "Target not found" });
      }
      
      res.json(target);
    } catch (error) {
      next(error);
    }
  });

  // Update user joining date and monthly target
  app.put("/api/users/:id/target-info", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Validate request data
      if (typeof req.body.joiningDate !== 'string' && req.body.joiningDate !== null) {
        return res.status(400).json({ error: "joiningDate must be a string date or null" });
      }
      
      if (typeof req.body.monthlyTarget !== 'number' && req.body.monthlyTarget !== null) {
        return res.status(400).json({ error: "monthlyTarget must be a number or null" });
      }
      
      // Convert joiningDate string to Date object if provided
      let joiningDate = req.body.joiningDate ? new Date(req.body.joiningDate) : null;
      
      // Update the user
      const updatedUser = await storage.updateUser(userId, {
        joiningDate,
        monthlyTarget: req.body.monthlyTarget
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Log activity
      if (req.user) {
        await logActivity(
          req.user.id,
          `Updated target info for user ${updatedUser.fullName} (ID: ${userId})`
        );
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user target info:", error);
      res.status(500).json({ 
        error: "Failed to update user target info", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  // Get monthly sales data - for dashboard stats card
  app.get("/api/sales-monthly", isAuthenticated, async (req, res, next) => {
    try {
      // Get current month's sales data
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      
      const firstDayStr = firstDayOfMonth.toISOString().split('T')[0];
      const lastDayStr = lastDayOfMonth.toISOString().split('T')[0];
      
      // Query to fetch all sales for the current month
      const monthlySales = await db
        .select()
        .from(sales)
        .where(
          sql`${sales.bookingDate} >= ${firstDayStr} AND ${sales.bookingDate} <= ${lastDayStr}`
        );
      
      res.json(monthlySales);
    } catch (error) {
      console.error("Error fetching monthly sales data:", error);
      next(error);
    }
  });

  // Incentive Plan API Routes
  app.get("/api/incentives/user/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      const { month, year } = req.query;
      
      // Authorization check - users can only see their own incentives unless admin
      if (req.user?.id !== userId && req.user?.role !== "admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const incentives = await storage.getUserIncentives(
        userId,
        month ? parseInt(month as string) : undefined,
        year ? parseInt(year as string) : undefined
      );
      
      res.json(incentives);
    } catch (error: any) {
      console.error("Error fetching user incentives:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/incentives/summary/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      const currentMonth = new Date().getMonth() + 1;
      const currentYear = new Date().getFullYear();
      
      // Authorization check
      if (req.user?.id !== userId && req.user?.role !== "admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const summary = await storage.getUserIncentivesSummary(userId, currentMonth, currentYear);
      
      res.json(summary);
    } catch (error: any) {
      console.error("Error fetching incentives summary:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/incentives/payouts/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Authorization check
      if (req.user?.id !== userId && req.user?.role !== "admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const upcomingPayouts = await storage.getUpcomingPayouts(userId);
      res.json(upcomingPayouts);
    } catch (error: any) {
      console.error("Error fetching upcoming payouts:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/incentives/history/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Authorization check
      if (req.user?.id !== userId && req.user?.role !== "admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const history = await storage.getIncentiveHistory(userId);
      res.json(history);
    } catch (error: any) {
      console.error("Error fetching incentive history:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/incentives/calculate/:saleId", isAuthenticated, async (req, res, next) => {
    try {
      const saleId = parseInt(req.params.saleId);
      const incentiveData = await storage.calculateIncentiveForSale(saleId);
      
      res.json(incentiveData);
    } catch (error: any) {
      console.error("Error calculating incentive:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/incentives/update-milestones", isAuthenticated, async (req, res, next) => {
    try {
      // Only admin can trigger milestone updates
      if (req.user?.role !== "admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      await storage.updatePaymentMilestones();
      res.json({ message: "Payment milestones updated successfully" });
    } catch (error: any) {
      console.error("Error updating payment milestones:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Site Visit Management API Routes
  
  // Get all site visits (Super Admin and Sales Executives)
  app.get("/api/site-visits", isAuthenticated, async (req, res, next) => {
    try {
      // Allow Super Admin and Sales department users (Sales Executive, Sales Representative, etc.)
      const isAdmin = req.user?.role === "Super Admin" || req.user?.designation === "Super Admin";
      const isSalesUser = req.user?.department === "Sales" || req.user?.role === "Sales Executive" || req.user?.role === "Sales Representative";
      
      if (!isAdmin && !isSalesUser) {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const siteVisits = await storage.getAllSiteVisits();
      res.json(siteVisits);
    } catch (error) {
      next(error);
    }
  });

  // Get site visits by sales executive
  app.get("/api/site-visits/sales/:userId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Check if requesting own data or is admin
      if (req.user?.id !== userId && req.user?.role !== "Super Admin" && req.user?.designation !== "Super Admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const siteVisits = await storage.getSiteVisitsByUser(userId);
      res.json(siteVisits);
    } catch (error) {
      next(error);
    }
  });

  // Get site visits by driver
  app.get("/api/site-visits/driver/:driverId", isAuthenticated, async (req, res, next) => {
    try {
      const driverId = parseInt(req.params.driverId);
      
      // Check if requesting own data or is admin
      if (req.user?.id !== driverId && req.user?.role !== "Super Admin" && req.user?.designation !== "Super Admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const siteVisits = await storage.getSiteVisitsByDriver(driverId);
      res.json(siteVisits);
    } catch (error) {
      next(error);
    }
  });

  // Create a new site visit request
  app.post("/api/site-visits", isAuthenticated, async (req, res, next) => {
    try {
      const siteVisitData = {
        ...req.body,
        salesExecutiveId: req.user?.id,
        projectIds: JSON.stringify(req.body.projectIds) // Store as JSON string
      };
      
      const siteVisit = await storage.createSiteVisit(siteVisitData);
      
      // Log activity
      if (req.user) {
        await logActivity(
          req.user.id,
          `Created site visit request for ${siteVisit.customerName} on ${siteVisit.visitDate}`
        );
      }
      
      res.status(201).json(siteVisit);
    } catch (error) {
      next(error);
    }
  });

  // Approve/Decline site visit (Super Admin only)
  app.put("/api/site-visits/:id/approve", isAuthenticated, async (req, res, next) => {
    try {
      if (req.user?.role !== "Super Admin" && req.user?.designation !== "Super Admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const visitId = parseInt(req.params.id);
      const { status, assignedDriverId } = req.body;
      
      let updatedSiteVisit;
      if (status === 'approved') {
        updatedSiteVisit = await storage.approveSiteVisit(visitId, req.user.id, assignedDriverId);
      } else {
        updatedSiteVisit = await storage.updateSiteVisit(visitId, { 
          status: 'declined',
          approvedBy: req.user.id,
          approvedAt: new Date()
        });
      }
      
      // Log activity
      await logActivity(
        req.user.id,
        `${status === 'approved' ? 'Approved' : 'Declined'} site visit request ID ${visitId}`
      );
      
      res.json(updatedSiteVisit);
    } catch (error) {
      next(error);
    }
  });

  // Complete site visit (Driver only)
  app.put("/api/site-visits/:id/complete", isAuthenticated, async (req, res, next) => {
    try {
      const visitId = parseInt(req.params.id);
      const { startOdometer, endOdometer, remarks } = req.body;
      
      // Check if user is assigned driver for this visit
      const siteVisit = await storage.getSiteVisit(visitId);
      if (!siteVisit || siteVisit.assignedDriverId !== req.user?.id) {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const updatedSiteVisit = await storage.completeSiteVisit(
        visitId, 
        startOdometer, 
        endOdometer, 
        remarks
      );
      
      // Log activity
      if (req.user) {
        await logActivity(
          req.user.id,
          `Completed site visit for ${siteVisit.customerName} - ODO: ${startOdometer} to ${endOdometer}`
        );
      }
      
      res.json(updatedSiteVisit);
    } catch (error) {
      next(error);
    }
  });

  // Delete site visit (Super Admin only)
  app.delete("/api/site-visits/:id", isAuthenticated, async (req, res, next) => {
    try {
      if (req.user?.role !== "Super Admin" && req.user?.designation !== "Super Admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const visitId = parseInt(req.params.id);
      const siteVisit = await storage.getSiteVisit(visitId);
      
      if (!siteVisit) {
        return res.status(404).json({ error: "Site visit not found" });
      }
      
      const result = await storage.deleteSiteVisit(visitId);
      
      if (!result) {
        return res.status(500).json({ error: "Failed to delete site visit" });
      }
      
      // Log activity
      await logActivity(
        req.user.id,
        `Deleted site visit request for ${siteVisit.customerName} (ID: ${visitId})`
      );
      
      res.json({ message: "Site visit deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Update site visit (Sales Executive can edit their own)
  app.put("/api/site-visits/:id", isAuthenticated, async (req, res, next) => {
    try {
      const visitId = parseInt(req.params.id);
      const siteVisit = await storage.getSiteVisit(visitId);
      
      if (!siteVisit) {
        return res.status(404).json({ error: "Site visit not found" });
      }
      
      // Check if user is the sales executive who created this visit or is admin
      if (siteVisit.salesExecutiveId !== req.user?.id && 
          req.user?.role !== "Super Admin" && 
          req.user?.designation !== "Super Admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      // Prepare update data
      const updateData = {
        ...req.body,
        projectIds: req.body.projectIds ? JSON.stringify(req.body.projectIds) : siteVisit.projectIds
      };
      
      const updatedSiteVisit = await storage.updateSiteVisit(visitId, updateData);
      
      // Log activity
      await logActivity(
        req.user.id,
        `Updated site visit request for ${updateData.customerName || siteVisit.customerName} (ID: ${visitId})`
      );
      
      res.json(updatedSiteVisit);
    } catch (error) {
      next(error);
    }
  });

  // Cancel site visit (Sales Executive can cancel their own)
  app.put("/api/site-visits/:id/cancel", isAuthenticated, async (req, res, next) => {
    try {
      const visitId = parseInt(req.params.id);
      const siteVisit = await storage.getSiteVisit(visitId);
      
      if (!siteVisit) {
        return res.status(404).json({ error: "Site visit not found" });
      }
      
      // Check if user is the sales executive who created this visit or is admin
      if (siteVisit.salesExecutiveId !== req.user?.id && 
          req.user?.role !== "Super Admin" && 
          req.user?.designation !== "Super Admin") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const updatedSiteVisit = await storage.updateSiteVisit(visitId, { 
        status: 'cancelled',
        cancelledBy: req.user.id,
        cancelledAt: new Date()
      });
      
      // Log activity
      await logActivity(
        req.user.id,
        `Cancelled site visit request for ${siteVisit.customerName} (ID: ${visitId})`
      );
      
      res.json(updatedSiteVisit);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}