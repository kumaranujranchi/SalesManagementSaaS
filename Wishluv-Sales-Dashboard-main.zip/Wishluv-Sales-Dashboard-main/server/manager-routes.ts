import type { Express } from "express";
import { eq, inArray, sql, and, gte, lte } from "drizzle-orm";
import { db } from "./db";
import { sales, users, targets, SalesDesignation } from "@shared/schema";

// Manager performance endpoints for sales dashboard
export function registerManagerRoutes(app: Express) {
  // API endpoint to check if a user is a manager (has direct reports)
  app.get("/api/is-manager", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;

      // Count how many users report to this manager
      const [result] = await db.select({
        count: sql<number>`COUNT(*)`
      })
      .from(users)
      .where(eq(users.reportingManagerId, managerId));
      
      const isManager = result.count > 0;

      res.json({ isManager, directReportsCount: result.count });
    } catch (error) {
      console.error("Error checking manager status:", error);
      res.status(500).send("Error checking manager status");
    }
  });

  // API endpoint to get team members for a manager
  app.get("/api/manager-team", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;

      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      res.json(teamMembers);
    } catch (error) {
      console.error("Error getting team members:", error);
      res.status(500).send("Error retrieving team members");
    }
  });

  // API endpoint to get team sales data for managers (all time)
  app.get("/api/manager-sales", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;

      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      // Get the user IDs of all team members
      const teamMemberIds = teamMembers.map(member => member.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]); // No team members found
      }

      // Get all sales for the team members
      const teamSalesData = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        imageUrl: users.imageUrl,
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(inArray(sales.salesExecutiveId, teamMemberIds))
      .groupBy(sales.salesExecutiveId, users.fullName, users.imageUrl);

      // Get team total metrics
      const [teamTotal] = await db.select({
        totalTeamSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalTeamArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        totalTeamCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(inArray(sales.salesExecutiveId, teamMemberIds));

      res.json({
        teamMembers: teamSalesData,
        teamTotal
      });
    } catch (error) {
      console.error("Error getting manager sales data:", error);
      res.status(500).send("Error retrieving manager sales data");
    }
  });

  // API endpoint to get team monthly sales data for managers
  app.get("/api/manager-sales-monthly", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;

      // Get monthly date range
      const today = new Date();
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      
      const firstDayStr = firstDay.toISOString().split('T')[0];
      const lastDayStr = lastDay.toISOString().split('T')[0];
      
      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      // Get the user IDs of all team members
      const teamMemberIds = teamMembers.map(member => member.id);
      
      if (teamMemberIds.length === 0) {
        return res.json({ teamMembers: [], teamTotal: { totalTeamSales: 0, totalTeamArea: 0, totalTeamCount: 0 } }); 
      }

      // Get monthly sales for the team members
      const teamMonthlySalesData = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        imageUrl: users.imageUrl,
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      )
      .groupBy(sales.salesExecutiveId, users.fullName, users.imageUrl);

      // Get team total metrics for the month
      const [teamMonthlyTotal] = await db.select({
        totalTeamSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalTeamArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        totalTeamCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      );

      res.json({
        teamMembers: teamMonthlySalesData,
        teamTotal: teamMonthlyTotal
      });
    } catch (error) {
      console.error("Error getting manager monthly sales data:", error);
      res.status(500).send("Error retrieving manager monthly sales data");
    }
  });

  // API endpoint to get monthly sales data for the entire year (for graphs)
  app.get("/api/manager-monthly-graph", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;
      
      // Get current year
      const today = new Date();
      const currentYear = today.getFullYear();
      
      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      // Get the user IDs of all team members
      const teamMemberIds = teamMembers.map(member => member.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]); // No team members found
      }

      // For each month in the year, get the total sales
      const monthlySales = [];
      
      for (let month = 1; month <= 12; month++) {
        const firstDayOfMonth = new Date(currentYear, month - 1, 1);
        const lastDayOfMonth = new Date(currentYear, month, 0);
        
        const firstDayStr = firstDayOfMonth.toISOString().split('T')[0];
        const lastDayStr = lastDayOfMonth.toISOString().split('T')[0];
        
        // Skip future months
        if (firstDayOfMonth > today) {
          monthlySales.push({
            month,
            monthName: new Date(currentYear, month - 1, 1).toLocaleString('default', { month: 'short' }),
            totalSales: 0,
            totalArea: 0,
            salesCount: 0
          });
          continue;
        }
        
        // Get total sales for this month across all team members
        const [monthData] = await db.select({
          totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
          totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
          salesCount: sql<number>`COUNT(*)`
        })
        .from(sales)
        .where(
          and(
            inArray(sales.salesExecutiveId, teamMemberIds),
            gte(sales.bookingDate, firstDayStr),
            lte(sales.bookingDate, lastDayStr)
          )
        );
        
        monthlySales.push({
          month,
          monthName: new Date(currentYear, month - 1, 1).toLocaleString('default', { month: 'short' }),
          totalSales: monthData.totalSales,
          totalArea: monthData.totalArea,
          salesCount: monthData.salesCount
        });
      }
      
      res.json(monthlySales);
    } catch (error) {
      console.error("Error getting monthly graph data:", error);
      res.status(500).send("Error retrieving monthly graph data");
    }
  });
  
  // API endpoint to get team yearly sales data for managers
  app.get("/api/manager-sales-yearly", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;

      // Get yearly date range (since Jan 1 of current year)
      const today = new Date();
      const firstDay = new Date(today.getFullYear(), 0, 1);
      const lastDay = today;
      
      const firstDayStr = firstDay.toISOString().split('T')[0];
      const lastDayStr = lastDay.toISOString().split('T')[0];
      
      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      // Get the user IDs of all team members
      const teamMemberIds = teamMembers.map(member => member.id);
      
      if (teamMemberIds.length === 0) {
        return res.json({ teamMembers: [], teamTotal: { totalTeamSales: 0, totalTeamArea: 0, totalTeamCount: 0 } });
      }

      // Get yearly sales for the team members
      const teamYearlySalesData = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        fullName: users.fullName,
        imageUrl: users.imageUrl,
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .innerJoin(users, eq(sales.salesExecutiveId, users.id))
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      )
      .groupBy(sales.salesExecutiveId, users.fullName, users.imageUrl);

      // Get team total metrics for the year
      const [teamYearlyTotal] = await db.select({
        totalTeamSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalTeamArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        totalTeamCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      );

      res.json({
        teamMembers: teamYearlySalesData,
        teamTotal: teamYearlyTotal
      });
    } catch (error) {
      console.error("Error getting manager yearly sales data:", error);
      res.status(500).send("Error retrieving manager yearly sales data");
    }
  });

  // API endpoint to get team targets vs achievements
  app.get("/api/manager-targets", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;
      
      // Get the current month and year
      const today = new Date();
      const year = today.getFullYear();
      const month = today.getMonth() + 1; // JavaScript months are 0-based
      
      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      // Get the user IDs of all team members
      const teamMemberIds = teamMembers.map(member => member.id);
      
      if (teamMemberIds.length === 0) {
        return res.json({
          teamMembers: [],
          teamTotal: {
            targetAmount: 0,
            achievedAmount: 0,
            percentAchieved: 0,
            salesCount: 0,
            pendingAmount: 0
          },
          manager: {
            targetAmount: 0,
            personalAchievement: 0,
            teamAchievement: 0,
            combinedAchievement: 0,
            percentAchieved: 0,
            salesCount: 0,
            pendingAmount: 0
          }
        });
      }

      // Get current month's targets for each team member
      const teamTargets = await db.select()
        .from(targets)
        .where(
          and(
            inArray(targets.userId, teamMemberIds),
            eq(targets.year, year),
            eq(targets.month, month)
          )
        );
      
      // Get all sales for the current month for team members
      const firstDayOfMonth = new Date(year, month - 1, 1);
      const lastDayOfMonth = new Date(year, month, 0);
      
      const firstDayStr = firstDayOfMonth.toISOString().split('T')[0];
      const lastDayStr = lastDayOfMonth.toISOString().split('T')[0];
      
      // Get achievements (sales) for the current month
      const achievements = await db.select({
        salesExecutiveId: sales.salesExecutiveId,
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      )
      .groupBy(sales.salesExecutiveId);
      
      // Calculate team total achievements
      const [teamTotalAchievement] = await db.select({
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      );
      
      // Get the manager's own target for this month
      const managerTarget = await db.select()
        .from(targets)
        .where(
          and(
            eq(targets.userId, managerId),
            eq(targets.year, year),
            eq(targets.month, month)
          )
        )
        .then(results => results[0] || { targetValue: 0 });
      
      // Get the manager's personal sales achievements
      const [managerAchievement] = await db.select({
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(
        and(
          eq(sales.salesExecutiveId, managerId),
          gte(sales.bookingDate, firstDayStr),
          lte(sales.bookingDate, lastDayStr)
        )
      );
      
      // Calculate total target for team members
      const totalTeamTarget = teamTargets.reduce((sum, t) => sum + (t.targetValue || 0), 0);
      
      // For managers, achievements include both personal sales and team's sales
      const personalAchievement = managerAchievement.totalArea || 0;
      const teamAchievement = teamTotalAchievement.totalArea || 0;
      const combinedAchievement = personalAchievement + teamAchievement;
      
      // Calculate percentage achieved based on manager's target
      const managerTargetValue = managerTarget?.targetValue || 0;
      const percentAchieved = managerTargetValue > 0 
        ? Math.round((combinedAchievement / managerTargetValue) * 100) 
        : 0;
      
      console.log(`Team leader achievement calculation for manager ${managerId}:`, {
        personalAchievement,
        teamAchievement,
        combinedAchievement,
        managerTargetValue,
        percentAchieved
      });
      
      // Merge targets with achievements and include user details for team members
      const targetVsAchievement = teamMembers.map(member => {
        const target = teamTargets.find(t => t.userId === member.id) || { 
          targetValue: 0,
          userId: member.id,
          year,
          month
        };
        
        const achievement = achievements.find(a => a.salesExecutiveId === member.id) || {
          totalArea: 0,
          totalSales: 0,
          salesCount: 0
        };
        
        return {
          userId: member.id,
          fullName: member.fullName,
          imageUrl: member.imageUrl,
          targetAmount: target.targetValue || 0,
          achievedAmount: achievement.totalArea || 0,
          percentAchieved: target.targetValue ? 
            Math.round((achievement.totalArea / target.targetValue) * 100) : 0,
          salesCount: achievement.salesCount || 0,
          pendingAmount: Math.max(0, (target.targetValue || 0) - (achievement.totalArea || 0))
        };
      });
      
      res.json({
        teamMembers: targetVsAchievement,
        teamTotal: {
          targetAmount: totalTeamTarget,
          achievedAmount: teamTotalAchievement.totalArea || 0,
          percentAchieved: totalTeamTarget > 0 
            ? Math.round((teamTotalAchievement.totalArea / totalTeamTarget) * 100) 
            : 0,
          salesCount: teamTotalAchievement.salesCount || 0,
          pendingAmount: Math.max(0, totalTeamTarget - (teamTotalAchievement.totalArea || 0))
        },
        manager: {
          targetAmount: managerTargetValue,
          personalAchievement,
          teamAchievement,
          combinedAchievement,
          percentAchieved,
          salesCount: managerAchievement.salesCount || 0,
          pendingAmount: Math.max(0, managerTargetValue - combinedAchievement)
        }
      });
    } catch (error) {
      console.error("Error getting team targets vs achievements:", error);
      res.status(500).send("Error retrieving team targets vs achievements");
    }
  });

  // API endpoint to get team performance summary
  app.get("/api/manager-summary", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;
      
      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      // Get the user IDs of all team members
      const teamMemberIds = teamMembers.map(member => member.id);
      
      if (teamMemberIds.length === 0) {
        return res.json({
          monthly: { totalSales: 0, totalArea: 0, salesCount: 0 },
          yearly: { totalSales: 0, totalArea: 0, salesCount: 0 },
          allTime: { totalSales: 0, totalArea: 0, salesCount: 0 }
        });
      }

      // Get current month's date range
      const today = new Date();
      const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      
      const firstDayMonthStr = firstDayOfMonth.toISOString().split('T')[0];
      const lastDayMonthStr = lastDayOfMonth.toISOString().split('T')[0];
      
      // Get current year's date range
      const firstDayOfYear = new Date(today.getFullYear(), 0, 1);
      const firstDayYearStr = firstDayOfYear.toISOString().split('T')[0];
      const todayStr = today.toISOString().split('T')[0];
      
      // Get monthly team summary
      const [monthlySummary] = await db.select({
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayMonthStr),
          lte(sales.bookingDate, lastDayMonthStr)
        )
      );
      
      // Get yearly team summary
      const [yearlySummary] = await db.select({
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(
        and(
          inArray(sales.salesExecutiveId, teamMemberIds),
          gte(sales.bookingDate, firstDayYearStr),
          lte(sales.bookingDate, todayStr)
        )
      );
      
      // Get all-time team summary
      const [allTimeSummary] = await db.select({
        totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
        totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
        salesCount: sql<number>`COUNT(*)`
      })
      .from(sales)
      .where(inArray(sales.salesExecutiveId, teamMemberIds));
      
      res.json({
        monthly: monthlySummary,
        yearly: yearlySummary,
        allTime: allTimeSummary
      });
    } catch (error) {
      console.error("Error getting team performance summary:", error);
      res.status(500).send("Error retrieving team performance summary");
    }
  });
  
  // API endpoint to get year-to-date performance data for the graph
  app.get("/api/manager-ytd-graph", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const { user } = req;
      const { id: managerId } = user;
      
      // Get current year
      const today = new Date();
      const currentYear = today.getFullYear();
      const startOfYear = new Date(currentYear, 0, 1);
      
      // Get all team members reporting to this manager
      const teamMembers = await db.select().from(users)
        .where(eq(users.reportingManagerId, managerId));
      
      // Get the user IDs of all team members
      const teamMemberIds = teamMembers.map(member => member.id);
      
      if (teamMemberIds.length === 0) {
        return res.json([]); // No team members found
      }

      // For each week, get the cumulative sales from the start of the year
      const ytdData = [];
      
      // Define the start date as January 1st
      const startDate = new Date(currentYear, 0, 1);
      
      // Calculate number of weeks from start of year to today
      const millisecondsPerWeek = 7 * 24 * 60 * 60 * 1000;
      const weeksFromStart = Math.min(
        Math.ceil((today.getTime() - startDate.getTime()) / millisecondsPerWeek),
        52 // Cap at 52 weeks
      );
      
      for (let week = 1; week <= weeksFromStart; week++) {
        // Calculate the end date for this data point (week number from start of year)
        const endDate = new Date(startDate.getTime() + (week * millisecondsPerWeek));
        if (endDate > today) {
          // Don't go beyond today
          endDate.setTime(today.getTime());
        }
        
        const endDateStr = endDate.toISOString().split('T')[0];
        const startDateStr = startDate.toISOString().split('T')[0];
        
        // Get cumulative sales up to this week across all team members
        const [weekData] = await db.select({
          totalSales: sql<number>`COALESCE(SUM(${sales.finalAmount}), 0)`,
          totalArea: sql<number>`COALESCE(SUM(${sales.areaSold}), 0)`,
          salesCount: sql<number>`COUNT(*)`
        })
        .from(sales)
        .where(
          and(
            inArray(sales.salesExecutiveId, teamMemberIds),
            gte(sales.bookingDate, startDateStr),
            lte(sales.bookingDate, endDateStr)
          )
        );
        
        // Format date as "Week X" or with the month name for first week of each month
        const weekLabel = `Week ${week}`;
        
        ytdData.push({
          week,
          label: weekLabel,
          date: endDate.toISOString().split('T')[0],
          totalSales: weekData.totalSales,
          totalArea: weekData.totalArea,
          salesCount: weekData.salesCount
        });
      }
      
      res.json(ytdData);
    } catch (error) {
      console.error("Error getting year-to-date graph data:", error);
      res.status(500).send("Error retrieving year-to-date graph data");
    }
  });
}