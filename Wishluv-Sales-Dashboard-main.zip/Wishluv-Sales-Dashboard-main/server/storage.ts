import { 
  users, 
  projects, 
  departments, 
  roles, 
  activities, 
  leaderboard,
  sales,
  targets,
  siteVisits,
  type User, 
  type Project, 
  type Department, 
  type Role, 
  type Activity, 
  type Leaderboard,
  type Sales,
  type Target,
  type SiteVisit,
  type InsertUser, 
  type InsertProject, 
  type InsertDepartment, 
  type InsertRole, 
  type InsertActivity, 
  type InsertLeaderboard,
  type InsertSales,
  type InsertTarget,
  type InsertSiteVisit
} from "@shared/schema";
import session from "express-session";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  
  // Project management
  createProject(project: InsertProject): Promise<Project>;
  getProject(id: number): Promise<Project | undefined>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  getAllProjects(): Promise<Project[]>;
  
  // Department management
  createDepartment(department: InsertDepartment): Promise<Department>;
  getDepartment(id: number): Promise<Department | undefined>;
  updateDepartment(id: number, department: Partial<InsertDepartment>): Promise<Department | undefined>;
  deleteDepartment(id: number): Promise<boolean>;
  getAllDepartments(): Promise<Department[]>;
  
  // Role management
  createRole(role: InsertRole): Promise<Role>;
  getRole(id: number): Promise<Role | undefined>;
  updateRole(id: number, role: Partial<InsertRole>): Promise<Role | undefined>;
  deleteRole(id: number): Promise<boolean>;
  getAllRoles(): Promise<Role[]>;
  
  // Activity management
  createActivity(activity: InsertActivity): Promise<Activity>;
  getAllActivities(): Promise<Activity[]>;
  
  // Leaderboard management
  createLeaderboardEntry(entry: InsertLeaderboard): Promise<Leaderboard>;
  getLeaderboard(): Promise<Leaderboard[]>;
  
  // Announcement management
  createAnnouncement(announcement: any): Promise<any>;
  getAnnouncement(id: number): Promise<any | undefined>;
  deleteAnnouncement(id: number): Promise<boolean>;
  getAllAnnouncements(): Promise<any[]>;
  
  // Sales management
  createSale(sale: InsertSales): Promise<Sales>;
  getSale(id: number): Promise<Sales | undefined>;
  updateSale(id: number, sale: Partial<InsertSales>): Promise<Sales | undefined>;
  cancelSale(id: number, cancelledBy: number, cancellationReason: string): Promise<Sales | undefined>;
  deleteSale(id: number): Promise<boolean>;
  getAllSales(): Promise<Sales[]>;
  
  // Payment management
  createPayment(payment: any): Promise<any>;
  getPayment(id: number): Promise<any>;
  updatePayment(id: number, payment: any): Promise<any>;
  getPaymentsBySale(saleId: number): Promise<any[]>;
  getTotalPaymentsForSale(saleId: number): Promise<number>;
  
  // Sales dashboard data methods
  getMonthlySalesByUser(userId?: number): Promise<any[]>; // Sales for current month
  getYearlySalesByUser(userId?: number): Promise<any[]>; // Year-to-date sales
  getCrystalCityContestSales(userId?: number): Promise<any[]>; // Mar 15 - May 15 contest
  
  // Target management
  createTarget(target: InsertTarget): Promise<Target>;
  getTarget(userId: number, year: number, month: number): Promise<Target | undefined>;
  updateTarget(id: number, targetData: Partial<InsertTarget>): Promise<Target | undefined>;
  deleteTarget(id: number): Promise<boolean>;
  
  // Target vs Achievement data methods
  getUserTargets(userId: number): Promise<Target[]>;
  getAllTargets(): Promise<Target[]>;
  calculateUserAchievement(userId: number, startDate?: Date, endDate?: Date): Promise<any>;
  
  // Incentive management
  calculateIncentiveForSale(saleId: number): Promise<any>;
  getUserIncentives(userId: number, month?: number, year?: number): Promise<any[]>;
  getUserIncentivesSummary(userId: number, month: number, year: number): Promise<any>;
  getUpcomingPayouts(userId: number): Promise<any[]>;
  getIncentiveHistory(userId: number): Promise<any[]>;
  updatePaymentMilestones(): Promise<void>;
  
  // Site Visit management
  createSiteVisit(siteVisit: InsertSiteVisit): Promise<SiteVisit>;
  getSiteVisit(id: number): Promise<SiteVisit | undefined>;
  updateSiteVisit(id: number, siteVisitData: Partial<InsertSiteVisit>): Promise<SiteVisit | undefined>;
  deleteSiteVisit(id: number): Promise<boolean>;
  getAllSiteVisits(): Promise<SiteVisit[]>;
  getSiteVisitsByUser(userId: number): Promise<SiteVisit[]>;
  getSiteVisitsByDriver(driverId: number): Promise<SiteVisit[]>;
  approveSiteVisit(id: number, approvedBy: number, assignedDriverId?: number): Promise<SiteVisit | undefined>;
  completeSiteVisit(id: number, startOdometer: number, endOdometer: number, remarks?: string): Promise<SiteVisit | undefined>;
  
  // Session store
  sessionStore: session.Store;
}

// Import the DatabaseStorage class
import { DatabaseStorage } from './storage-db';

// Use the database storage implementation
export const storage = new DatabaseStorage();

// Initialize the database with seed data
storage.seedInitialData().catch(error => {
  console.error('Error seeding initial data:', error);
});